<?php
/**
 * 縮網址系統 - 常數設定檔
 * 所有固定變數統一管理於此檔案
 */

// 資料庫連線設定
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '9H-6a-0N-1s-29');
define('DB_NAME', 'mini_url_db');
define('DB_CHARSET', 'utf8mb4');

// 允許縮網址的網域白名單
define('ALLOWED_DOMAINS', [
    'www.yzu.edu.tw',
    'yzu.edu.tw',
    'www.google.com',
    'google.com',
    'www.google.com.tw',
    'google.com.tw'
]);

// 短網址基礎 URL（請根據實際部署位置修改）
define('BASE_URL', 'wusminiurl.ddns.net/mini_url/');

// 短網址碼長度
define('SHORT_CODE_LENGTH', 5);

// 短網址碼字元集（使用數字和大寫字母，避免容易混淆的字元）
define('SHORT_CODE_CHARS', '0123456789ABCDEFGHJKLMNPQRSTUVWXYZ');

// 資料表名稱
define('TABLE_URLS', 'urls');

// 是否啟用 Google AdSense（額外加分項目）
define('ENABLE_ADSENSE', true);

// Google AdSense Publisher ID（如果啟用 AdSense）
define('ADSENSE_PUBLISHER_ID', '8212135276378276');


