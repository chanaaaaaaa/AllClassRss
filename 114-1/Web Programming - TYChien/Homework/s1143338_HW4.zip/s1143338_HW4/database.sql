-- 縮網址系統資料庫結構
-- 請先建立資料庫：CREATE DATABASE mini_url_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE mini_url_db;

-- 建立網址對應表
CREATE TABLE IF NOT EXISTS urls (
    id INT AUTO_INCREMENT PRIMARY KEY,
    original_url VARCHAR(2048) NOT NULL COMMENT '原始網址',
    short_code VARCHAR(20) NOT NULL UNIQUE COMMENT '短網址碼',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '建立時間',
    click_count INT DEFAULT 0 COMMENT '點擊次數',
    INDEX idx_short_code (short_code),
    INDEX idx_original_url (original_url(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='網址對應表';


