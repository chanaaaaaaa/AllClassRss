<?php
/**
 * 處理 AJAX 請求，產生短網址
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../CONSTANT.php';

function generateShortCode($length = SHORT_CODE_LENGTH) {
    $chars = SHORT_CODE_CHARS;
    $code = '';
    $max = strlen($chars) - 1;
    
    for ($i = 0; $i < $length; $i++) {
        $code .= $chars[random_int(0, $max)];
    }
    
    return $code;
}

function isValidUrl($url) {
    // 檢查 URL 格式
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }
    
    // 解析網域
    $parsed = parse_url($url);
    if (!isset($parsed['host'])) {
        return false;
    }
    
    $host = $parsed['host'];
    
    // 移除 www. 前綴進行比對
    $hostWithoutWww = preg_replace('/^www\./', '', $host);
    
    // 檢查是否在白名單中
    foreach (ALLOWED_DOMAINS as $allowedDomain) {
        $allowedWithoutWww = preg_replace('/^www\./', '', $allowedDomain);
        if ($hostWithoutWww === $allowedWithoutWww) {
            return true;
        }
    }
    
    return false;
}

try {
    // 檢查是否為 POST 請求
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('僅接受 POST 請求');
    }
    
    // 取得原始網址
    $input = json_decode(file_get_contents('php://input'), true);
    $originalUrl = isset($input['url']) ? trim($input['url']) : '';
    
    if (empty($originalUrl)) {
        throw new Exception('請輸入網址');
    }
    
    // 確保網址有 http:// 或 https:// 前綴
    if (!preg_match('/^https?:\/\//i', $originalUrl)) {
        $originalUrl = 'https://' . $originalUrl;
    }
    
    // 驗證網址格式和網域
    if (!isValidUrl($originalUrl)) {
        throw new Exception('僅允許縮短以下網域的網址：' . implode(', ', ALLOWED_DOMAINS));
    }
    
    // 取得資料庫連線
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // 檢查是否已存在相同的原始網址
    $stmt = $conn->prepare("SELECT short_code FROM " . TABLE_URLS . " WHERE original_url = ? LIMIT 1");
    $stmt->execute([$originalUrl]);
    $existing = $stmt->fetch();
    
    if ($existing) {
        // 如果已存在，直接返回現有的短網址
        $shortCode = $existing['short_code'];
    } else {
        // 產生新的短網址碼，確保不重複
        $maxAttempts = 100;
        $attempts = 0;
        $shortCode = '';
        
        do {
            $shortCode = generateShortCode();
            $stmt = $conn->prepare("SELECT id FROM " . TABLE_URLS . " WHERE short_code = ? LIMIT 1");
            $stmt->execute([$shortCode]);
            $exists = $stmt->fetch();
            $attempts++;
            
            if ($attempts >= $maxAttempts) {
                throw new Exception('無法產生唯一的短網址碼，請稍後再試');
            }
        } while ($exists);
        
        // 插入資料庫
        $stmt = $conn->prepare("INSERT INTO " . TABLE_URLS . " (original_url, short_code) VALUES (?, ?)");
        $stmt->execute([$originalUrl, $shortCode]);
    }
    
    // 回傳結果
    echo json_encode([
        'success' => true,
        'short_url' => BASE_URL . $shortCode,
        'short_code' => $shortCode,
        'original_url' => $originalUrl
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}


