<?php
/**
 * 取得允許的網域列表（供前端使用）
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../CONSTANT.php';

echo json_encode([
    'success' => true,
    'domains' => ALLOWED_DOMAINS
], JSON_UNESCAPED_UNICODE);


