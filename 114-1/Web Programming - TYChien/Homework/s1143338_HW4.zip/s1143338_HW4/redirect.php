<?php
/**
 * 處理短網址轉址
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/CONSTANT.php';

// 從 URL 取得短網址碼
$shortCode = isset($_GET['code']) ? trim($_GET['code']) : '';

if (empty($shortCode)) {
    http_response_code(404);
    die('找不到指定的短網址');
}

try {
    // 取得資料庫連線
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // 查詢原始網址
    $stmt = $conn->prepare("SELECT original_url FROM " . TABLE_URLS . " WHERE short_code = ? LIMIT 1");
    $stmt->execute([$shortCode]);
    $result = $stmt->fetch();
    
    if (!$result) {
        http_response_code(404);
        die('找不到指定的短網址');
    }
    
    $originalUrl = $result['original_url'];
    
    // 更新點擊次數
    $stmt = $conn->prepare("UPDATE " . TABLE_URLS . " SET click_count = click_count + 1 WHERE short_code = ?");
    $stmt->execute([$shortCode]);
    
    // 執行轉址
    header('Location: ' . $originalUrl, true, 301);
    exit;
    
} catch (Exception $e) {
    http_response_code(500);
    die('系統錯誤：' . $e->getMessage());
}


