<?php
$host = 'localhost';
$dbuser ='root';
$dbpassword = '9H-6a-0N-1s-29';
$dbname = 'four_orientation_form';
$link = new mysqli($host,$dbuser,$dbpassword,$dbname);
if($link){
    mysqli_query($link,'SET NAMES utf8');
    // echo "正確連接資料庫";
}
else {
    echo "不正確連接資料庫</br>" . mysqli_connect_error();
}
?>