<?php
$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : '';
$pdf_file = 'orders/' . $order_id . '.pdf';
$qr_file = 'qrcodes/' . $order_id . '.png';
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>報名成功 - 四系聯合迎新活動</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Noto Sans TC', 'Microsoft JhengHei', sans-serif;
            background: #1a1a1a;
            color: #e0e0e0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            width: 100%;
            background: #2a2a2a;
            border: 2px solid #ff6b35;
            padding: 50px 30px;
            text-align: center;
            position: relative;
        }

        .success-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 30px;
            border: 4px solid #4caf50;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: scaleIn 0.5s ease-out;
        }

        .success-icon::after {
            content: '✓';
            font-size: 50px;
            color: #4caf50;
        }

        @keyframes scaleIn {
            0% { transform: scale(0); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        h1 {
            font-size: 2rem;
            color: #ff6b35;
            margin-bottom: 15px;
        }

        .subtitle {
            color: #b0b0b0;
            margin-bottom: 40px;
            font-size: 1.1rem;
        }

        .order-id {
            background: #1a1a1a;
            padding: 20px;
            margin: 30px 0;
            border-left: 4px solid #ff6b35;
        }

        .order-id-label {
            color: #b0b0b0;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }

        .order-id-value {
            font-size: 2rem;
            color: #ff6b35;
            font-weight: bold;
            letter-spacing: 0.2em;
        }

        .qr-section {
            margin: 40px 0;
            padding: 30px;
            background: #1a1a1a;
        }

        .qr-section img {
            max-width: 200px;
            width: 100%;
            height: auto;
            border: 4px solid #3a3a3a;
            padding: 10px;
            background: white;
        }

        .qr-label {
            margin-top: 15px;
            color: #b0b0b0;
            font-size: 0.9rem;
        }

        .info-box {
            background: #1a1a1a;
            padding: 25px;
            margin: 30px 0;
            text-align: left;
            border: 1px solid #3a3a3a;
        }

        .info-box p {
            margin: 10px 0;
            color: #b0b0b0;
            line-height: 1.8;
        }

        .info-box strong {
            color: #ff6b35;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 40px;
            flex-wrap: wrap;
        }

        .btn {
            flex: 1;
            min-width: 150px;
            padding: 15px 30px;
            border: 2px solid #ff6b35;
            background: transparent;
            color: #ff6b35;
            text-decoration: none;
            display: inline-block;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn:hover {
            background: #ff6b35;
            color: #1a1a1a;
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(255, 107, 53, 0.3);
        }

        .btn-primary {
            background: linear-gradient(45deg, #ff6b35, #f7931e);
            border: none;
            color: #1a1a1a;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(255, 107, 53, 0.4);
        }

        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;
            }

            h1 {
                font-size: 1.5rem;
            }

            .order-id-value {
                font-size: 1.5rem;
            }

            .button-group {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }
        }

        .email-notice {
            background: rgba(255, 107, 53, 0.1);
            border: 1px solid #ff6b35;
            padding: 20px;
            margin: 30px 0;
            border-radius: 0;
        }

        .email-notice p {
            color: #ff6b35;
            font-size: 0.95rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-icon"></div>
        
        <h1>報名成功！</h1>
        <p class="subtitle">您的報名已完成</p>

        <div class="order-id">
            <div class="order-id-label">您的訂單編號</div>
            <div class="order-id-value"><?php echo htmlspecialchars($order_id); ?></div>
        </div>

        <?php if (file_exists($qr_file)): ?>
        <div class="qr-section">
            <img src="<?php echo $qr_file; ?>" alt="報名 QR Code">
            <p class="qr-label">請保存此 QR Code，報到時出示即可</p>
        </div>
        <?php endif; ?>

        <div class="email-notice">
            <p>✉️ 報名確認信已發送至您的信箱</p>
            <p style="font-size: 0.85rem; margin-top: 10px;">請檢查收件匣或垃圾郵件資料夾</p>
        </div>

        <div class="info-box">
            <p><strong>📋 重要事項：</strong></p>
            <p>• 請妥善保存訂單編號與 QR Code</p>
            <p>• 活動當天請攜帶學生證</p>
            <p>• 報到時出示 QR Code 或訂單編號</p>
            <p>• 如需查詢報名資訊，請使用訂單編號</p>
        </div>

        <div class="button-group">
            <?php if (file_exists($pdf_file)): ?>
            <a href="<?php echo $pdf_file; ?>" target="_blank" class="btn btn-primary">下載確認單 PDF</a>
            <?php endif; ?>
            <a href="index.html" class="btn">返回首頁</a>
        </div>
    </div>
</body>
</html>