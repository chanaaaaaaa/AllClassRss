import os,base64,requests
from flask import Flask, request
from flask_ngrok import run_with_ngrok

# 載入 json 標準函式庫，處理回傳的資料格式
import requests, json, time, statistics

# 載入 LINE Message API 相關函式庫
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import MessageEvent, TextMessage, TextSendMessage

# 載入 MySQL 相關函式庫
import pymysql
import sys

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = 'code\key.json' # 金鑰 json
project_id = 'newagent-kxxt'                                   # dialogflow project id
language = 'en'                                                # 語系
session_id = 'ruichen'                                         # 自訂 session id

# LINE push 訊息函式
def push_message(msg, uid, token):
    headers = {'Authorization':f'Bearer {token}','Content-Type':'application/json'}   
    body = {
    'to':uid,
    'messages':[{
            "type": "text",
            "text": msg
        }]
    }
    req = requests.request('POST', 'https://api.line.me/v2/bot/message/push', headers=headers,data=json.dumps(body).encode('utf-8'))
    print(req.text)

# LINE 回傳訊息函式
def reply_message(msg, rk, token):
    headers = {'Authorization':f'Bearer {token}','Content-Type':'application/json'}
    body = {
    'replyToken':rk,
    'messages':[{
            "type": "text",
            "text": msg
        }]
    }
    req = requests.request('POST', 'https://api.line.me/v2/bot/message/reply', headers=headers,data=json.dumps(body).encode('utf-8'))
    print(req.text)

# LINE 回傳圖片函式
def reply_image(msg, rk, token):
    headers = {'Authorization':f'Bearer {token}','Content-Type':'application/json'}
    body = {
    'replyToken':rk,
    'messages':[{
          'type': 'image',
          'originalContentUrl': msg,
          'previewImageUrl': msg
        }]
    }
    req = requests.request('POST', 'https://api.line.me/v2/bot/message/reply', headers=headers,data=json.dumps(body).encode('utf-8'))
    print(req.text)

# LINE 回傳圖片函式
def reply_image(msg, rk, token):
    headers = {'Authorization':f'Bearer {token}','Content-Type':'application/json'}    
    body = {
    'replyToken':rk,
    'messages':[{
          'type': 'image',
          'originalContentUrl': msg,
          'previewImageUrl': msg
        }]
    }
    req = requests.request('POST', 'https://api.line.me/v2/bot/message/reply', headers=headers,data=json.dumps(body).encode('utf-8'))
    print(req.text)

#SQL information get
def query_database(target):
    """查詢資料庫範例"""
    try:
        reply=""
        # 連接到資料庫
        connection = pymysql.connect(
            host='wuspusing.ddns.net',
            port=3306,
            user='root',
            password='9H-6a-0N-1s-29',
            database='four_orientation_form',
            charset='utf8mb4'
        )
        cursor = connection.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM user_data")
        count = cursor.fetchone()
        print(f"\nuser_data表格中有 {count[0]} 筆資料\n")
        
        # 查詢4: 顯示前5筆資料 (如果有的話)
        if count[0] > 0:
            cursor.execute("SELECT * FROM user_data")
            rows = cursor.fetchall()
            for row in rows:
                print(row)
                if(row[2]==target):
                    return True
            return False
        else:
            print("\n4. 表格中沒有資料")
        
        cursor.close()
        connection.close()
        
        return reply

    except pymysql.Error as e:
        print(f"❌ 資料庫錯誤: {e}")
    except Exception as e:
        print(f"❌ 其他錯誤: {e}")


app = Flask(__name__)
@app.route("/", methods=['POST'])
def linebot():
    body = request.get_data(as_text=True)                    # 取得收到的訊息內容
    try:
        json_data = json.loads(body) 
        print(body)                        # json 格式化訊息內容
        access_token = 'Gs2gpzDO1/T99ggBEf/NqZfVjjejQ2zDL6iIJciH7MqqMVKkZAhNQL02P/SXx0t/LTkb9o7G0/bjQejhdpPiGdd1HGnhnEEISokwIFikKTYowZFJe0frqjvfJPIeOf+vwvZ/StynJASjIZQCnyt/NwdB04t89/1O/w1cDnyilFU='
        secret = '8de70cc350dc45902920777a64d73df8'
        line_bot_api = LineBotApi(access_token)              # 確認 token 是否正確
        handler = WebhookHandler(secret)                     # 確認 secret 是否正確
        signature = request.headers['X-Line-Signature']      # 加入回傳的 headers
        handler.handle(body, signature)                      # 綁定訊息回傳的相關資訊
        reply_token = json_data['events'][0]['replyToken']   # 取得回傳訊息的 Token
        user_id = json_data['events'][0]['source']['userId'] # 取得使用者 ID ( push message 使用 )
        type = json_data['events'][0]['message']['type']     # 取得 LINe 收到的訊息類型
        if type=='text':
            text = json_data['events'][0]['message']['text']
            if(text[:3] == 'SQL'):
                if query_database(text[3:]) :
                    reply='已報名 期待當天與您見面️️❤'
                else:
                    reply='未報名 以下是連結❤\nhttps://wuspusing.ddns.net/project/index.html'
            else:
                reply = '蛤?查詢格式是 SQL+<你的名字>\nEx: SQL帥哥'    
            print(reply)
            line_bot_api.reply_message(reply_token,TextSendMessage(reply))# 回傳訊息
        else:
            reply = '我看不懂～'
            print(reply)
            line_bot_api.reply_message(reply_token,TextSendMessage(reply))# 回傳訊息
    except:
        print(body)                                          # 如果發生錯誤，印出收到的內容
    return 'OK'                                              # 驗證 Webhook 使用，不能省略


if __name__ == "__main__":
    app.run()