<?php
$servername = "localhost";
$username = "root";
$password = "9H-6a-0N-1s-29";
$dbname = "four_orientation_form";
 
// create link
//$conn = new mysqli($servername, $username, $password, $dbname);
// check link
if ($conn->connect_error) {
    die("fail: " . $conn->connect_error);
} 
 
// use sql to create table
$sql = "CREATE TABLE User_Data (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
user_department VARCHAR(30) NOT NULL,
user_name VARCHAR(30) NOT NULL,
user_ID VARCHAR(30) NOT NULL,
user_birthday VARCHAR(50) NOT NULL,
user_email VARCHAR(100) NOT NULL,
user_phone VARCHAR(30) NOT NULL,
reg_date TIMESTAMP
)";
//$department,$name,$student,$birthday,$email,$phone,$timestamp
if ($conn->query($sql) === TRUE) {
    echo "Table MyGuests created successfully";
} else {
    echo "create table fail: " . $conn->error;
}
 
$conn->close();
?>