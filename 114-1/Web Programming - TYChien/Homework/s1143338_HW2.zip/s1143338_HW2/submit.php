<?php
// 開啟錯誤報告
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('./TCPDF/tcpdf.php');
require_once('./phpqrcode/qrlib.php'); // QR Code 函式庫

// PHPMailer use statements
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// 接收表單資料
$department = isset($_POST['department']) ? $_POST['department'] : '';
$name = isset($_POST['name']) ? $_POST['name'] : '';
$birthday = isset($_POST['birthday']) ? $_POST['birthday'] : '';
$student = isset($_POST['student']) ? $_POST['student'] : '';
$phone = isset($_POST['phone']) ? $_POST['phone'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';

// 學號格式驗證
function validateStudentId($studentId, $department) {
    // 基本格式檢查: sDDDSSdd
    if (!preg_match('/^s(10[5-9]|11[0-5])(14|15|33|18|20|17|35)\d{2}$/', $studentId)) {
        return false;
    }
    
    // 系所代碼對應
    $deptMapping = [
        '資工大一' => ['14', '15', '33'],
        '資管大一' => ['17'],
        '資傳大一' => ['18', '20'],
        '資應大一' => ['35']
    ];
    
    // 提取系所代碼
    $deptCode = substr($studentId, 4, 2);
    
    // 檢查系所代碼是否匹配
    if (isset($deptMapping[$department])) {
        return in_array($deptCode, $deptMapping[$department]);
    }
    
    return true; // 如果系所不在映射中，只檢查基本格式
}

// 驗證學號
if (!validateStudentId($student, $department)) {
    die('學號格式錯誤或與所選系所不符');
}

// 產生訂單編號（7位數字）
$order_id = substr(str_pad(mt_rand(0, 9999999), 7, '0', STR_PAD_LEFT), 0, 7);

// 產生 QR Code
$qr_path = __DIR__ . DIRECTORY_SEPARATOR . 'qrcodes' . DIRECTORY_SEPARATOR;
if (!file_exists($qr_path)) {
    mkdir($qr_path, 0777, true);
}
$qr_file = $qr_path . $student . '.png';
// 生成可從外部裝置訪問的 PDF 連結並寫入 QR Code
$public_pdf_url = 'https://wuspusing.ddns.net/project/orders/' . $student . '.pdf';
$qr_data = $public_pdf_url;
QRcode::png($qr_data, $qr_file, QR_ECLEVEL_L, 4);

//產生時間戳記
$timestamp = date('Y-m-d H:i:s');

/*---------------- Print PDF Start -----------------*/
try {
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    
    // 使用支援繁體中文的字體
    $pdf->SetFont('cid0jp', '', 12);
    $pdf->AddPage();
} catch (Exception $e) {
    error_log("TCPDF初始化錯誤: " . $e->getMessage());
    die('PDF生成失敗: ' . $e->getMessage());
}

// 檢查QR Code檔案是否存在
if (!file_exists($qr_file)) {
    error_log("QR Code檔案不存在，跳過QR Code: " . $qr_file);
    $qr_file_pdf = '';
} else {
    $qr_file_pdf = str_replace('\\', '/', $qr_file);
}

// 構建QR Code部分
$qr_section = '';
if (!empty($qr_file_pdf)) {
    $qr_section = '<img src="@' . $qr_file_pdf . '" width="150" height="150">';
} else {
    $qr_section = '<p>QR Code生成中...</p>';
}

$html = <<<EOF
<style>
    .title { font-size: 24px; text-align: center; font-weight: bold; color: #ff6b35; margin-bottom: 10px; }
    .order-id { text-align: right; font-size: 14px; margin-bottom: 20px; }
    .qr-section { text-align: center; margin: 20px 0; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    td { padding: 12px; border: 1px solid #ddd; }
    .label { background-color: #f5f5f5; font-weight: bold; width: 30%; }
    .footer { text-align: center; font-size: 10px; color: #666; margin-top: 30px; border-top: 1px solid #ddd; padding-top: 10px; }
</style>

<div class="title">四系聯合迎新活動<br>訂單確認單</div>

<div class="order-id">訂單編號: $order_id</div>

<div class="qr-section">
    $qr_section
</div>

<table>
    <tr>
        <td class="label">年級系所</td>
        <td>$department</td>
    </tr>
    <tr>
        <td class="label">姓名</td>
        <td>$name</td>
    </tr>
    <tr>
        <td class="label">學號</td>
        <td>$student</td>
    </tr>
    <tr>
        <td class="label">生日</td>
        <td>$birthday</td>
    </tr>
    <tr>
        <td class="label">電話號碼</td>
        <td>$phone</td>
    </tr>
    <tr>
        <td class="label">電子信箱</td>
        <td>$email</td>
    </tr>
    <tr>
        <td colspan="2" style="background-color: #f5f5f5; font-weight: bold;">桃園市中壢區遠東路135號</td>
    </tr>
</table>

<div class="footer">
    <p>報名時間: $timestamp</p>
    <p>此為正式報名憑證，請妥善保存</p>
    <p>四系聯合迎新活動籌備委員會</p>
</div>
EOF;

try {
    $pdf->writeHTML($html, true, false, true, false, '');
} catch (Exception $e) {
    error_log("PDF HTML寫入錯誤: " . $e->getMessage());
    die('PDF內容生成失敗: ' . $e->getMessage());
}

// 儲存 PDF 到伺服器
$pdf_path = __DIR__ . DIRECTORY_SEPARATOR . 'orders' . DIRECTORY_SEPARATOR;
if (!file_exists($pdf_path)) {
    mkdir($pdf_path, 0777, true);
}
$pdf_file = $pdf_path . $student . '.pdf';

try {
    $pdf->lastPage();
    $pdf_content = $pdf->Output('', 'S');
    
    if (file_put_contents($pdf_file, $pdf_content) === false) {
        error_log("PDF檔案寫入失敗: " . $pdf_file);
        die('PDF檔案儲存失敗');
    }
    
    error_log("PDF檔案儲存成功: " . $pdf_file);
    
} catch (Exception $e) {
    error_log("PDF輸出錯誤: " . $e->getMessage());
    die('PDF輸出失敗: ' . $e->getMessage());
}
/*---------------- Print PDF End -------------------*/

/*---------------- Sent Mail Start -----------------*/
$mail_sent = false;
try {
    require './PHPMailer/src/Exception.php';
    require './PHPMailer/src/PHPMailer.php';
    require './PHPMailer/src/SMTP.php';

    // 嘗試多個SMTP端口
    $smtp_ports = [
        ['port' => 587, 'secure' => PHPMailer::ENCRYPTION_STARTTLS],
        ['port' => 465, 'secure' => PHPMailer::ENCRYPTION_SMTPS],
        ['port' => 25, 'secure' => PHPMailer::ENCRYPTION_STARTTLS]
    ];
    
    $last_error = '';
    
    // 嘗試每個端口發送郵件
    foreach ($smtp_ports as $config) {
        try {
            $mail = new PHPMailer(true);
            
            // SMTP 設定
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'fourdepartmentorientation@gmail.com';
            $mail->Password = 'ncmt hakv mdie wtae';
            $mail->CharSet = 'UTF-8';
            $mail->SMTPSecure = $config['secure'];
            $mail->Port = $config['port'];
            
            error_log("嘗試SMTP端口: " . $config['port'] . " (加密: " . $config['secure'] . ")");
            
            // 設定收件人資訊
            $mail->setFrom($mail->Username, '四系聯合迎新活動');
            $mail->addAddress($email, $name);
            $mail->isHTML(true);
            $mail->Subject = '【四系聯合迎新活動】報名確認通知';
        
            // 設定郵件內容
            $mail_body = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset='UTF-8'>
                <style>
                    body { font-family: Arial, '微軟正黑體', sans-serif; background: #f5f5f5; padding: 20px; }
                    .container { max-width: 600px; margin: 0 auto; background: white; border: 3px solid #ff6b35; }
                    .header { background: linear-gradient(135deg, #2c2c2c 0%, #1a1a1a 100%); color: white; padding: 30px; text-align: center; }
                    .header h1 { margin: 0; font-size: 28px; color: #ff6b35; }
                    .content { padding: 30px; }
                    .info-row { margin: 15px 0; padding: 10px; background: #f9f9f9; border-left: 4px solid #ff6b35; }
                    .label { font-weight: bold; color: #333; }
                    .qr-section { text-align: center; padding: 20px; background: #f5f5f5; margin: 20px 0; }
                    .footer { background: #2c2c2c; color: #b0b0b0; padding: 20px; text-align: center; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='header'>
                        <h1>報名成功！</h1>
                        <p>四系聯合迎新活動</p>
                    </div>
                    <div class='content'>
                        <p>親愛的 <strong>$name</strong> 同學您好：</p>
                        <p>您的報名已成功送出！以下是您的報名資訊：</p>
                        
                        <div class='info-row'>
                            <span class='label'>訂單編號：</span>$order_id
                        </div>
                        <div class='info-row'>
                            <span class='label'>年級系所：</span>$department
                        </div>
                        <div class='info-row'>
                            <span class='label'>學號：</span>$student
                        </div>
                        <div class='info-row'>
                            <span class='label'>姓名：</span>$name
                        </div>
                        <div class='info-row'>
                            <span class='label'>生日：</span>$birthday
                        </div>
                        <div class='info-row'>
                            <span class='label'>電話號碼：</span>$phone
                        </div>
                        <div class='info-row'>
                            <span class='label'>電子信箱：</span>$email
                        </div>
                        
                        <div class='qr-section'>
                            <p><strong>您的專屬 QR Code</strong></p>
                            <p style='color: #666; font-size: 14px;'>請保存此 QR Code，報到時出示即可</p>
                            <p style='margin-top:12px;'>或點擊下列連結查詢您的報名確認單：<br>
                            <a href='$public_pdf_url' target='_blank' style='color:#ff6b35;'>開啟報名確認單 PDF</a></p>
                        </div>
                        
                        <p style='color: #666; margin-top: 30px;'>
                            ※ 活動當天請攜帶學生證並出示此郵件或 QR Code<br>
                            ※ 如有任何問題，請聯繫主辦單位
                        </p>
                    </div>
                    <div class='footer'>
                        <p>此為系統自動發送郵件，請勿直接回覆</p>
                        <p>四系聯合迎新活動籌備委員會</p>
                    </div>
                </div>
            </body>
            </html>
            ";
            
            $mail->Body = $mail_body;
            
            // 只有在QR Code檔案存在時才添加附件
            if (file_exists($qr_file)) {
                $mail->addAttachment($qr_file, 'QRCode_' . $student . '.png');
            }
            
            // 嘗試發送郵件
            $mail->send();
            $mail_sent = true;
            error_log("郵件發送成功，使用端口: " . $config['port']);
            break; // 發送成功，跳出迴圈
            
        } catch (Exception $e) {
            $last_error = $e->getMessage();
            error_log("SMTP端口 " . $config['port'] . " 發送失敗: " . $last_error);
            continue; // 嘗試下一個端口
        }
    }
    
    if (!$mail_sent) {
        error_log("所有SMTP端口都無法發送郵件，最後錯誤: " . $last_error);
    }
    
} catch (Exception $e) {
    $mail_sent = false;
    error_log("郵件發送失敗: " . $e->getMessage());
    // 不中斷執行，繼續生成PDF
}
/*---------------- Sent Mail End -------------------*/


/*-------------- Add To Mysql Start ----------------*/
try {
    require_once 'link_to_db.php';  // 載入db.php來連結資料庫
    
    if (!$link) {
        throw new Exception("資料庫連接失敗");
    }
    
    // sql語法存在變數中
    $sql = "INSERT INTO  `user_data` (`user_department`,`user_name`,`user_ID`,`user_birthday`,`user_email`,`user_phone`,`reg_date`) VALUES ('$department','$name','$student','$birthday','$email','$phone','$timestamp') ";
    
    // 用mysqli_query方法執行(sql語法)將結果存在變數中
    $result = mysqli_query($link,$sql);
    
    if (!$result) {
        throw new Exception("資料庫插入失敗: " . mysqli_error($link));
    }
    
    error_log("資料庫操作成功");
    
} catch (Exception $e) {
    error_log("資料庫操作錯誤: " . $e->getMessage());
    // 不中斷執行，繼續生成PDF
}

if (isset($link) && $link) {
    mysqli_close($link); 
}
/*-------------- Add To Mysql End ------------------*/

// 返回PDF URL給前端
header('Content-Type: application/json');
$response = ['pdfUrl' => 'orders/' . $student . '.pdf'];
echo json_encode($response);
error_log("返回JSON: " . json_encode($response));

exit;
?>