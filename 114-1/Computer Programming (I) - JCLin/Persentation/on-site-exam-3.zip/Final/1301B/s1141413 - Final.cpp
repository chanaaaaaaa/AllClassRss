#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}
// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary);

    if (!inFile)
        cout << "can't open it!" << endl;

    MemberRecord temp;

    inFile.read(reinterpret_cast<char*>(&temp), sizeof(memberDetails));

}
// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations)
{

    ifstream inFile("Reservations.dat", ios::binary);

    if (!inFile)
        cout << "can't open it!" << endl;

    ReservationRecord temp;

    inFile.read(reinterpret_cast<char*>(&temp), sizeof(reservations));

}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}
// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{
    Date currentDate = compCurrentDate();
    ReservationRecord reservation;

    int day = currentDate.day;
    int hour = currentDate.hour;
    int year = currentDate.year;
    int month = currentDate.month;

    int year1 = reservation.date.year;
    int month1 = reservation.date.month;
    int day1 = reservation.date.day;
    int hour1 = 0;

    int date1 = year1 * 1000000 + month1 * 1000 + day1 * 10 + hour1;
    int date2 = year * 1000000 + month * 1000 + day * 10 + hour;

    if (date1 <= date2)
    {
        return true;
    }
    else
        return false;



}
// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}
// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}
// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile)
        cout << "can't open it!" << endl;

    MemberRecord temp;

    inFile.read(reinterpret_cast<char*>(&temp), sizeof(memberDetails));

    if (!strcmp(idNumber, temp.idNumber)) {
        if (!strcmp(password, temp.password)) {
            return true;
        }
    }
    else {
        cout << "Invalid account number or password. Please try again." << endl;
        return false;
    }

}
// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    int branchCode;
    do
    {
        for (int i = 0; i <= 18; i++)
        {
            if (i != 0)
                cout << i << '.';
            for (int j = 0; j <= 23; j++)
            {
                cout << branchNames[i][j];
            }
            cout << endl;
        }

        cout << "Enter your choice (0 to end):" << endl;
        cin >> branchCode;
    } while (branchCode < 0 || branchCode > 18);

    if (branchCode == 0) {
        return;
    }
    
    newReservation.branchCode = branchCode;

    int choose;
    do
    {
        Date currentDate = compCurrentDate();
        compAvailableDates();

        cout << "Enter your choice (0 to end):" << endl;
        cin >> choose;

    } while (choose < 0 || choose > 7);

    if (choose == 0) {
        return;
    }
    newReservation.date.year = year;
    newReservation.date.month = month;
    


    Date currentDate = compCurrentDate();
    int hour;
    int start = currentDate.hour + 1;

    if (start == 24) {
        start -= 24;
    }

    do
    {
        cout << "Enter hour(" << start << "~" << 23 << ")" << endl;
        cin >> hour;

    } while (hour < start || hour > 23);

    if (hour == 0) {
        return;
    }

    newReservation.date.hour = hour;

    int numCustomers;

    do 
    {
        cout << "Enter the number of customers (1~30, 0 to end):" << endl;
        cin >> numCustomers;
    } while (numCustomers < 0 || numCustomers > 30);

    if (numCustomers == 0) {
        return;
    }

    newReservation.numCustomers = numCustomers;

    

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    cout << "The current hour is";
    cout << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;

    int day = currentDate.day;
    int hour = currentDate.hour;
    int year = currentDate.year;
    int month = currentDate.month;

    for (int i = 0; i < 7; i++)
    {
        if (hour == 23) {
            day++;
            hour = 0;
        }
        if (month == 2) {
            if (year % 400 == 0 || year % 4 == 0 && year % 100 != 0) {
                if (day > 29) {
                    month++;
                    day -= 29;
                }
            }
            else {
                if (day > 28) {
                    month++;
                    day -= 28;
                }
            }
        }
        else if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
        {
            if (day > 31) {
                month++;
                day -= 31;
                if (month > 12) {
                    year++;
                    month -= 12;
                }
            }
        }
        else {
            if (day > 30) {
                month++;
                day -= 30;
            }
        }
        cout << i + 1 << "." << year << "/" << month << "/" << day << " \n";
        day++;
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}
// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    lessEqual(date1, date2);

    ReservationRecord save;

    ofstream ioFile("Reservations.dat", ios::in | ios::out | ios::binary);
    if (!ioFile)
        cout << "can't open it!" << endl;

    ioFile.seekp(0, ios::beg);

    



}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}
// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{

    ifstream inFile("Members.dat", ios::binary);

    if (!inFile)
        cout << "can't open it!" << endl;

    MemberRecord newMember;

    inFile.read(reinterpret_cast<char*>(&newMember), sizeof(memberDetails));

    if (!strcmp(idNumber, newMember.idNumber)) {

        return true;

    }
    else {
        return false;
    }



}
// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Member.dat", ios::in | ios::out | ios::binary);
    if (!outFile) {
        cout << "can't open it!" << endl;
    }

    MemberRecord save;
    outFile.seekp(0, ios::end);
    outFile.write(reinterpret_cast<const char*>(&save),sizeof(memberDetails));

    outFile.close();
}
// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream ioFile("Reservations.dat", ios::in | ios::out | ios::binary);

    ReservationRecord save;
    ioFile.seekp(0, ios::end);
    ioFile.write(reinterpret_cast<const char*> (&save), sizeof(reservations));

    ioFile.close();
}
