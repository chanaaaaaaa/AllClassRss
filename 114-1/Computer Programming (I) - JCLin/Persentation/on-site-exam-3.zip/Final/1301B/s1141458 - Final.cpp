#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    MemberRecord temp;

    int numRecords = 0;

    ifstream file("Members.dat", ios::in | ios::out | ios::binary);

    if (!file)
    {
        cout << "File cannot be opened!" << endl;
        system("pause");
        exit(1);
    }

    file.seekg(0, ios::beg);

    while (file.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord)))
    {
        
         memberDetails[numRecords] = temp;
         numRecords++;
    }

    file.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    ReservationRecord temp;

    int numRecords = 0;

    ifstream file("Reservations.dat", ios::in | ios::out | ios::binary);

    if (!file)
    {
        cout << "File cannot be opened!" << endl;
        system("pause");
        exit(1);
    }

    file.seekg(0, ios::beg);

    while (file.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord)))
    {
        if (!lessEqual(currentDate, temp.date))
        {
            reservations[numRecords] = temp;
            numRecords++;
        } 
    }

    file.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year)
    {
        return true;
    }
    else if (date1.year == date2.year)
    {
        if (date1.month < date2.month)
        {
            return true;
        }
        else if (date1.month == date2.month)
        {
            if (date1.day <= date2.day)
            {
                return true;
            }
        }
    }

    return false;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < 100; i++)
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0 && strcmp(memberDetails[i].password, password) == 0)
        {
            return true;
        }
        
    }

    cout << endl << "Invalid account number or password. Please try again." << endl << endl;
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    int choiceBranch;
    int choiceDate;
    int choiceHour;
    int choiceNumCustomers;

    int availableMinHour;

    ReservationRecord newReservation;

    for (int i = 1; i <= 18; i++)
    {
        cout << i << ". " << branchNames[i] << endl;
    }

    do {
        cout << endl << "Enter your choice (0 to end): ";
        cin >> choiceBranch;
        cout << endl << endl;

        if (choiceBranch == 0)
            return;

    } while (choiceBranch < 1 || choiceBranch > 18);

    Date currentDate = compCurrentDate();
    cout << "The current hour is: "
        << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ": " 
        << currentDate.hour << endl << endl;
        

    cout << "Available days:" << endl << endl;

    Date availableDates[7];

    compAvailableDates(availableDates);

    if (availableDates[1].day == currentDate.day)
        availableMinHour = currentDate.hour + 1;
    else if (availableDates[1].day != currentDate.day)
        availableMinHour = 0;


    for (int i = 1; i <= 7; i++)
    {
        cout << i << ". " << availableDates[i].year << "/" << availableDates[i].month
            << "/" << availableDates[i].day << endl;
    }

    do {
        cout << endl << "Enter your choice (0 to end): ";
        cin >> choiceDate;
        cout << endl << endl;

        if (choiceDate == 0)
            return;

    } while (choiceDate < 1 || choiceDate > 7);

    do {
        cout << endl << "Enter hour " << "(" << availableMinHour << "~23): ";
        cin >> choiceHour;
        cout << endl << endl;

        if (choiceHour == 0)
            return;

    } while (choiceHour < availableMinHour || choiceHour > 23);

    do {
        cout << endl << "Enter the number of customers (1~30, 0 to end): ";
        cin >> choiceNumCustomers;
        cout << endl << endl;

        if (choiceNumCustomers == 0)
            return;

    } while (choiceNumCustomers < 1 || choiceNumCustomers > 30);

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    newReservation.branchCode = choiceBranch;
    newReservation.date = availableDates[choiceDate];
    strcpy_s(newReservation.idNumber, 12, idNumber);
    newReservation.numCustomers = choiceNumCustomers;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    int addCounter = 0;
    int subtractCounter;
    int februaryNumDays;

    if (currentDate.year / 400 == 0)
    {
        februaryNumDays = 29;
    }
    else if (currentDate.year / 100 == 0 || currentDate.year / 400 != 0)
    {
        februaryNumDays = 28;
    }
    else if (currentDate.year / 4 == 0 || currentDate.year / 100 != 0)
    {
        februaryNumDays = 29;
    }

    int daysPerMonth[12] = { 0, 31, februaryNumDays, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (currentDate.month == 12)
    {
        if (currentDate.hour == 23)
        {
            availableDates[1].day = currentDate.day + 1;

          
            for (int i = 2; i <= 7; i++)
            {

                if (currentDate.day == daysPerMonth[currentDate.month])
                    break;

                currentDate.day++;
                availableDates[i].day = currentDate.day;
                availableDates[i].month = currentDate.month;
                availableDates[i].year = currentDate.year;
                addCounter++;

            }

            if (addCounter < 6)
            {
                currentDate.year++;
                currentDate.month = 1;
                currentDate.day = 1;


                int k = 1;
                subtractCounter = 6 - addCounter;

                for (int i = 1; i <= subtractCounter; i++)
                {
                    availableDates[addCounter + 1].day = k;
                    k++;
                }
            }
        }
        else if (currentDate.hour != 23)
        {
            availableDates[1].day = currentDate.day;


            for (int i = 2; i <= 7; i++)
            {

                if (currentDate.day == daysPerMonth[currentDate.month])
                    break;

                currentDate.day++;
                availableDates[i].day = currentDate.day;
                availableDates[i].month = currentDate.month;
                availableDates[i].year = currentDate.year;
                addCounter++;

            }

            if (addCounter < 6)
            {
                currentDate.year++;
                currentDate.month = 1;
                currentDate.day = 1;


                int k = 1;
                subtractCounter = 6 - addCounter;

                for (int i = 1; i <= subtractCounter; i++)
                {
                    availableDates[addCounter + 1].day = k;
                    k++;
                }
            }
        }
    }
    else if (currentDate.month != 12)
    {
        if (currentDate.hour == 23)
        {
            availableDates[1].day = currentDate.day + 1;


            for (int i = 2; i <= 7; i++)
            {

                if (currentDate.day == daysPerMonth[currentDate.month])
                    break;

                currentDate.day++;
                availableDates[i].day = currentDate.day;
                availableDates[i].month = currentDate.month;
                availableDates[i].year = currentDate.year;
                addCounter++;

            }

            if (addCounter < 6)
            {
                currentDate.month++;
                currentDate.day = 1;


                int k = 1;
                subtractCounter = 6 - addCounter;

                for (int i = 1; i <= subtractCounter; i++)
                {
                    availableDates[addCounter + 1].day = k;
                    k++;
                }
            }
        }
        else if (currentDate.hour != 23)
        {
            availableDates[1].day = currentDate.day;


            for (int i = 2; i <= 7; i++)
            {

                if (currentDate.day == daysPerMonth[currentDate.month])
                    break;

                currentDate.day++;
                availableDates[i].day = currentDate.day;
                availableDates[i].month = currentDate.month;
                availableDates[i].year = currentDate.year;
                addCounter++;

            }

            if (addCounter < 6)
            {
                currentDate.month++;
                currentDate.day = 1;


                int k = 1;
                subtractCounter = 6 - addCounter;

                for (int i = 1; i <= subtractCounter; i++)
                {
                    availableDates[addCounter + 1].day = k;
                    k++;
                }
            }
        }
    }


}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    int validRecord[50] = {};
    int count = 0;

    Date currentDate = compCurrentDate();

    for (int i = 0; i < 100; i++)
    {
        if (!lessEqual(currentDate, reservations[validRecord[count]].date))
        {
            if (strcmp(idNumber, reservations[i].idNumber) == 0)
            {
                validRecord[count] = i;
                count++;
            }
        }
    }

    if (count == 0)
        cout << "No reservations!" << endl << endl;

    for (int i = 0; i <= count; i++)
    {
        cout << i << ". ";
        output(reservations[i]);
    }

    int choice;

    do {
        cout << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> choice;

        if (choice == 0)
            return;

    } while (choice < 1 || choice > count);


  
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < 100; i++)
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0)
        {
            return true;
        }

    }

    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    int numRecords;

    vector< MemberRecord > temp;

    for (int i = 0; i < 100; i++)
    {
        temp[i] = memberDetails[i];
    }

    ofstream file("Members.dat", ios::in | ios::out | ios::binary);

    if (!file)
    {
        cout << "File cannot be opened!" << endl;
        system("pause");
        exit(1);
    }

    file.seekp(0, ios::beg);

    while (file.write(reinterpret_cast<char*>(&temp), sizeof(MemberRecord)))
    {
        numRecords++;
    }

    file.close();

    
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    int numRecords;

    vector< ReservationRecord > temp;

    for (int i = 0; i < 100; i++)
    {
        temp[i] = reservations[i];
    }

    ofstream file("Reservations.dat", ios::in | ios::out | ios::binary);

    if (!file)
    {
        cout << "File cannot be opened!" << endl;
        system("pause");
        exit(1);
    }

    file.seekp(0, ios::beg);

    for (int i = 0; i < 100; i++)
    {


        while (!lessEqual(currentDate, temp[i].date))
        {
            file.write(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord));
            numRecords++;
        }
    }

    file.close();
}