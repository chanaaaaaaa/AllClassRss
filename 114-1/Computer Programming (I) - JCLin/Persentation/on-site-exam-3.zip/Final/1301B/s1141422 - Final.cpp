#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::fstream ;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
	ifstream infile("Members.dat" ,ios::binary) ;
	if(!infile){
		cout<<"Fail to check MemberDetails.\n" ;
		return ;
	}
	MemberRecord current[200] ;
	int currentnum=0 ;
	while(infile.read(reinterpret_cast<char*>(&current[currentnum]) ,sizeof(MemberRecord))){
		currentnum++ ;
		memberDetails.push_back(current[currentnum]) ;
	}
	infile.close() ;
}

void loadReservations( vector< ReservationRecord > &reservations )
{
	ifstream infile("Reservations.dat" ,ios::binary) ;
	if(!infile){
		cout<<"Fail to check Reservations.\n" ;
		return ;
	}
	ReservationRecord current[200] ;
	int currentnum=0 ;
	while(infile.read(reinterpret_cast<char*>(&current[currentnum]) ,sizeof(ReservationRecord))){
		currentnum++ ;
		reservations.push_back(current[currentnum]) ;
	}
	infile.close() ;
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year =2025; //structuredTime.tm_year + 1900;
   currentDate.month =12; //structuredTime.tm_mon + 1;
   currentDate.day =31; //structuredTime.tm_mday;
   currentDate.hour =18; //structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
	if(date2.year>date1.year){
		return true ;
	}
	else if(date2.year==date1.year && date2.month>date1.month){
		return true ;
	}
	else if(date2.year==date1.year && date2.month==date1.month && date2.day>date1.day){
		return true ;
	}
	else if(date2.year==date1.year && date2.month==date1.month && date2.day==date1.day && date2.hour>=date1.hour){
		return true ;
	}
	else{
		return false ;
	}
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
	ifstream infile("Members.dat" ,ios::binary) ;
	MemberRecord current ;
	while(infile.read(reinterpret_cast<char*>(&current) ,sizeof(MemberRecord))){
		if(strcmp(idNumber ,current.idNumber)==0){
			if(strcmp(password ,current.password)==0){
				return true ;
			}
		}
	}
	infile.close() ;
	cout<<"Invalid account number or password. Please try again.\n" ;
	return false ;
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   	ReservationRecord newReservation;
   	strcpy(newReservation.idNumber ,idNumber) ;
   	Date currentDate=compCurrentDate() ;
	Date availableDates[6] ;
	for(int i=1 ;i<=18 ;i++){
		cout<<setw(2)<<i<<". "<<branchNames[i]<<endl ;
	}
	do{
		cout<<"\nEnter your choice (0 to end):" ;
		cin>>newReservation.branchCode ;
		if(newReservation.branchCode==0){
			return ;
		}
	}while(newReservation.branchCode<1 || newReservation.branchCode>18) ;
	cout<<"\nThe current hour is "<<currentDate.year<<"/"<<currentDate.month<<"/"<<currentDate.day<<"/"<<currentDate.hour<<endl ;
	cout<<"\nAvailable days:\n" ;
	compAvailableDates(availableDates) ;
	for(int i=0 ;i<7 ;i++){
		cout<<i+1<<". "<<availableDates[i].year<<"/"<<availableDates[i].month<<"/"<<availableDates[i].day<<endl ;
	}
	int choice ;
	do{
		cout<<"\nEnter your choice (0 to end):" ;
		cin>>choice ;
		if(choice==0){
			return ;
		}
	}while(choice>7 ||choice<0 ) ;
	int hour ;
	Date currentDate2=compCurrentDate() ;
	do{
		if(choice==1){
			cout<<"\nEnter hour ("<<currentDate2.hour<<"~"<<"23"<<"): "<<endl ;
		}
		else{
			cout<<"\nEnter hour ("<<"0"<<"~"<<"23"<<"): "<<endl ;
		}
		cin>>hour ;
	}while(hour<currentDate2.hour || hour>23 ||hour<0);
	newReservation.date.year=availableDates[choice-1].year ;
	newReservation.date.hour=hour ;
	newReservation.date.month=availableDates[choice-1].month ;
	newReservation.date.day=availableDates[choice-1].day ;
	do{
		cout<<"\nEnter the number of customers (1~30, 0 to end): " ;
		cin>>newReservation.numCustomers ;
		if(newReservation.numCustomers==0){
			return ;
		}
	}while(newReservation.numCustomers<0|| newReservation.numCustomers>30) ;

   	cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   	output( newReservation );
	
	
	cin.ignore();
   	cout << "\nReservation Completed!\n";
	reservations.push_back( newReservation );
   	saveReservations( reservations ) ;
   	
}

void compAvailableDates( Date availableDates[] )
{
   	Date currentDate = compCurrentDate();
   	int i=0 ;
	int monthdays[13]{ 0 ,31 ,28 ,31 ,30 ,31 ,30 ,31 ,31 ,30 ,31 ,30 ,31} ;
	if(currentDate.year%400==0 && currentDate.year%100!=0 ){
		monthdays[2]=29 ;
	}
	for(int i=0 ;i<7 ;i++){
		availableDates[i].year=currentDate.year ;
		availableDates[i].month=currentDate.month ;
		availableDates[i].day=currentDate.day+i ;
	}
	for(int i=0 ;i<7 ;i++){
		if(availableDates[i].month==12 && availableDates[i].day>31){ 
			availableDates[i].year+=1 ;
			availableDates[i].month=1 ;
			availableDates[i].day=availableDates[i].day-31 ;
		}
		else if(availableDates[i].day>monthdays[availableDates[i].month]){
			availableDates[i].month+=1 ;
			availableDates[i].day=availableDates[i].day-monthdays[availableDates[i].month] ;
		}
	}
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{	
   	Date currentDate = compCurrentDate() ;
   	ReservationRecord found[200] ;
   	int foundnum=0 ;
   	cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;
   	for(int i=0 ;i<reservations.size() ;i++){
   		if(strcmp(idNumber ,reservations[i].idNumber)==0){
   			found[foundnum]=reservations[i] ;
   			foundnum++ ;
   			cout<<foundnum<<"." ;
   			output(reservations[i]) ;
		}		
	}
	
	


}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );
   saveMemberDetails(memberDetails) ;
	
   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
	ifstream infile("Members.dat" ,ios::binary) ;
	MemberRecord current ;
	while(infile.read(reinterpret_cast<char*>(&current) ,sizeof(MemberRecord))){
		if(strcmp(idNumber ,current.idNumber)==0){
			return true ;
		}
	}
	infile.close() ;
	return false ;
}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{	
	ofstream outfile("Members.dat" ,ios::binary |ios::app) ;
	for(int i=0 ;i<memberDetails.size() ;i++){
		outfile.write(reinterpret_cast<const char*>(&memberDetails[i]) ,sizeof(MemberRecord)) ;
	}
	outfile.close() ;
}

void saveReservations( const vector< ReservationRecord > &reservations )
{
	ofstream outfile("Reservations.dat" ,ios::binary |ios::app) ;
	for(int i=0 ;i<reservations.size() ;i++){
		outfile.write(reinterpret_cast<const char*>(&reservations[i]) ,sizeof(ReservationRecord)) ;
	}
	outfile.close() ;
}