#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream infile("Members.dat", ios::in | ios::binary);

    if (!infile) {
        cout << "Cannot open Members.dat!";
        return;
    }

    MemberRecord temp;
    int numMembers = 0;
    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        memberDetails.push_back(temp);
    }

    infile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{   
    ifstream infile("Reservations.dat", ios::in | ios::binary);
    if (!infile) {
        cout << "Cannot open Rservations.dat!";
        return;
    }

    int numReservations = 0;
    Date currentDate = compCurrentDate();
    ReservationRecord temp2;
    while (infile.read(reinterpret_cast<char*>(&temp2), sizeof(ReservationRecord))) {
        reservations.push_back(temp2);
    }

    infile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{

    if (date2.year > date1.year) {
        return true;
    }
    else if (date2.year < date1.year) {
        return false;
    }
    else {
        if (date2.month > date1.month) {
            return true;
        }
        else if (date2.month < date1.month) {
            return false;
        }
        else {
            if (date2.day >= date1.day) {
                return true;
            }else{
                return false;
            }
        }
    }
    
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    bool found = false;
    
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0 &&
            strcmp(memberDetails[i].password, password) == 0) 
        {
            found = true;
            break;
        }
    }
    return found;
    
    

}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    Date currentDate = compCurrentDate();
    Date GoodDate[200];
    int numRes = 0;
    for (int i = 1; i <= 18; i++) {
        cout << "\n" << setw(2) << i << ". " << branchNames[i];
    }

    int userChoice;
    do {
        cout << "\nEnter your choice(0 to end): ";
        cin >> userChoice;
        if (userChoice == 0)
            break;
        newReservation.branchCode = userChoice;
    } while ((userChoice < 1 || userChoice>19) && userChoice != 0);

    cout << "The current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;
    compAvailableDates(GoodDate);
    int AvailableDaysChoice;
    int hourChoice;
    int startHour;
    int endHour = 23;
    int NumOfCustomers;
    do {
        cout << "\n" << "Enter your choice (0 to end): ";
        cin >> AvailableDaysChoice;
        if (AvailableDaysChoice == 0)
            break;
        for (int i = 1; i <= 7; i++) {
            if (AvailableDaysChoice == i) {
                newReservation.date = GoodDate[AvailableDaysChoice];
            }
        }
    } while ((AvailableDaysChoice < 1 || AvailableDaysChoice>7) && AvailableDaysChoice != 0);
    
    if (AvailableDaysChoice == 1) {
        startHour = currentDate.hour + 1;
    }
    else {
        startHour = 00;
    }
    do {
        cout << "\n" << "Enter hour(" << startHour << "~" << endHour << "): ";
        cin >> hourChoice;
        newReservation.date.hour = hourChoice;
    } while (hourChoice<startHour || hourChoice>endHour);

    do {
        cout << "\n" << "Enter the number of customers (1~30, 0 to end): ";
        cin >> NumOfCustomers;
        if (NumOfCustomers == 0)
            break;
        newReservation.numCustomers = NumOfCustomers;
    } while ((NumOfCustomers < 1 || NumOfCustomers>30) && NumOfCustomers != 0);

    for (int i = 0; i < 12; i++) {
        newReservation.idNumber[i] = idNumber[i];
    }
    
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    int daysInMonth[] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
    
    int displayYear = currentDate.year;
    int displayMonth = currentDate.month;
    int displayDay = currentDate.day;
    if (currentDate.hour == 23)
        displayDay++;
    if (displayYear % 400 == 0 || (displayYear % 4 == 0 || displayYear % 100 != 0)) {
        daysInMonth[2] = 29;
        if (displayDay > daysInMonth[currentDate.month]) {
            displayMonth++;
            displayDay = 1;
            if (displayMonth > 12) {
                displayYear++;
                displayMonth = 1;
            }
        }
    }
    else {
        if (displayDay > daysInMonth[currentDate.month]) {
            displayMonth++;
            displayDay = 1;
            if (displayMonth > 12) {
                displayYear++;
                displayMonth = 1;
            }
        }
    }
    
    
    
    
    cout << "\nAvailable days: \n";
    for (int i = 1; i <= 7; i++) {       
        cout<<"\n" << i << ". " << displayYear << "/" << displayMonth << "/" << displayDay;
        availableDates[i] = { displayYear,displayMonth,displayDay };
        displayDay++;
        if (displayYear % 400 == 0 || (displayYear % 4 == 0 || displayYear % 100 != 0)) {
            daysInMonth[2] = 29;
            if (displayDay > daysInMonth[currentDate.month]) {
                displayMonth++;
                displayDay = 1;
                if (displayMonth > 12) {
                    displayYear++;
                    displayMonth = 1;
                }
            }
        }
        else {
            if (displayDay > daysInMonth[currentDate.month]) {
                displayMonth++;
                displayDay = 1;
                if (displayMonth > 12) {
                    displayYear++;
                    displayMonth = 1;
                }
            }
        }
    }    
    
   
    


}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    loadReservations(reservations);
    int UserResNum = 0;
    ReservationRecord temp[200];
    int count[100] = {};
    int x = 1;
    for (int i = 0; i < reservations.size() - 1; i++) {
        if (strcmp(reservations[i].idNumber, idNumber) == 0) {
            UserResNum++;
            temp[UserResNum] = reservations[i];
            count[x] = i;
            x++;
        }
    }
    if (UserResNum == 0) {
        cout << "No reservations with this guy!";
        return;
    }
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;
    for (int i = 1; i <= UserResNum; i++) {
        cout << "\n" << i; output(temp[i]);
    }
    
    int No;
    do {
        cout<<"\n" << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> No;
        if (No == 0)
            break;
    } while ((No<1 || No>UserResNum) && No != 0);
    int p;
    for (int i = 0; i < reservations.size(); i++) {
        if (i == count[No]) {
            p = i;
        }
    }
    reservations[p] = {};
          
        
    

}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    bool found = false;

    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0 )
        {
            found = true;
            break;
        }
    }
    return found;


}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outfile("Members.dat", ios::out |ios::app| ios::binary);
    if (!outfile) {
        cout << "Cannot open Members.dat!(saveMe)";
        return;
    }

    outfile.seekp(0, ios::end);
    for (int i = 0; i < memberDetails.size(); i++) {
        outfile.write(reinterpret_cast<char*>(&MemberDetails[i]),sizeof(MemberRecord))
    }
    //outfile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord));
    outfile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outfile("Reservations.dat", ios::out | ios::app | ios::binary);
    if (!outfile) {
        cout << "Cannot open Reservations.dat!(saveRe)";
        return;
    }
    outfile.seekp(0, ios::end);
    
    //outfile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
    outfile.close();
}