#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}
//my
void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary | ios::in);//ok
    if (!inFile)
    {
        cout << "error in loadMemberDetails\n";
        return;
    }//ok
    MemberRecord temp;
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord)))
    {
        memberDetails.push_back(temp);
    }
    inFile.close();

}
//my
//Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::binary | ios::in);
    if (!inFile)
    {
        cout << "error in loadReservations\n";
        return;
    }
    ReservationRecord temp;
    Date now = compCurrentDate();
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord)))
    {
        if (!lessEqual(temp.date, now))
        {
            reservations.push_back(temp);
        }
    }

    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}
//my
//may be bug
bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year == date2.year)
    {
        if (date1.month == date2.month)
        {
            if (date1.day == date2.day)
            {
                return true;
            }
            else if (date1.day < date2.day)
                return true;
            else
                return false;
        }
        else if (date1.month < date2.month)
            return true;
        else
            return false;
    }
    else if (date1.year < date2.year)
        return true;
    else
        return false;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}
//my
bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    bool found = false;
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (!strcmp(memberDetails[i].idNumber, idNumber) && !strcmp(memberDetails[i].password, password))
        {
            found = true;
            break;
        }

    }

    if (!found)
        cout << "\nInvalid account number or password. Please try again.\n\n";
    return found;

}

//my
void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    Date now = compCurrentDate();
    int i = 0;
    for (; idNumber[i] != '\0'; i++)
    {
        newReservation.idNumber[i] = idNumber[i];
    }
    newReservation.idNumber[i] = '\0';//id

    for (int k = 1; k <= 18; k++)
    {
        cout << endl << setw(2) << k << ". " << branchNames[k];
    }
    cout << endl << endl;
    do
    {
        cout << "Enter your choice(0 to end) : ";
        cin >> newReservation.branchCode;
        cout << endl;
        if (newReservation.branchCode == 0)
        {
            cin.ignore();
            return;
        }
    } while (newReservation.branchCode < 1 || newReservation.branchCode>18);//branchCode
    cout << endl << "The current hour is " << now.year << "/" << now.month << '/' << now.day << ':' << now.hour << endl;//wait for compAvailableDates

    Date availableDates[7];
    compAvailableDates(availableDates);
    cout << "Available days:\n";
    for (int j = 0; j < 7; j++)
    {
        cout << j + 1 << ". " << availableDates[j].year << "/" << availableDates[j].month << '/' << availableDates[j].day << endl;
    }
    int choice = 0;
    cout << endl;
    do
    {
        cout << "Enter your choice(0 to end) :";
        cin >> choice;

        if (choice == 0)
        {
            cin.ignore();
            return;
        }
    } while (choice < 1 || choice>7);
    newReservation.date = availableDates[choice];//date
    int jhour = 0;
    int chour = 0;
    do
    {

        if (choice == 1)
        {
            if (now.hour == 23)
            {
                cout << "Enter hour (0~23): ";
                jhour = 0;
            }
            else
            {
                cout << "Enter hour (" << now.hour + 1 << "~23): ";
                jhour = now.hour + 1;
            }
        }
        else
            cout << "Enter hour (0~23): ";

        cin >> chour;
    } while (chour < jhour || chour>23);
    newReservation.date.hour = chour;//hour

    do
    {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> newReservation.numCustomers;
        if (newReservation.numCustomers == 0)
        {
            cin.ignore();
            return;
        }

    } while (newReservation.numCustomers < 1 || newReservation.numCustomers>30);//numCustomers



    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
    cin.ignore();

}
//my
void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    int y = currentDate.year;
    int m = currentDate.month;
    int d = currentDate.day;
    int h = currentDate.hour;
    int DIM[] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };

    if (h == 23)
        d++;

    bool leapyear = false;
    if ((y % 400 == 0) || (y % 4 == 0 && y % 100 != 0))
        leapyear = true;

    if (leapyear)
        DIM[2] = 29;

    for (int i = 0; i < 7; i++)
    {
        availableDates[i] = { y,m,d + i,0 };//input


        if (availableDates[i].day > DIM[availableDates[i].month])//day over
        {
            int a = DIM[availableDates[i].month];
            availableDates[i].month++;
            availableDates[i].day -= a;
        }

        if (availableDates[i].month > 12)//month over
        {
            availableDates[i].month -= 12;
            availableDates[i].year++;
        }
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}
//my
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)//copy output
{
    Date currentDate = compCurrentDate();
    int count = 0;

    for (int i = 0; i < reservations.size(); i++)
    {
        if (!strcmp(reservations[i].idNumber, idNumber))
        {
            count++;

        }
    }
    int countb = 0;
    if (count == 0)
    {
        cout << "\nNo reservations\n";
        return;
    }
    else
    {
        cout << endl << setw(29) << "Branch"
            << setw(14) << "Date" << setw(9) << "Hour"
            << setw(19) << "No of Customers" << endl;

        for (int i = 0; i < reservations.size(); i++)
        {
            for (int i = 0; i < reservations.size(); i++)
            {
                if (!strcmp(reservations[i].idNumber, idNumber))
                {
                    countb++;
                    cout << countb << ". " << setw(26) << branchNames[reservations[i].branchCode]
                        << setw(8) << reservations[i].date.year << '-'
                        << setw(2) << setfill('0') << reservations[i].date.month << "-"
                        << setw(2) << setfill('0') << reservations[i].date.day
                        << setw(8) << setfill(' ') << reservations[i].date.hour
                        << setw(19) << reservations[i].numCustomers << endl;
                }
            }
        }

    }



    int choose;
    do
    {
        cout << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> choose;
        cout << endl;
        if (choose == 0)
            cin.ignore();
        return;
    } while (choose<1 || choose>count);
    int countS = 0;
    for (int i = 0; i < reservations.size() - 1; i++)
    {
        if (!strcmp(reservations[i].idNumber, idNumber))
        {
            countS++;
            if (countS < choose)
                continue;
            else
                reservations[i] = reservations[i + 1];
        }
    }
    reservations.pop_back();
    cin.ignore();
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}
//my
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    bool found = false;
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (!strcmp(memberDetails[i].idNumber, idNumber))
            found = true;
    }
    return found;

}
//my
void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::binary | ios::out);
    if (!outFile)
    {
        cout << "error in saveMemberDetails\n";
        return;
    }
    outFile.clear();
    outFile.seekp(0, ios::beg);
    MemberRecord temp;
    for (int i = 0; i < memberDetails.size(); i++)
    {
        temp = memberDetails[i];
        outFile.write(reinterpret_cast<char*>(&temp), sizeof(MemberRecord));
    }
    outFile.close();
}
//my
void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::binary | ios::out);
    if (!outFile)
    {
        cout << "error in saveReservations\n";
        return;
    }
    outFile.clear();
    outFile.seekp(0, ios::beg);
    ReservationRecord temp;
    for (int i = 0; i < reservations.size(); i++)
    {
        temp = reservations[i];
        outFile.write(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord));
    }
    outFile.close();
}