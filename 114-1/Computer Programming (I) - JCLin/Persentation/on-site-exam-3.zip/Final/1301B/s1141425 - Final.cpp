#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile) {
        cout << "Error" << endl;
        return;
    }

    MemberRecord temp;
    while (inFile.read(reinterpret_cast<char*>(&memberDetails), sizeof(MemberRecord))) {
        memberDetails.push_back(temp);
    }
    inFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    
    ifstream inFile("Reservations.dat", ios::binary);
    if (!inFile) {
        cout << "Error" << endl;
        return;
    }

    ReservationRecord temp;
    while (inFile.read(reinterpret_cast<char*>(&reservations), sizeof(ReservationRecord))) {
        if(lessEqual(temp.date, currentDate));
        reservations.push_back(temp);
    }
    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    Date currentDate = compCurrentDate();
    
    if(date1.year <= date2.year){
        if (date1.month <= date2.month) {
            if (date1.day <= date2.day) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

/*if (!valid(idNumber, password, memberDetails)) {
                    cout << "Invalid account number or password.Please try again." << endl;
                }*/

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0) {
            if (strcmp(memberDetails[i].password, password) == 0) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    for (int i = 1; i <= 18; i++) {
        cout << setw(3) << i << "." << branchNames[i] << endl;
    }

    int choice;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice;
        if (choice == 0) {
            cin.ignore();
            return;
        }
    } while (choice > 18 || choice < 0);

    newReservation.branchCode ;

    Date currentDate = compCurrentDate();

    //snprintf(idNumber, 11, "%d/%d/%d", currentDate.year, currentDate.month, currentDate.day);
    cout << "\nThe current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << " " << currentDate.hour << endl;
    
    Date availableDates;
    compAvailableDates(availableDates[reservations]);

    int Availabledays;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> Availabledays;
        if (Availabledays == 0) {
            cin.ignore();
            return;
        }
    } while (Availabledays > 7 || Availabledays < 1);

    newReservation.date.year = currentDate.year;
    newReservation.date.month = currentDate.month;
    newReservation.date.day = currentDate.day;
    newReservation.date.hour = currentDate.hour;

    int hour;
    int midHour = currentDate.hour;
    do {
        cout << "\nEnter hour (" << midHour << "~23): ";
        cin >> hour;
    } while (hour < midHour || hour > 23);

    int customers = 0;
    do {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> customers;
        if (customers == 0) {
            cin.ignore();
            return;
        }
    } while (customers > 30 || customers < 1);

    strcpy_s(newReservation.idNumber, 12, branchNames[19]);

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    int nowMonthDays[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    
    bool leapyear = false;
    if (currentDate.year % 400 == 0 || currentDate.year % 4 == 0 && currentDate.year % 100 != 0) {
        leapyear = true;
        nowMonthDays[2] = 29;
    }
    else {
        leapyear = false;
    }

    int maxDay;
    for (int i = 1; i < 7; i++) {
        //another year
        if (availableDates[i].day == 31 && availableDates[i].month == 12) {
            availableDates[i].year++;
            availableDates[i].month == 1;
            availableDates[i].day == 1;
        }

        //another month
        if (availableDates[i].day > nowMonthDays[12]) {
            availableDates[i].month++;
            availableDates[i].day -= nowMonthDays[12];
        }
        
        cout << "\nAvailable days :\n";
        cout << i << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day;
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    
    if (reservations.empty()) {
        cout << "No reservations.";
        return;
    }

    int mach = 0;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(reservations[i].idNumber, idNumber) == 0) {
            mach++;
            cout << mach << ".";
            output(reservations[i]);
        }
    }

    int deleteindex = -1;
    do {
        cout << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> deleteindex;
        if (deleteindex == 0) {
            cin.ignore();
            return;
        }
    } while (deleteindex < 0 || deleteindex > mach);

    //delete vector
    for (int i = 0; i < reservations.size(); i++) {
        if (i != deleteindex) {
            reservations.push_back();
        }
    }
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (memberDetails[i].idNumber == idNumber) {
            return true;
        }
        else {
            return false;
        }
    }
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream ofFile("Members.dat", ios::app | ios::binary);
    if(!ofFile) {
        cout << "Error" << endl;
    }

    MemberRecord temp;
    while (ofFile.write(reinterpret_cast<const char*>(&temp), sizeof(MemberRecord))) {
        for (int i = 0; i < sizeof(MemberRecord); i++) {
            memberDetails.push_back(temp);;
        }
    }
    ofFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream ofFile("Reservations.dat", ios::app | ios::binary);
    if (!ofFile) {
        cout << "Error" << endl;
    }

    ReservationRecord temp;
    while (ofFile.write(reinterpret_cast<const char*>(&temp), sizeof(ReservationRecord))) {
        reservations.push_back(temp);;
    }
    ofFile.close();
}