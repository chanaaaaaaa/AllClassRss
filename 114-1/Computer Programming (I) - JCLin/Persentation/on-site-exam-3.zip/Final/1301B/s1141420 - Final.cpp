#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
        if (!inFile)
        {
            cout << "Members.dat could not be opened." << endl;
            exit(1);
        }
    vector< MemberRecord > temp;
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(vector< MemberRecord >)))
        memberDetails = temp;
    inFile.close();

}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservation.dat", ios::in | ios::binary);
    if (!inFile)
    {
        cout << "Reservation.dat could not be opened." << endl;
        exit(1);
    }
    vector< ReservationRecord > temp;
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(vector< ReservationRecord >)))
        reservations = temp;
    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year)
        return true;
    else if (date1.month < date2.month)
        return true;
    else if (date1.day < date2.day)
        return true;
    else if (date1.hour < date2.hour)
        return true;
    else
        return false;

}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i <= 12; i++)
        if (idNumber[i] != memberDetails.idNumber[i])
        {
            cout << endl << "Invalid account number or password. Please try again." << endl;
            return false;
        }        
    for (int i = 0; i <= 24; i++)
        if (password[i] != memberDetails.password[i])
        {
            cout << endl << "Invalid account number or password. Please try again." << endl;
            return false;
        }
    return true;

}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    Date currentDate = compCurrentDate();
    cout << endl;
    for(int i = 0; i < 18; i++)
        cout << i + 1 << ". " << branchNames[i] << endl;
    cout << endl << "Enter your choice (0 to end): ";
    int choice;
    cin >> choice;
    if (choice == 0 || choice > 18)
        return;
    cout << endl << endl << "The current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;
    cout << endl << "Available days:" << endl << endl;
    compAvailableDates(&currentDate);
      
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[]) 
{
    Date currentDate = compCurrentDate();
    int maxDay[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    if (currentDate.month == 2 && (currentDate.year % 400 == 0 || (currentDate.year % 4 == 0 && currentDate.year % 100 != 0)))
        maxDay[3] = 29;
    int selectYear[8], selectMonth[8], selectDay[8];
    if (currentDate.hour >= 23)
        currentDate.day += 1;
    for (int i = 1; i <= 7; i++)
    {
        selectYear[i] = currentDate.year;
        selectMonth[i] = currentDate.month;
        selectDay[i] = currentDate.day + 1;
        if (currentDate.day > maxDay[selectMonth[i]])
        {
            selectDay[i] -= maxDay[selectMonth[i]];
            selectMonth[i]++;
        }
        if (selectMonth[i] > 12)
        {
            selectMonth[i] -= 12;
            selectYear[i]++;
        }
        cout << i << ". " << selectYear[i] << "/" << selectMonth[i] << "/" << selectDay[i] << endl;
    }

    cout << endl << "Enter your choice (0 to end): ";
    int choice1;
    cin >> choice1;
    if (choice1 == 0 || choice1 > 7)
        return;
    int selectHour = 0;
    if (currentDate.year == selectYear[choice1 - 1] && currentDate.month == selectMonth[choice1 - 1] && currentDate.day == selectDay[choice1 - 1])
        selectHour = currentDate.hour + 1;

    cout << endl << endl << "Enter hour (" << selectHour << "~23): ";
    int choice2;
    cin >> choice2;
    if (choice2 < selectHour || choice2 > 23)
        return;
    cout << endl << endl << "Enter the number of customers (1~30, 0 to end): ";
    int choice3;
    cin >> choice3;
    if (choice3 == 0 || choice3 > 30)
        return;
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    ofstream outFile("Reservations.dat", ios::out | ios::binary);
    if (!outFile)
    {
        cout << endl << "No reservations!" << endl;
        return;
    }
    if (lessEqual(reservations.date, currentDate))
        return;
    else
        cout << endl;
    cout << endl << "Choose a reservation to cancel (0: keep all reservations): ";
    int choice;
    cin >> choice;
    while (choice > numReservation)
    {
        cout << endl << "Choose a reservation to cancel (0: keep all reservations): ";
        int choice;
        cin >> choice;
    }
    return;
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    cout << endl << "Input your ID Number: ";
    int number;
    cin >> number;
    cout << endl;
    if (number == memberDetails.idNumber)
        return true;
    else
        return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::out | ios::binary);
    if (!outFile)
    {
        cout << "Members.dat could not be opened." << endl;
        exit(1);
    }
    vector< MemberRecord > temp;
    outFile.write(reinterpret_cast<char*>(&temp), sizeof(vector< MemberRecord >));
    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservation.dat", ios::out | ios::binary);
    if (!outFile)
    {
        cout << "Reservation.dat could not be opened." << endl;
        exit(1);
    }
    vector< ReservationRecord > temp;
    outFile.write(reinterpret_cast<char*>(&temp), sizeof(vector< ReservationRecord >));
    outFile.close();
}