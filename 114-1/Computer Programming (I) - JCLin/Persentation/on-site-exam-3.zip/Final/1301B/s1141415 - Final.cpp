#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream MemDetail("Members.dat", ios::binary);
    if (!MemDetail) {
        cout << "File could not be opened." << endl;
    }

    MemberRecord temp = {};
    while (MemDetail.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        memberDetails.push_back(temp);
    }
    MemDetail.close();
}

void loadReservations(vector< ReservationRecord >& reservations) //no show of past date
{ 
    ifstream ReserData("Reservations.dat", ios::binary);
    if (!ReserData)
        cout << "File could not be opened." << endl;

    ReservationRecord temp = {};
    while (ReserData.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord))) {
        if (!lessEqual(temp.date, compCurrentDate()))
            reservations.push_back(temp);
    }
    ReserData.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2) //1<=2 true
{
    if (date1.year > date2.year) //year 1>2
        return false;
    else if (date1.year == date2.year) { // year 1=2 
        if (date1.month > date2.month)
            return false;
        else if (date1.month == date2.month) {// year 1=2 & month 1=2
            if (date1.day >= date2.day)
                return false;
            /*else if (date1.day == date2.day) {
                if (date1.hour > date2.hour)
                    return false;
                else //year 1=2 & month 1=2 & day 1=2 & hour 1<=2
                    return true;
            }*/
            else //year 1=2 & month 1=2 & day 1<=2
                return true; 
        }
        else //year 1=2 & month 1<2
            return true;
    }
    else //year1<2
                return true;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails) //exist->true
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber,memberDetails[i].idNumber)==0 && strcmp(password,memberDetails[i].password)==0)
            return true;
    }

    cout << endl << "Invalid account number or password. Please try again." << endl << endl;
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    strcpy_s(newReservation.idNumber, idNumber);

    //Branch
    cout << endl;
    for (int i = 1; i <= 18; i++)
        cout << setw(2)<<i << ". " << branchNames[i] << endl;

    int selectBranch;
    do {
        cout << endl << "Enter your choice (0 to end): ";
        cin >> selectBranch;
    } while (selectBranch < 0 || selectBranch>18);
    newReservation.branchCode = selectBranch;
    cin.ignore();

    //Date
    Date Datenow = compCurrentDate();
    cout << endl << "The current hour is " << Datenow.year << "/" << Datenow.month << "/" << Datenow.day << ":" << Datenow.hour << endl;
    cout << endl << "Available days:" << endl << endl;

    Date availableDates[8] = {};//availableDates[0] always stays empty.
    compAvailableDates(availableDates);
    Date select;
    int selectDate;
    do {
        cout << endl << "Enter your choice (0 to end): ";
        cin >> selectDate;
    } while (selectDate < 0 || selectDate>7);
    cin.ignore();
    if (selectDate == 0)
        return;
    select = availableDates[selectDate];
    int selectHour;
    int showHours;
    if (selectDate == 1)
        showHours = availableDates[1].hour + 1;
    else
        showHours = 0;
    do {
        cout << endl << "Enter hour (" << showHours << "~23): ";
        cin >> selectHour;
    } while (selectHour < showHours || selectHour>23);
    cin.ignore();
    select.hour = selectHour;
    newReservation.date = select;

    //Customers
    do {
        cout << endl<< "Enter the number of customers (1~30, 0 to end): ";
        cin >> newReservation.numCustomers;
    } while (newReservation.numCustomers < 0 || newReservation.numCustomers>30);
    cin.ignore();
    if (newReservation.numCustomers == 0) {
        return;
    }

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    bool specialyear = false;
    if (currentDate.year % 400 == 0)
        specialyear = true;
    else if (currentDate.year % 4 == 0) {
        if (currentDate.year % 100 != 0)
            specialyear = true;
    }
    else
        specialyear = false;

    int maxDate[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
    if (specialyear)
        maxDate[1] = 29;

    if (currentDate.hour == 23) {
        currentDate.day++;
        currentDate.hour == -1; //currenthour cant be booked, later will +1.
        if (currentDate.day > maxDate[currentDate.month - 1]) {
            currentDate.month++;
            currentDate.day = 1;
            if (currentDate.month > 12) {
                currentDate.year++;
                currentDate.month = 1;
            }
        }
    }

    int choice = 1;
    cout << choice << ". " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << endl; 
    availableDates[choice] = currentDate;
    for (choice = 2; choice <= 7; choice++) {
        if (currentDate.day + 1 > maxDate[currentDate.month - 1]) {
            currentDate.month++;
            currentDate.day = 1;
            if (currentDate.month > 12) {
                currentDate.year++;
                currentDate.month = 1;
            }
        }
        else
            currentDate.day++;
        cout << choice << ". " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << endl;
        availableDates[choice] = currentDate;
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    vector<int> aPersonReservation; 
    int Case = 0;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(reservations[i].idNumber, idNumber)==0) {
            Case++;
            aPersonReservation.push_back(i);
        }
    }

    if (Case == 0) {
        cout << "No reservations!" << endl;
        return;
    }
    cout << endl << setw(28) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    for (int x = 1; x <= Case; x++) {
        cout << x << ".";
        output(reservations[aPersonReservation[x-1]]);

    }
    int choice;
    do {
        cout << endl << "Choose a reservation to cancel(0: keep all reservations) :";
        cin >> choice;
    } while (choice<0 || choice>Case);
    cin.ignore();

    if (choice == 0) {
        return;
    }

    int j = 0;
    for (int i = 0; i < reservations.size(); i++) {
        if (i != aPersonReservation[choice-1]) {
            reservations[j] = reservations[i];
            j++;
        }
    }
    reservations.pop_back();
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++)
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
            return true;
    
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream saveMemData("Members.dat", ios::binary);
    if (!saveMemData)
        cout << "File could not be opened." << endl;

    for (int i = 0; i < memberDetails.size(); i++) {
        saveMemData.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord));
    }
    saveMemData.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream saveResData("Reservations.dat", ios::binary);
    if(!saveResData)
        cout << "File could not be opened." << endl;

    for (int i = 0; i < reservations.size(); i++) {
        saveResData.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
    }
    saveResData.close();
}