#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile) {
        cout << "cant not read Members.dat\n";
        return;
    }
    MemberRecord mr;
    while (inFile.read(reinterpret_cast<char*>(&mr), sizeof(MemberRecord))) {
        memberDetails.push_back(mr);
    }
    inFile.close();
        
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::binary);
    if (!inFile) {
        cout << "cant not read Members.dat\n";
        return;
    }
    ReservationRecord resRecord;
    while (inFile.read(reinterpret_cast<char*>(&resRecord), sizeof(ReservationRecord))) {
        reservations.push_back(resRecord);
    }
    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year) {
        return true;
    }
    else if(date1.year > date2.year){
        return false;
    }
    //�P�~-------------
    if (date1.month < date2.month) {
        return true;
    }
    else if(date1.month > date2.month){
        return false;
    }
    //�P��-------------
    if (date1.day < date2.day) {
        return true;
    }
    else if (date1.day > date2.day) {
        return false;
    }
    //�P��-----------
    return true;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); ++i) {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0 &&
            strcmp(memberDetails[i].password, password) == 0) {
            return true;
        }
    }
    cout << "\nInvalid account number or password. Please try again.\n\n";
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    for (int i = 1; i <= 18; ++i) {
        cout << setw(2) << std::right << i << ". " << branchNames[i] << endl;
    }
    int choiceBranchCode;
    do {
        cout << "\nEnter your choice (0 to end): ";
        choiceBranchCode = inputAnInteger(0, 18);
        if (choiceBranchCode == 0)return;
    } while (choiceBranchCode < 1 || choiceBranchCode > 18);
    
    Date availableDates[8]; //����1~7
    compAvailableDates(availableDates);
    
    int choiceDate;
    do {
        cout << "\nEnter your choice (0 to end): ";
        choiceDate = inputAnInteger(0, 7);
        if (choiceDate == 0)return;
    } while (choiceDate < 1 || choiceDate > 7);


    int choiceHour;
    do {
        if (choiceDate == 1) {
            cout << "\nEnter hour (" << availableDates[1].hour << "~23): ";
        }
        else {
            cout << "\nEnter hour (" << availableDates[choiceDate].hour << "~23): ";
        }
    } while ((choiceHour = inputAnInteger(availableDates[choiceDate].hour, 23)) == -1);
    Date temp = availableDates[choiceDate];//��ܪ����
    temp.hour = choiceHour;
    int numCustomers;
    do {      
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        numCustomers = inputAnInteger(0, 30);
        if (numCustomers == 0)return;
    } while (numCustomers < 1 || numCustomers > 30);

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;
    strcpy(newReservation.idNumber, idNumber);
    newReservation.numCustomers =  numCustomers;
    newReservation.date = temp;
    newReservation.branchCode = choiceBranchCode;
    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
  /*  currentDate.year = 2026;
    currentDate.month = 1;
    currentDate.day = 1;
    currentDate.hour = 18;*/
    cout << "\nThe current hour is " << currentDate.year << "/" <<
        currentDate.month << "/" <<
        currentDate.day << ":" <<
        currentDate.hour << endl;

    cout << "\nAvailable days:\n\n";
    Date temp = currentDate;

    int daysInMonths[] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
    if (temp.hour == 23) {
        if (temp.year % 400 == 0 || (temp.year % 4 == 0 && temp.year % 100 != 0))
            daysInMonths[2] = 29;
        else
            daysInMonths[2] = 28;
        if (temp.day == daysInMonths[temp.month]) {
            //�O�Ӥ�̫�@��
            if (temp.month == 12) {
                temp.year++;
                temp.month = 1;
                temp.day = 1;
            }
            else {
                temp.month++;
                temp.day = 1;
            }
        }
        else {
            temp.day++;
        }
        temp.hour = 0;
    }
    else {
        temp.hour++;
    }
    for (int i = 1; i <= 7; ++i) {
        cout << i << ". " << temp.year << "/" << temp.month << "/" << temp.day << endl;
        availableDates[i] = temp;
        if (temp.year % 400 == 0 || (temp.year % 4 == 0 && temp.year % 100 != 0))
            daysInMonths[2] = 29;
        else
            daysInMonths[2] = 28;
        if (temp.day == daysInMonths[temp.month]) {
            //�O�Ӥ�̫�@��
            if (temp.month == 12) {
                temp.year++;
                temp.month = 1;
                temp.day = 1;
            }
            else {
                temp.month++;
                temp.day = 1;
            }
        }
        else {
            temp.day++;
        }
        temp.hour = 0;
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
 /*   currentDate.year = 2026;
    currentDate.month = 1;
    currentDate.day = 1;
    currentDate.hour = 18;*/
   
    //////////////////////////////////////////
    //�R���ثe����e������
    vector<int> idxToDelete(reservations.size());//1 3 5
    int idxSize = 0;
    for (int i = 0; i < reservations.size(); ++i) {
        Date d = reservations[i].date;
        if (!lessEqual( currentDate,d)) {
            idxToDelete[idxSize] = (i);
            idxSize++;
        }
    }
    if (idxSize != 0) {
        vector<ReservationRecord> tempRes;
        int t = 0;
        for (int i = 0; i < reservations.size(); ++i) {
            if (i == idxToDelete[t]) {
                t++;
            }
            else {
                tempRes.push_back(reservations[i]);
            }
        }
        reservations = tempRes;
    }

    //////////////////////////////////////////
    bool found = false;
    for (int i = 0; i < reservations.size(); ++i) {
        if (strcmp(reservations[i].idNumber, idNumber) == 0) {
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "No reservations!\n";
        return;
    }
    cout << endl << setw(28) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;
    int numRes = 0;
    int cnt = 1;
    for (int i = 0; i < reservations.size(); ++i) {
        if (strcmp(reservations[i].idNumber, idNumber) == 0) {
            cout << cnt++ << ".";
            output(reservations[i]);
            numRes++;
        }
    }
    int choice;
    do {
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
        choice = inputAnInteger(0, numRes);
        if (choice == 0)return;
    } while (choice < 1 || choice > numRes);

    int realidx = -1;
    int k = 0;
    for (int i = 0; i < reservations.size(); ++i) {
        if (strcmp(reservations[i].idNumber, idNumber) == 0) {
            k++;
            if (k == choice) {
                realidx = i;
                break;
            }
        }
    }
    //    mine choice
    //0
    //1    _      1
    //2
    //3    _      2
    vector<ReservationRecord> newRes;
    for (int i = 0; i < reservations.size(); ++i) {
        if (i != realidx) {
            newRes.push_back(reservations[i]);
        }
    }
    reservations = newRes;
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); ++i) {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0) {
            return true;
        }
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::binary);
    if (!outFile) {
        cout << "\ncan not save Members.dat\n";
        return;
    }
    for (int i = 0; i < memberDetails.size(); ++i) {
        outFile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::binary);
    if (!outFile) {
        cout << "\ncan not save Reservations.dat\n";
        return;
    }
    for (int i = 0; i < reservations.size(); ++i) {
        outFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }
    outFile.close();
}