#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile) return;
    MemberRecord temp;
    inFile.seekg(0, ios::beg);
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        memberDetails.push_back(temp);
    }
    inFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::binary);
    if (!inFile) return;
    ReservationRecord temp;
    inFile.seekg(0, ios::beg);
    Date currentDate = compCurrentDate();
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord))) {
        if (lessEqual(temp.date, currentDate)) {
            reservations.push_back(temp);
        }
    }
    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year == date2.year) {
        if (date1.month == date2.month) {
            if (date1.day >= date2.day) return 1;
        }
        else if (date1.month > date2.month) return 1;
    }
    else if (date1.year > date2.year) return 1;
    return 0;
}

int inputAnInteger(int begin, int end)
{

    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);


    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 && strcmp(password, memberDetails[i].password) == 0) {
            return 1;
        }
    }
    cout << "\nInvalid account number or password. Please try again.\n\n";
    return 0;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    Date temp[9];
    for (int i = 1; i < 19; i++) {
        cout << i << ". " << branchNames[i] << endl;
    }
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> newReservation.branchCode;

    } while (newReservation.branchCode > 18 || newReservation.branchCode < 0);
    if (newReservation.branchCode == 0) {
        cin.ignore();
        return;
    }

    compAvailableDates(temp);
    Date currentDate = compCurrentDate();
    if (currentDate.hour == 23) {
        for (int i = 1; i < 8; i++) {
            temp[i] = temp[i + 1];
        }
    }
    for (int i = 1; i < 8; i++) {
        cout << i << ". " << temp[i].year << "/" << temp[i].month << "/" << temp[i].day << ":" << endl;
    }
    int choose = 0;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choose;
    } while (choose < 0 || choose > 7);
    if (choose == 0) {
        cin.ignore();
        return;
    }
    newReservation.date.year = temp[choose].year;
    newReservation.date.month = temp[choose].month;
    newReservation.date.day = temp[choose].day;
    do {
        cout << "\nEnter hour (" << temp[choose].hour << "~23): ";
        cin >> newReservation.date.hour;
    } while (newReservation.date.hour < temp[choose].hour || newReservation.date.hour > 23);
    do {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> newReservation.numCustomers;
    } while (newReservation.numCustomers < 0 || newReservation.numCustomers > 30);
    if (newReservation.numCustomers == 0) {
        cin.ignore();
        return;
    }
    strncpy_s(newReservation.idNumber, 12, idNumber, 12);

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
    cin.ignore();
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    cout << "\nThe current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;
    cout << "\nAvailable days:\n\n";
    int maxday[] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
    if ((currentDate.year % 400) == 0 || ((currentDate.year % 4) == 0 && (currentDate.year % 100) != 0)) {
        maxday[2] = 29;
    }
    int year = currentDate.year;
    int month = currentDate.month;
    int day = currentDate.day;
    int hour = currentDate.hour;
    bool firstm = true;
    bool firsty = true;
    for (int i = 1; i < 9; i++) {
        availableDates[i].year = year;
        availableDates[i].month = month;
        availableDates[i].day = day;
        if (i == 1) availableDates[i].hour = currentDate.hour + 1;
        else availableDates[i].hour = 0;
        day = (day + 1 > maxday[month]) ? 1 : day + 1;
        if (currentDate.day + i > maxday[month]) {
            if (firstm) {
                month++;
                firstm = false;
            }
        }
        if (month > 12) month = 1;
        if (currentDate.day + i > maxday[month]) {
            if (currentDate.month + 1 > 12 && firsty) {
                year++;
                if ((year % 400) == 0 || ((year % 4) == 0 && (year % 100) != 0)) {
                    maxday[2] = 29;
                }
                else maxday[2] = 28;
                firsty = false;
            }
        }
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    int count = 0;
    int sum = 0;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(idNumber, reservations[i].idNumber) == 0 && lessEqual(reservations[i].date, currentDate)) {
            sum++;
        }
    }
    if (sum == 0) {
        cout << "No reservations!\n";
        return;
    }
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(idNumber, reservations[i].idNumber) == 0 && lessEqual(reservations[i].date, currentDate)) {
            cout << ++count << ".";
            output(reservations[i]);
        }
    }
    int choose;
    do {
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
        cin >> choose;
    } while (choose < 0 || choose>count);
    if (choose == 0) {
        cin.ignore();
        return;
    }
    int cnt = 0;
    int index = -1;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(idNumber, reservations[i].idNumber) == 0 &&
            lessEqual(reservations[i].date, currentDate) &&
            ++cnt == choose) {
            index = i;
        }
    }
    vector< ReservationRecord > temp(reservations.size());
    for (int i = 0, j = 0; i < reservations.size(); i++) {
        if (i != index) {
            temp[j] = reservations[i];
            j++;
        }
    }
    reservations.clear();
    for (int i = 0, j = 0; i < temp.size(); i++) {
        reservations.push_back(temp[i]);
    }
    cin.ignore();
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {
            return 1;
        }
    }
    return 0;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::binary);
    if (!outFile) return;
    outFile.seekp(0, ios::beg);
    for (int i = 0; i < memberDetails.size(); i++) {
        outFile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::binary);
    if (!outFile) return;
    outFile.seekp(0, ios::beg);
    for (int i = 0; i < reservations.size(); i++) {
        outFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }
    outFile.close();
}