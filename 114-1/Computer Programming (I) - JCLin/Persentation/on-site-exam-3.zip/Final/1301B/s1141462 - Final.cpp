#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    if (!inFile) {
        cout << "can't load Members.dat" << endl;
        return;
    }

    MemberRecord temp;

    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        memberDetails.push_back(temp);
    }
    inFile.close();



}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream inFile("Reservations.dat", ios::in | ios::binary);
    if (!inFile) {
        cout << "can't load Reservations.dat" << endl;
        return;
    }

    Date cur = compCurrentDate();

    ReservationRecord temp;
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord))) {
        if (!lessEqual(temp.date, cur)) {//temp.date>cur
            reservations.push_back(temp);
        }
    }
    inFile.close();



}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    bool less = false;
    tm dt1 = {};
    tm dt2 = {};

    dt1.tm_year = date1.year - 1900;
    dt1.tm_mon = date1.month - 1;
    dt1.tm_mday = date1.day;
    dt1.tm_hour = 0;

    dt2.tm_year = date2.year - 1900;
    dt2.tm_mon = date2.month - 1;
    dt2.tm_mday = date2.day;
    dt2.tm_hour = 0;

    time_t dt1Sec = mktime(&dt1);
    time_t dt2sec = mktime(&dt2);

    double diff = difftime(dt2sec, dt1Sec);

    int timeDiff = static_cast<int>(diff / 86400);

    if (timeDiff > 0) {
        less = true;
        return less;
    }
    else
        return less;




}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    bool found = false;
    for (int i = 0; i < memberDetails.size(); i++){
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 && strcmp(password, memberDetails[i].password) == 0) {
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "\nInvalid account number or password. Please try again.\n"<<endl;
    }

    return found;





}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;
   int choicePlace;
   
   for (int i = 1; i < 19; i++) {
       cout << i << ". " << branchNames[i] << endl;

   }

   do {

       cout << "\nEnter your choice (0 to end): ";
       cin >> choicePlace;

       if (choicePlace == 0) {
           return;
       }
   
   
   
   } while (choicePlace < 1 || choicePlace>18);

   Date cur = compCurrentDate();

   cout << "\nThe current hour is "<<cur.year<<'/' << cur.month <<'/' << cur.day <<':' << cur.hour<<endl;

   cout << "\nAvailable days:\n";

   int daysInMonth[] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };

   //400�����ƬO�|�~�A100�����Ʀ����O400�����ƬO���~�A4�����Ʀ����O100�����ƬO�|�~
   if (cur.year % 400 == 0 || (cur.year % 4 == 0 && cur.year % 100 != 0)) {//�P�_�O�_�O�|�~
       daysInMonth[2] = 29;
   
   }
   cout << endl;
   for (int i = 1; i <= 7; i++) {
      Date show;
      show.hour = cur.hour+1;
      show.day = cur.day+i-1;
      show.month = cur.month;
      show.year = cur.year;

      if (show.hour > 23) {
          show.hour %= 23;
          show.day++;
      }
      if (show.day>daysInMonth[show.month]) {
          show.day %= daysInMonth[show.month];
          show.month++;
      }

      if (show.month > 12) {
          show.month %= 12;
          show.year++;
      }


      cout << i << ". " << show.year << '/' << show.month << '/' << show.day << endl;
      

   }

   int choiceDay;
   do {
       cout << "\nEnter your choice (0 to end): ";
       cin >> choiceDay;
       if (choiceDay == 0) {
           return;
       }

   } while(choiceDay<1 || choiceDay>7);

   Date choiceDate;
   choiceDate.hour = cur.hour + 1;
   choiceDate.day = cur.day + choiceDay-1;
   choiceDate.month = cur.month;
   choiceDate.year = cur.year;
   if (choiceDate.hour> 23) {
       choiceDate.hour -= 24;
       choiceDate.day++;
   }
   if (choiceDate.day > daysInMonth[choiceDate.month]) {
       choiceDate.day %= daysInMonth[choiceDate.month];
       choiceDate.month++;
   }

   if (choiceDate.month > 12) {
       choiceDate.month %= 12;
       choiceDate.year++;
   }


   Date choice;
   choice.hour = cur.hour + 1;

   int maxHour = 23;
   int minHour = 0;
   if (choiceDay == 1) {
       if (cur.hour + 1 < 23)
           minHour = cur.hour + 1;
   }

   if (choiceDay == 7) {
       if (maxHour > cur.hour + 1) {
           maxHour = cur.hour + 1;
       }

   }

   int choiceHour;
   do {
       cout << "\nEnter hour ("<<minHour<<"~"<<maxHour<<"): ";
       cin >> choiceHour;

   } while (choiceHour<minHour || choiceHour>maxHour);

   choiceDate.hour = choiceHour;

   int numOfCustomers;

   do {
       cout << "\nEnter the number of customers (1~30, 0 to end): ";
       cin >> numOfCustomers;

       if (numOfCustomers == 0) {
           return;
       }

   } while (numOfCustomers > 30 || numOfCustomers < 1);


   newReservation.branchCode = choicePlace;
   newReservation.date =choiceDate;
   newReservation.numCustomers = numOfCustomers;
   strcpy_s(newReservation.idNumber, 12, idNumber);









   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );

}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();

   int daysInMonth[] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };

   //400�����ƬO�|�~�A100�����Ʀ����O400�����ƬO���~�A4�����Ʀ����O100�����ƬO�|�~
   if (currentDate.year % 400 == 0 || (currentDate.year % 4 == 0 && currentDate.year % 100 != 0)) {//�P�_�O�_�O�|�~
       daysInMonth[2] = 29;


   for (int i = 1; i <= 7; i++) {
       availableDates[i].year = currentDate.year;
       availableDates[i].month = currentDate.month;
       availableDates[i].day = currentDate.day+i-1;
       availableDates[i].hour = currentDate.hour+1;
           if (availableDates[i].hour > 23) {
               availableDates[i].hour -= 24;
               availableDates[i].day++;
           }
           if (availableDates[i].day > daysInMonth[availableDates[i].month]) {
               availableDates[i].day %= daysInMonth[availableDates[i].month];
               availableDates[i].month++;
           }

           if (availableDates[i].month > 12) {
               availableDates[i].month %= 12;
               availableDates[i].year++;
           }
       }
   }









}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();
   int cnt = 0;
   int matchCount = 0;
   int targetIndex = -1;
   int choice;
   bool found = false;

   do {
       for (int i = 0; i < reservations.size(); i++) {
           if (strcmp(reservations[i].idNumber, idNumber) == 0) {
               cnt++;
               found = true;
               cout << "\n" << cnt << ".";
               output(reservations[i]);

           }
       }
       if (!found) {
           cout << "No reservations!" << endl;
           return;
       }
       cout << "Choose a reservation to cancel (0: keep all reservations): ";
       cin >> choice;


   } while ((choice<matchCount && choice!=0) || choice>matchCount || !found);
   
   if (choice == 0)
       return;

   for (int i = 0; i < reservations.size(); i++) {
       if (strcmp(reservations[i].idNumber, idNumber) == 0) {
           matchCount++;

           if (matchCount = choice) {
               targetIndex = i;
           }
       }
   }
   //if (targetIndex != -1) {
       //reservations.erase(reservations[targetIndex]);
   
   //}






}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    bool found = false;
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {
            found = true;
            break;
        }
    }
    return found;



}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream outFile("Members.dat", ios::out | ios::binary | ios::app);
    if (!outFile) {
        cout << "can't save Members.dat" << endl;
        return;
    }

    if (outFile) {
        for (int i = 0; i < memberDetails.size(); i++) {
            outFile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
        }
    }
    outFile.close();


}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream outFile("Reservations.dat", ios::out | ios::binary | ios::app);
    if (!outFile) {
        cout << "can't save Reservations.dat" << endl;
        return;
    }

    if (outFile) {
        for (int i = 0; i < reservations.size(); i++) {
            outFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
        }
    }
    outFile.close();




}