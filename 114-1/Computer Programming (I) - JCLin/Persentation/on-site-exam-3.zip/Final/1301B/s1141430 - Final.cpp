#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile) {
        cout << "file fail";
        return;
    }
    MemberRecord temp;
    int count = 0;
    memberDetails.clear();
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        memberDetails[count++] = temp;
    }
    inFile.close();

}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::binary);
    if (!inFile) {
        cout << "file fail";
        return;
    }
    ReservationRecord temp;
    int count = 0;
    reservations.clear();
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord))) {
        reservations[count++] = temp;
    }
    inFile.close();



}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}
// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{
    Date currentDate = compCurrentDate();
    




}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}
// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    vector< MemberRecord >member;
    loadMemberDetails(member);
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile) {
        cout << "gg";
        return false;
    }
    MemberRecord temp;
    int count = 0;
    bool found = false;
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        if (strcmp(idNumber, temp.idNumber) == 0 && strcmp(password,temp.password)==0) {
            found = true;
            count++;
            return true;
        }
        else return false;

    }

    inFile.close();
    
}
// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    Date currentDate = compCurrentDate();
    ifstream read("Reservations.dat",ios::binary);
    bool vaild = false;
    int count = 0;
    ReservationRecord temp;
    branchNames;
    for (int i = 1; i <= 18; i++) {
        cout << i << ". " << branchNames[i] << endl;
    }
    int selectedbranch = 0;
    do {
        
        vaild = false;
        cout << "Enter your choice (0 to end): ";
        cin >> selectedbranch;
        
        cout << endl;
        if (selectedbranch > 0 && selectedbranch <= 18) {
            vaild = true;
            newReservation.branchCode = selectedbranch;
        }
        else if (selectedbranch == 0) {
            
        }
        else {
            vaild = false;
        }
    } while (!vaild);

    int displayyear = currentDate.year;
    int displaymonth = currentDate.month;
    int displayday = currentDate.day;
    int displayhour = currentDate.hour;
    char dayinmonth[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
    cout << "The current hour is " << displayyear << "/" << displaymonth << "/" << displayday << ": " << displayhour << endl;
    cout << "\nAvailable days:" << endl << endl;

    for (int i = 0; i <= 6; i++) {
        cout << i + 1 << ". " << displayyear << "/" << displaymonth << "/" << displayday + i << endl;
    }
    int selectedday = 0;
    do {
        cout << "Enter your choice (0 to end): ";
        cin >> selectedday;
        newReservation.date.year = displayyear;
        newReservation.date.month = displaymonth;
        newReservation.date.day = displayday + selectedday - 1;
        if (newReservation.date.day > dayinmonth[newReservation.date.month]) {
            newReservation.date.day -= dayinmonth[newReservation.date.month];
            newReservation.date.month++;
            if (newReservation.date.month > 12) {
                newReservation.date.month -= 12;
                newReservation.date.year++;
            }
        }
        
    } while (selectedday > 7 || selectedday < 1);

    int selectedhour = 0;
    int minhour = currentDate.hour + 1;
    if (minhour > 23) {
        minhour -= 23;
    }
    int maxhour = 23;
    do {
        cout << "Enter hour (" << minhour << "~" << maxhour << "): ";
        cin >> selectedhour;
        cout << endl;
        newReservation.date.hour = selectedhour;
    } while (selectedhour < minhour || selectedhour > maxhour);

    int choosenum;
    do {
        cout << "Enter the number of customers (1~30, 0 to end): ";
        cin >> choosenum;
        cout << endl;
        newReservation.numCustomers = choosenum;
        if (choosenum == 0) {
            break;
        }
    } while (choosenum < 0 || choosenum > 30);


    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}
// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    tm start = { 0 }, end{ 0 };
    start.tm_year = currentDate.year;
    start.tm_mon = currentDate.month;
    start.tm_mday = currentDate.day;
    start.tm_hour = currentDate.hour;

    end.tm_year = currentDate.year;
    end.tm_mon = currentDate.month;
    end.tm_mday = currentDate.day + 7;
    end.tm_hour = currentDate.hour;

    char dayinmonth[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };

    if (end.tm_mday > dayinmonth[end.tm_mon]) {
        end.tm_mon++;
        end.tm_mday -= dayinmonth[end.tm_mon];
        if (end.tm_mon > 12) {
            end.tm_year++;
            end.tm_mon -= 12;
        }
    }

    


}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();



}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";

}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    vector< MemberRecord> member;
    loadMemberDetails(member);
    ifstream inFile("Members.dat", ios::binary);
    MemberRecord temp;
    bool found = false;
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        if (idNumber == temp.idNumber) {
            found = true;
            return true;
            
        }       
    }
    inFile.close();
    if (!found) {
        return false;
    }

}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat",ios::binary | ios::app);
    if (outFile) {
        outFile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord));
        outFile.close();
    }
    else {
        cout << "error" << endl;

    }
    


}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat",ios::binary | ios::app);
    if (outFile) {
        outFile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
        outFile.close();
    }
    else {
        cout << "error" << endl;
    }
}