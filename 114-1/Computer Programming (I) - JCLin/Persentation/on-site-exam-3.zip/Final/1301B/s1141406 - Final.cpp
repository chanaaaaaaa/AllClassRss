#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream Member("Members.dat", ios::in | ios::binary);
    MemberRecord temp;
    while (Member.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord)))
    {
        memberDetails.push_back(temp);
    }
    Member.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    ifstream reserve("Reservations.dat", ios::in | ios::binary);
    ReservationRecord temp;
    while (reserve.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord)))
    {
        if (!lessEqual(temp.date, currentDate))
            reservations.push_back(temp);
        else
            continue;
    }
    reserve.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year == date2.year &&
        date1.month == date2.month &&
        date1.day < date2.day)
        return true;
    else if (date1.year == date2.year &&
        date1.month < date2.month)
        return true;
    else if (date1.year < date2.year)
        return true;
    
                
    return false;

}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do
        {
            cout << "\nEnter your choice (1~3): ";
        }
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0)
        {
            if (strcmp(memberDetails[i].password, password) == 0)
            {
                return true;
            }
        }
    }
    cout << "\nInvalid account number or password. Please try again.\n";
    return false;

}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    Date currentDate = compCurrentDate();

    //decide place
    for (int i = 1; i <= 18; i++)
    {
        cout << setw(2) << i << ". " << branchNames[i] << endl;
    }
    int place;
    do {
        cout << "\nEnter your choice (0 to end): ";
    } while ((place = inputAnInteger(0, 18)) == -1);
    
    if (place == 0)
        return;

    newReservation.branchCode = place;

    cout << "\nThe current hour is ";
    cout << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;

    Date availableDates[8];
    compAvailableDates(availableDates);
    //decide time
    cout << "\nAvailable days:\n";
    cout << "\n";

    for (int i = 1; i <= 7; i++)
    {
        cout << i << ". " << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << endl;
    }
    //year,month,and day
    int reservedate;
    do {
        cout << "\nEnter your choice (0 to end): ";
    } while ((reservedate = inputAnInteger(0, 7)) == -1);
    cout << endl;
    if (reservedate == 0)
        return;

    newReservation.date.year = availableDates[reservedate].year;
    newReservation.date.month = availableDates[reservedate].month;
    newReservation.date.day = availableDates[reservedate].day;

    //decide hour
    int hour;
    if (newReservation.date.year == currentDate.year &&
        newReservation.date.month == currentDate.month &&
        newReservation.date.day == currentDate.day)
    {
        do {
            cout << "\nEnter hour (" << currentDate.hour + 1 << "~23): ";
        } while ((hour = inputAnInteger(currentDate.hour+1, 23)) == -1);
        cout << endl;
    }
    else
    {
        do {
            cout << "\nEnter hour (0~23): ";
        } while ((hour = inputAnInteger(0, 23)) == -1);
        cout << endl;
    }

    newReservation.date.hour = hour;

    int numsofcus;

    do {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
    } while ((numsofcus = inputAnInteger(0, 30)) == -1);
    cout << endl;
    if (numsofcus == 0)
        return;

    newReservation.numCustomers = numsofcus;
    strcpy_s(newReservation.idNumber, idNumber);

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";
    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    int daysofmonth[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };

    for (int i = 1; i <= 7; i++)
    {
        availableDates[i].year = currentDate.year;
        availableDates[i].month = currentDate.month;
        availableDates[i].day = currentDate.day;
    }

    if (currentDate.hour < 23)
    {
        for (int i = 1; i <= 6; i++)
        {
            availableDates[i + 1].day += i;
        }
    }
    else
    {
        for (int i = 1; i <= 7; i++)
        {
            availableDates[i].day += i;
        }
    }

    int maxday = 0;

    for (int i = 1; i <= 7; i++)
    {
        if (availableDates[i].month == 2)
        {
            if ((availableDates[i].year % 4 == 0 && availableDates[i].year % 100 != 0) || availableDates[i].year % 400 == 0)
            {
                maxday = 29;
            }
            else 
                maxday = 28;
        }
        else
            maxday = daysofmonth[availableDates[i].month];

        if (availableDates[i].day > maxday)
        {
            availableDates[i].day -= maxday;
            availableDates[i].month += 1;
        }

        if (availableDates[i].month > 12)
        {
            availableDates[i].month = 1;
            availableDates[i].year += 1;
        }
    }




}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    if (reservations.empty())
    {
        cout << "No reservations!\n";
        return;
    }



    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    int match = 0;
    for (int i = 0; i < reservations.size(); i++)
    {
        if (strcmp(reservations[i].idNumber, idNumber) == 0)
        {
            match++;
            cout << match << ".";
            output(reservations[i]);
        }
    }
    int deleteindex;
    do {
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
    } while ((deleteindex = inputAnInteger(0, match)) == -1);
    if (deleteindex == 0)
        return;

    vector<ReservationRecord> temp;
    int dest = 0;
    for (int i = 0; i < reservations.size(); i++)
    {
        if (strcmp(reservations[i].idNumber, idNumber) == 0)
        {
            dest++;
            if (dest == deleteindex)
                continue;
        }
        temp.push_back(reservations[i]);
    }

    reservations = temp;
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0)
            return true;
    }
    return false;

}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream Member("Members.dat", ios::out | ios::binary | ios::app);

    for (int i = 0; i < memberDetails.size(); i++)
    {
        Member.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }

    Member.close();

}

void saveReservations(const vector< ReservationRecord >& reservations)
{

    ofstream reserve("Reservations.dat", ios::out | ios::binary | ios::trunc);

    for (int i = 0; i < reservations.size(); i++)
    {
        reserve.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }

    reserve.close();


}