#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    if (!inFile)
    {
        cout << "File can't be opened.";
        exit(0);
    }

    MemberRecord tempMember;
    while (inFile.read(reinterpret_cast<char*>(&tempMember), sizeof(MemberRecord)))
    {
        memberDetails.push_back(tempMember);
    }
    inFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::in | ios::binary);
    if (!inFile)
    {
        cout << "File can't be opened.";
        exit(0);
    }

    ReservationRecord tempReservation;
    while (inFile.read(reinterpret_cast<char*>(&tempReservation), sizeof(ReservationRecord)))
    {
        reservations.push_back(tempReservation);
    }
    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year > date2.year)
    {
        return true;
    }
    else if (date1.year < date2.year)
    {
        return false;
    }
    else
    {
        if (date1.month > date2.month)
        {
            return true;
        }
        else if (date1.month < date2.month)
        {
            return false;
        }
        else
        {
            if (date1.day > date2.day)
            {
                return true;
            }
            else if (date1.day < date2.day)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(1);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); ++i)
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0 && strcmp(memberDetails[i].password, password) == 0)
        {
            return true;
        }
    }
    cout << "\nInvalid account number or password. Please try again.\n\n";
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation{ 0 };
    strcpy_s(newReservation.idNumber, idNumber);
    for (int i = 1; i <= 18; ++i)
    {
        cout << setw(2) << i << ". " << branchNames[i] << '\n';
    }
    newReservation.branchCode = 99;
    do
    {
        if (newReservation.branchCode == 0)
        {
            cin.ignore();

            return;
        }
        if (newReservation.branchCode >= 1 && newReservation.branchCode <= 18)
        {
            break;
        }
        cout << "\nEnter your choice (0 to end): ";
    }while (cin >> newReservation.branchCode);

    cin.ignore();

    Date availableDates[8]{ 0 };
    compAvailableDates(availableDates);

    int targetDate = 99;
    do
    {
        if (targetDate == 0)
        {
            cin.ignore();

            return;
        }
        if (targetDate >= 1 && targetDate <= 7)
        {
            break;
        }
        cout << "\nEnter your choice (0 to end): ";
    } while (cin >> targetDate);

    cin.ignore();

    newReservation.date = availableDates[targetDate];

    int targetHour = 99;
    int maxHour = 0;
    Date currentDate = compCurrentDate();
    if (targetDate == 1)
    {
        maxHour = currentDate.hour + 1;
        if (maxHour == 24)
        {
            maxHour = 0;
        }
    }
    do
    {
        if (targetHour >= maxHour && targetHour <= 23)
        {
            break;
        }
        cout << "\nEnter hour(" << maxHour << "~23): ";
    } while (cin >> targetHour);

    cin.ignore();

    newReservation.date.hour = targetHour;

    newReservation.numCustomers = 99;
    do
    {
        if (newReservation.numCustomers == 0)
        {
            cin.ignore();

            return;
        }
        if (newReservation.numCustomers >= 1 && newReservation.numCustomers <= 30)
        {
            break;
        }
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
    } while (cin >> newReservation.numCustomers);

    cin.ignore();

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    cout << "\nThe current hour is " << currentDate.year << '/' << currentDate.month << '/' << currentDate.day << ':' << currentDate.hour << '\n';
    cout << "Available days:\n\n";
    Date tempDate = currentDate;
    bool leap = false;
    int maxDay = 0;
    if (tempDate.hour == 23)
    {
        tempDate.day++;
    }
    for (int i = 1; i <= 7; ++i)
    {
        if (tempDate.year % 4 == 0 && tempDate.year % 100 != 0 || tempDate.year % 400 == 0)
        {
            leap = true;
        }
        if (tempDate.month == 1 || tempDate.month == 3 || tempDate.month == 5 || tempDate.month == 7 || tempDate.month == 8 || tempDate.month == 10 || tempDate.month == 12)
        {
            maxDay = 31;
        }
        else if (tempDate.month == 4 || tempDate.month == 6 || tempDate.month == 9 || tempDate.month == 11)
        {
            maxDay = 30;
        }
        else if (tempDate.month == 2)
        {
            if (leap)
            {
                maxDay = 29;
            }
            if (!leap)
            {
                maxDay = 28;
            }
        }
        if (tempDate.day > maxDay)
        {
            if (tempDate.month == 12)
            {
                tempDate.year++;
                tempDate.month -= 11;
                tempDate.day -= 31;
            }
            else
            {
                tempDate.month++;
                tempDate.day -= maxDay;
            }
        }
        availableDates[i] = tempDate;
        cout << i << ". " << tempDate.year << '/' << tempDate.month << '/' << tempDate.day << '\n';
        tempDate.day++;
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    vector < ReservationRecord > targetReservations{ 0 };
    for (int i = 0; i < reservations.size(); ++i)
    {
        if (strcmp(reservations[i].idNumber, idNumber) == 0 && reservations[i].numCustomers != 0 && lessEqual(reservations[i].date, currentDate))
        {
            targetReservations.push_back(reservations[i]);
        }
    }
    if (targetReservations.size() == 0)
    {
        cout << "\nNo Reservations!\n";
        return;
    }
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;
    for (int i = 0; i < targetReservations.size(); ++i)
    {
        output(targetReservations[i]);
    }
    int choice;
    cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
    while(cin >> choice)
    {
        cin.ignore();

        if (choice == 0)
        {
            return;
        }
        if (choice >= 1 && choice <= targetReservations.size())
        {
            int deletNum = 0;
            for (int i = 0; i < reservations.size(); ++i)
            {
                if (strcmp(reservations[i].idNumber, targetReservations[choice - 1].idNumber) == 0 && reservations[i].numCustomers != 0 && lessEqual(reservations[i].date, currentDate))
                {
                    deletNum++;
                    if (deletNum == choice)
                    {
                        reservations[i].numCustomers = 0;
                        cout << "\nReservation Deleted!\n";
                        return;
                    }
                }
            }
        }
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
    }

}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); ++i)
    {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
        {
            return true;
        }
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::out | ios::binary);
    if (!outFile)
    {
        cout << "File can't be write.";
        exit(0);
    }
    for (int i = 0; i < memberDetails.size(); ++i)
    {
        outFile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::out | ios::binary);
    if (!outFile)
    {
        cout << "File can't be write.";
        exit(0);
    }
    for (int i = 0; i < reservations.size(); ++i)
    {
        if (reservations[i].numCustomers != 0)
        {
            outFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
        }
    }
    outFile.close();
}