#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream inFile("Members.dat", ios::binary);
    while (inFile.read(reinterpret_cast<char*>(&memberDetails), sizeof(MemberRecord)));
    inFile.close();
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    //�L�������n
    Date temp = compCurrentDate();
    ifstream inFile("Reservations.dat", ios::binary);
    for (int i{ 0 }; i < reservations.size(); i++) {
        if (lessEqual(reservations[i].date, temp)) {
            while (inFile.read(reinterpret_cast<char*>(&reservations), sizeof(ReservationRecord)));
        }
    }
    inFile.close();
}

Date compCurrentDate()
{
   Date currentDate = {};
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    const int monthDays[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int Date1 = date1.year * 365 + date1.day;
    for (int i{ 0 }; i < date1.month - 1; i++) {
        Date1 += monthDays[i];
    }
    int year = date1.year - 1;
    Date1 = Date1 + year / 4 - year / 100 + year / 400;
    if ((date1.year % 400 == 0 || (date1.year % 4 == 0 && date1.year % 100 != 0)) && date1.month > 2) {
        Date1++;
    }

    int Date2 = date2.year * 365 + date2.day;
    for (int i{ 0 }; i < date2.month - 1; i++) {
        Date2 += monthDays[i];
    }
    year = date2.year - 1;
    Date2 = Date2 + year / 4 - year / 100 + year / 400;
    if ((date2.year % 400 == 0 || (date2.year % 4 == 0 && date2.year % 100 != 0)) && date2.month > 2) {
        Date2++;
    }

    return Date1 > Date2;
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline(string, 80, '\n');

   if (strlen(string) == 0)
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary);
    MemberRecord temp;
    bool isInFile = false;
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        if (strcmp(temp.idNumber, idNumber) == 0 && strcmp(temp.password, password) == 0) {
            isInFile = true;
        }
    }
    if (!isInFile) {
        for (int i{ 0 }; i < memberDetails.size(); i++) {
            if (strcmp(memberDetails[i].idNumber, idNumber) == 0 && strcmp(memberDetails[i].password, password) == 0) {
                isInFile = true;
                return isInFile;
            }
        }
    }
    if (!isInFile) {
        cout << "\nInvalid account number or password. Please try again.\n\n";
        return isInFile;
    }
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;
   strcpy_s(newReservation.idNumber, 12, idNumber);

   for (int i{ 1 }; i < 19; i++) {
       cout << setw(2) << i << ". " << branchNames[i] << endl;
   }
   cout << endl;
   do {
       cout << "Enter your choice (0 to end): ";
       cin >> newReservation.branchCode;
       cout << endl;
   } while (newReservation.branchCode < 0 || newReservation.branchCode > 18);
   if (newReservation.branchCode == 0) { // 0 return
       cin.ignore();
       return;
   }

   Date current = compCurrentDate();
   cout << "The current hour is " << current.year << '/' << setw(2) << setfill('0') << current.month << '/' << setw(2) << setfill('0') << current.day<< ":" << setw(2) << setfill(' ') << current.hour << endl;
   cout << "\nAvailable days:\n\n";
   Date temp = {};
   compAvailableDates(&temp);
   newReservation.date = temp;

   do {
       cout << "\nEnter the number of customers (1~30, 0 to end): ";
       cin >> newReservation.numCustomers;
   } while (newReservation.numCustomers < 0 || newReservation.numCustomers > 30); 
   if (newReservation.numCustomers == 0) { // 0 return
       cin.ignore();
       return;
   }

   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
   cin.ignore();
   saveReservations(reservations);
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();
   const int monthDays[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
   int showMonth = currentDate.month;
   int showYear = currentDate.year;
   int showDay = currentDate.day;
   int showHour = currentDate.hour + 1;
   if (currentDate.hour == 23) {
       showDay++;
       showHour = 0;
   }
   if (showDay > monthDays[currentDate.month]) {
       showDay = 1;
       showMonth++;
   }
   for (int i{ 0 }; i < 7; i++) { //show Available days
       if (showMonth > 12) {
           showMonth -= 12;
           showYear++;
       }
       cout << i + 1 << ". " << showYear << "/" << showMonth << "/" << showDay << endl;
       showDay++;
   }
   int choice{ 0 };
   do {
       cout << "\nEnter your Choice(0 to end): ";
       cin >> choice;
   } while (choice < 0 || choice > 7);
   if (choice == 0) { // 0 return
       cin.ignore();
       return;
   }
   if (choice > 1) {
       showHour = 0;
   }
   int hour;
   do {
       cout << "\nEnter hour (" << showHour << "~23): ";
       cin >> hour;
   } while (hour < showHour || hour > 23);

   availableDates[0].hour = hour;
   availableDates[0].day = currentDate.day + (choice - 1);
   if (availableDates[0].day > monthDays[currentDate.month]) {
       availableDates[0].month = currentDate.month + 1;
       if (availableDates[0].month > 12) {
           availableDates[0].month -= 12;
           availableDates[0].year = currentDate.year + 1;
       }
   }
   else {
       availableDates[0].month = currentDate.month;
       availableDates[0].year = currentDate.year;
   }
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();
   loadReservations(reservations);
   bool found = false;
   for (int i{ 0 }; i < reservations.size(); i++) {
       if (strcmp(reservations[i].idNumber, idNumber) == 0) {
           found = true;
       }
   }
   if (!found) {
       cout << "No reservations!\n";
       return;
   }
   cout << endl << setw(29) << "Branch"
       << setw(14) << "Date" << setw(8) << "Hour"
       << setw(19) << "No of Customers" << endl;

   int count{ 0 };
   for (int i{ 0 }; i < reservations.size(); i++) {
       if (strcmp(idNumber, reservations[i].idNumber) == 0) {
           cout << ++count << ". ";
           output (reservations[i]);
       }
   }
   cout << endl;
   int choice;
   do {
       cout << "Choose a reservation to cancel (0: keep all reservations): ";
       cin >> choice;
       cout << endl;
   } while (choice < 0 || choice > count);
   if (choice == 0) {
       cin.ignore();
       return;
   }

   count = 0;
   for (int i{ 0 }; i < reservations.size(); i++) {
       if (strcmp(idNumber, reservations[i].idNumber) == 0) {
           if (count++ == choice) {
               reservations[i].numCustomers = 0;
           }
       }
   }
   cin.ignore();
   saveReservations(reservations);
}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i{ 0 }; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {
            return true;
        }
    }
    return false;
}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream outFile("Members.dat", ios::binary|ios::app);
    outFile.write(reinterpret_cast<const char*>(&memberDetails[0]), sizeof(MemberRecord));
    outFile.close();
}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream outFile("Reservations.dat", ios::binary|ios::app);
    for (int i{ 0 }; i < reservations.size(); i++) { 
        if (reservations[i].numCustomers != 0) { // �e���p�G�R���q�쪺�ܡA�ڷ|��numCustomers�ܦ�0
            outFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
        }
    }
    outFile.close();
}