#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;
#include <string>
#include<cstring>
#include<time.h>
#include <ctime>
struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";

        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    int numMember = 0;
    MemberRecord temp = {};
    if (!inFile)
    {
        cout << "Members.dat could not open." << endl;
    }

    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord)))
    {
        memberDetails.push_back(temp);
    }
    inFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::in | ios::binary);
    int numReservation = 0;
    ReservationRecord temp = {};
    Date currentDate = compCurrentDate();
    if (!inFile)
    {
        cout << "Reservation.dat could not open." << endl;
    }

    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord)))
    {
        if (!lessEqual(temp.date, currentDate))
        {
            reservations.push_back(temp);
        }
    }
    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0) - 3 * 24 * 60 * 60;
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year > date2.year)
    {
        return false;
    }
    else if (date1.year == date2.year)
    {
        if (date1.month > date2.month)
        {
            return false;
        }
        else if ((date1.month == date2.month))
        {
            if (date1.day > date2.day)
            {
                return false;
            }
            else if (date1.day == date2.day)
            {
                if (date1.hour > date2.hour)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return true;
            }
        }
        else
        {
            return true;
        }
    }
    else
    {
        return true;
    }

}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
        {
            if (strcmp(password, memberDetails[i].password) == 0)
            {
                return true;
            }
            else
            {
                cout << endl;
                cout << "Invalid account number or password.Please try again." << endl;
                return false;
            }
        }
    }
    cout << endl;
    cout << "Invalid account number or password.Please try again." << endl;
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    int branchChoice = 0;
    int dayChoice = 0;
    int hourChoice = 0;
    int BigMonth[7] = { 1,3,5,7,8,10,12 };
    Date currentDate = compCurrentDate();
    int year = currentDate.year;
    int month = currentDate.month;
    int day = currentDate.day;
    int hour = currentDate.hour;
    ReservationRecord newReservation;

    for (int i = 1; i < 19; i++)
    {
        cout << endl << setw(2) << i << ". "
            << branchNames[i];
    }
    cout << endl << endl;
    do
    {
        cout << "Enter your choice(0 to end): ";
        cin >> branchChoice;
        cout << endl;
    } while (branchChoice < 0 || branchChoice > 18);
    if (branchChoice == 0)
    {
        cin.ignore();
        return;
    }
    cout << "The current hour is " << year << "/" << month << '/' << day << ":" << hour << endl;
    cout << endl;
    compAvailableDates(&currentDate);
    do
    {
        cout << "Enter your choice(0 to end) :";
        cin >> dayChoice;
        cout << endl;
    } while (dayChoice < 0 || dayChoice > 7);
    if (dayChoice == 0)
    {
        cin.ignore();
        return;
    }
    day += dayChoice;
    if (month == 12 && day > 31)
    {
        year++;
        month = 1;
        day = 1;
    }
    if (year % 4 == 0 && year % 100 != 0)
    {
        if (month == 2 && day > 29)
        {
            month++;
            day -= 29;
        }
    }
    else
    {
        if (month == 2 && day > 28)
        {
            month++;
            day -= 28;
        }
    }
    for (int i = 0; i < 7; i++)
    {
        if (month == BigMonth[i])
        {
            if (day > 31)
            {
                month++;
                day -= 31;
            }
        }
        else
        {
            if (day > 30)
            {
                month++;
                day -= 30;
            }
        }
    }
    Date chooseDate;
    chooseDate.year = year;
    chooseDate.month = month;
    chooseDate.day = day;
    int start = 0;
    hour += 1;

    do {
        if (dayChoice == 1)
        {
            start = hour;
            cout << "Enter hour(" << hour + 1 << "~23): ";
        }
        else
        {
            start = 0;
            cout << "Enter hour(0~23): ";
        }
        cin >> hourChoice;
        cout << endl;
    } while (hourChoice < start || hourChoice > 23);
    if (hourChoice == 0)
    {
        cin.ignore();
        return;
    }
    chooseDate.hour = hourChoice;
    int numCustomers = 0;
    do
    {
        cout << "Enter the number of customers(1~30, 0 to end): ";
        cin >> numCustomers;
        cout << endl;
    } while (numCustomers < 0 || numCustomers > 30);
    if (numCustomers == 0)
    {
        cin.ignore();
        return;
    }
    cin.ignore();
    newReservation.branchCode = branchChoice;
    newReservation.date = chooseDate;
    newReservation.numCustomers = numCustomers;

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
    saveReservations(reservations);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    int year = currentDate.year;
    int month = currentDate.month;
    int day = currentDate.day;
    int hour = currentDate.hour;
    int BigMonth[7] = { 1,3,5,7,8,10,12 };
    cout << "Available days:" << endl;
    cout << endl;
    for (int i = 1; i < 8; i++)
    {
        cout << i << ". " << year << "/" << month << '/' << day << endl;
        day++;
        if (month == 12 && day > 31)
        {
            year++;
            month = 1;
            day = 1;
        }
        if (year % 4 == 0 && year % 100 != 0)
        {
            if (month == 2 && day > 29)
            {
                month++;
                day -= 29;
            }
        }
        else
        {
            if (month == 2 && day > 28)
            {
                month++;
                day -= 28;
            }
        }
        for (int i = 0; i < 7; i++)
        {
            if (month == BigMonth[i])
            {
                if (day > 31)
                {
                    month++;
                    day -= 31;
                }
            }
            else
            {
                if (day > 30)
                {
                    month++;
                    day -= 30;
                }
            }
        }
    }
    cout << endl;
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    int cancelNum = 0;
    if (reservations.size() == 0)
    {
        cout << "There is no reservations" << endl;
        return;
    }
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    for (int i = 0; i < reservations.size(); i++)
    {
        cout << setw(2) << i + 1 << ".";
        output(reservations[i]);
    }
    do
    {
        cout << "Choose a reservation to cancel(0: keep all reservations): " << endl;
        cin >> cancelNum;
        cout << endl;
    } while (cancelNum < 0 || cancelNum > reservations.size());
    if (cancelNum == 0)
    {
        cin.ignore();
        return;
    }
    vector< ReservationRecord > temp = {};
    for (int i = 0; i < reservations.size(); i++)
    {
        if (i != (cancelNum - 1))
        {
            temp.push_back(reservations[i]);
        }
    }
    for (int i = 0; i < temp.size(); i++)
    {
        reservations[i] = temp[i];
    }
    reservations.pop_back();
    cin.ignore();
}

void registration(vector< MemberRecord >& memberDetails)
{

    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
    saveMemberDetails(memberDetails);
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{

    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
        {
            return true;
        }
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)

{
    ofstream outFile("Members.dat", ios::out | ios::binary);
    if (!outFile)
    {
        cout << "Members.dat could not open." << endl;
    }
    MemberRecord temp = {};
    for (int i = 0; i < memberDetails.size(); i++)
    {
        temp = memberDetails[i];
        outFile.write(reinterpret_cast<const char*>(&temp), sizeof(MemberRecord));
    }

    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::out | ios::binary);
    if (!outFile)
    {
        cout << "Reservations.dat could not open" << endl;
        return;
    }
    ReservationRecord temp = {};
    for (int i = 0; i < reservations.size(); i++)
    {
        temp = reservations[i];
        outFile.write(reinterpret_cast<const char*>(&temp), sizeof(ReservationRecord));
    }
    outFile.close();
}
