#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary);

    if (!inFile)
    {
        cout << "File could not be opened" << endl;
        return;
    }

    MemberRecord temp;

    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord)))
    {
        memberDetails.push_back(temp);
    }
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::binary);

    if (!inFile)
    {
        cout << "File could not be opened" << endl;
        return;
    }

    ReservationRecord temp;

    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord)))
    {
        reservations.push_back(temp);
    }
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year > date2.year)
    {
        return false;
    }

    else
    {
        if (date1.month > date2.month)
        {
            return false;
        }

        else
        {
            if (date1.day > date2.day)
            {
                return false;
            }

            else
            {
                return true;
            }
        }
    }

}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    MemberRecord userid;

    for (int i = 0; i < memberDetails.size(); i++)
    {
        userid = memberDetails[i];
    }


    if (idNumber == userid.idNumber && password == userid.password)
    {
        return true;
    }

    else
    {
        return false;
    }
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    int choice;
    do {
        for (int i = 1; i <= 18; i++)
        {
            cout << i << ". " << branchNames[i] << endl;
        }

        cout << endl << "Enter your choice (0 to end): ";

        cin >> choice;

    } while (choice < 0 || choice > 18);

    newReservation.branchCode = choice;

    Date availableDates;

    compAvailableDates(&availableDates);

    newReservation.date = availableDates;

    int peoplenum;
    do {

        cout << endl << "Enter the number of customers(1~30, 0 to end): ";

        cin >> peoplenum;

    } while (peoplenum < 1 || peoplenum > 30);

    newReservation.numCustomers = peoplenum;

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    cout << endl << "The current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;

    cout << endl << "Available days:" << endl;

    Date AvailableDate;

    AvailableDate = currentDate;

    int date = 1;
    do {
        for (int i = 1; i <= 7; i++)
        {
            if (currentDate.hour == 23)
            {
                if (lessEqual(currentDate, AvailableDate))
                {
                    AvailableDate.day = currentDate.day + i;
                    if (currentDate.month == 12 && currentDate.day == 31)
                    {
                        AvailableDate.month = 1;
                        AvailableDate.year = currentDate.year + 1;
                    }
                    
                }
            }

            else
            {
                if (lessEqual(currentDate, AvailableDate))
                {
                    AvailableDate.day = currentDate.day - 1 + i;

                }
            }
        }

        date++;

    } while (date <= 7);
    
    int choose;
    do {
        cout << endl << "Enter your choice (0 to end):";

        cin >> choose;

    } while (choose < 1 || choose > 7);

    int min = 0;



    if (currentDate.hour == 23)
    {
         min = 0;
    }

    else
    {
         min = currentDate.hour + 1;
    }
    
    int max = 23;

    int hourchoose;
    do {
        cout << endl << "Enter hour (" << min << "~" << max << "): ";

        cin >> hourchoose;

    } while (hourchoose < min || hourchoose > max);
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();


    ReservationRecord  currentreservation;

    for (int i = 0; i < reservations.size(); i++)
    {
        currentreservation = reservations[i];
        output(currentreservation);
    }


    int cancelchoose;
    do {
        cout << "Choose a reservation to cancel (0: keep all reservations):";
        cin >> cancelchoose;

    } while (cancelchoose <= 0);

    ofstream outFile("Reservations.dat", ios::binary);
    if (!outFile)
    {
        cout << "File could not be opened" << endl;
        return;
    }

    int choose;

    cin >> choose;
    int i = 0;

    while (i != choose)
    {
        outFile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
        i++;
    }
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    MemberRecord userid;

    for (int i = 0; i < memberDetails.size(); i++)
    {
        userid = memberDetails[i];
    }

    if (idNumber == userid.idNumber)
    {
        return true;
    }

    else
    {
        return false;
    }

}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::binary);
    if (!outFile)
    {
        cout << "File could not be opened" << endl;
        return;
    }

    outFile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord));
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::binary);
    if (!outFile)
    {
        cout << "File could not be opened" << endl;
        return;
    }

    outFile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
}