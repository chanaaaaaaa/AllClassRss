#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);
    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream member("Members.dat",ios::binary);
    if (!member) cout << "error open";
    member.seekg(0, ios::beg);
    MemberRecord mb;
    while (member.read(reinterpret_cast<char*>(&mb), sizeof(MemberRecord))) {
        memberDetails.push_back(mb);
    }
    member.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream reservation("Reservations.dat", ios::binary);
    if (!reservation) cout << "error open";
    reservation.seekg(0, ios::beg);
    ReservationRecord re;
    while (reservation.read(reinterpret_cast<char*>(&re), sizeof(ReservationRecord))) {
        reservations.push_back(re);
    }
    reservation.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0)-(3*24-25)*60*60;
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year > date2.year) return false;
    if (date1.year == date2.year) {
        if (date1.month > date2.month) return false;
        if (date1.month == date2.month) {
            if (date1.day > date2.day) return false;
        }
    }
    return true;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";
        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (!strcmp(idNumber,memberDetails[i].idNumber) && !strcmp(password,memberDetails[i].password)) {
            return true;
        }
    }

    cout << "\nInvalid account number or password. Please try again.\n\n";
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    for (int i = 1; i < 19; i++) {
        cout <<i<< ". " << branchNames[i] << "\n";
    }
    int cb;
    do{
        cout << "\nEnter your choice(0 to end) :";
        cin >> cb;
    } while (cb < 0 || cb>18);
    if (cb == 0) {
        cin.ignore();
        return;
    }
    Date now=compCurrentDate();

    cout << "\nThe current hour is " << now.year << "/" << now.month << "/" << now.day << ":" << now.hour<<"\n";

    Date availableDates[8];
    compAvailableDates(availableDates);
    cout <<"\nAvailable days:\n\n";
    for (int i = 1; i <= 7; i++) {
        cout << i << ". "<< availableDates[i].year<<"/"<<availableDates[i].month
            <<"/" << availableDates[i].day << "\n";
    }
    int cd;
    do {
        cout << "\n\nEnter your choice (0 to end):";
        cin >> cd;
    } while (cd < 0 || cd>7);
    if (cd == 0) {
        cin.ignore();
        return;
    }

    int ch;
    do {
        cout << "\nEnter hour ("<<availableDates[cd].hour<<"~23):";
        cin >> ch;
    } while (ch < availableDates[cd].hour || ch>23);
    
    int cm;
    do {
        cout << "\nEnter the number of customers (1~30, 0 to end):";
        cin >> cm;
    } while (cm < 0 || cm>30);
    if (cm == 0) {
        cin.ignore();
        return;
    }
    availableDates[cd].hour = ch;
    newReservation.branchCode = cb;
    newReservation.date = availableDates[cd];
    strcpy_s(newReservation.idNumber ,12, idNumber);
    newReservation.numCustomers = cm;


    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cin.ignore();

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    int hour = currentDate.hour,day=currentDate.day,month=currentDate.month,year=currentDate.year;
    if (hour >= 23) {
        hour = 0;
        day++;
    }
    int md;
    for (int i = 1; i <= 7; i++) {
        if (month == 2)
            if (year % 400 == 0 || year % 4 == 0 && year % 100 != 0) md = 29;
            else md = 28;
        else if (month == 1 || month == 3 || month == 5 || month == 7
            || month == 8 || month == 10 || month == 12) md = 31;
        else  md = 30;

        if (day > md) {
            day = 1;
            month++;
        }
        if (month > 12) {
            year++;
            month = 1;
        }

        if(day==currentDate.day) availableDates[i] = { year,month,day,hour+1};
        else availableDates[i] = {year,month,day,0};

        day++;
    }


}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    vector<int> t;
    for (int i = 0; i < reservations.size(); i++) {
        if (!strcmp(reservations[i].idNumber, idNumber)) {
            if (!lessEqual(currentDate,reservations[i].date)) continue;
            t.push_back(i);
            if(t.size()==1) cout << endl << setw(28) << "Branch"
                << setw(14) << "Date" << setw(8) << "Hour"
                << setw(19) << "No of Customers" << endl;

            cout << t.size() << ". ";
            output(reservations[i]);
        }
    }

    if (t.size() == 0) {
        cout << "No reservations!\n";
        return;
    }
    int choice;
    do {
        cout << "\n\nChoose a reservation to cancel (0: keep all reservations):";
        cin >> choice;
    } while (choice<0|| choice>t.size());
    if (choice == 0) {
        cin.ignore();
        return;
    }
    reservations.erase(reservations.begin() + t[choice-1]);
    cin.ignore();
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (!strcmp(idNumber,memberDetails[i].idNumber)) return true;
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream save("Members.dat", ios::out | ios::binary);
    if (!save) cout << "error open";
    for (int i = 0; i < memberDetails.size(); i++) {
        save.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    save.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream save("Reservations.dat", ios::out | ios::binary);
    if (!save) cout << "error open";
    for (int i = 0; i < reservations.size(); i++) {
        save.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }
    save.close();
}