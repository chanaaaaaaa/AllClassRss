#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::fstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members//main
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)//okkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    if (!inFile) {
        cout << "file could not be opened" << endl;
        return;
    }

    MemberRecord memberrecord;
    inFile.read(reinterpret_cast<char*>(&memberrecord), sizeof(MemberRecord));
    while (memberrecord.idNumber != '\0') {
        memberDetails.push_back(memberrecord);
        inFile.read(reinterpret_cast<char*>(&memberrecord), sizeof(MemberRecord));
    }
    inFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)//okkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk
{
    Date currentDate = compCurrentDate();

    ifstream inFile("Reservations.dat", ios::in | ios::binary);
    if (!inFile) {
        cout << "file could not be opened" << endl;
        return;
    }

    ReservationRecord reservationrecord;
    inFile.read(reinterpret_cast<char*>(&reservationrecord), sizeof(ReservationRecord));
    while (reservationrecord.idNumber != '\0') {
        if (lessEqual(currentDate, reservationrecord.date)) {
            reservations.push_back(reservationrecord);
            inFile.read(reinterpret_cast<char*>(&reservationrecord), sizeof(ReservationRecord));
        }
    }
    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)//ok
{
    if (date1.year <= date2.year) {
        if (date1.month <= date2.month)
            if (date1.day <= date2.day)
                if (date1.hour <= date2.hour)
                    return true;
    }
    else {
        return false;
    }
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)//okkkkkkkkkkkkkkkkkkkkkkkkkkk
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    if (!inFile) {
        cout << "file could not be opened" << endl;
        return;
    }

    MemberRecord memberrecord;
    inFile.read(reinterpret_cast<char*>(&memberrecord), sizeof(MemberRecord)); 

    while (memberrecord.idNumber != '\0') {
        if (idNumber[12] == memberrecord.idNumber[12] || password[24] == memberrecord.password[24]) {
            inFile.close();
            return true;
        }
    }
    inFile.close();
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    cout << endl;
    for (int i = 1; i <= 18; i++) {
        cout << endl << i << ". " << branchNames[i];
    }
    cout << endl;

    do cout << "\nEnter your choice(0 to end) : ";
    while ((newReservation.branchCode = inputAnInteger(1, 3)) == -1);
    cout << endl;

    if (newReservation.branchCode == 0) {
        return;
    }

    Date currentDate = compCurrentDate();
    cout << endl << "The current hour is " << currentDate.year << "/" << currentDate.month
        << "/" << currentDate.day << ":" << currentDate.hour << endl << "\nAvailable days: " << endl;

    Date availableDates[8];
    compAvailableDates(availableDates);

    int date;
    do cout << "\nEnter your choice(0 to end) : ";
    while ((date = inputAnInteger(1, 7)) == -1);
    cout << endl;

    if (date == 0) {
        return;
    }
    newReservation.date.year = availableDates[date].year;
    newReservation.date.month = availableDates[date].month;
    newReservation.date.day = availableDates[date].day;

    do cout << "\nEnter hour (19~23): ";
    while ((newReservation.date.hour = inputAnInteger(19, 23)) == -1);
    cout << endl;


    do cout << "\nEnter the number of customers (1~30, 0 to end): ";
    while ((newReservation.numCustomers = inputAnInteger(1, 30)) == -1);
    cout << endl;

    if (newReservation.numCustomers == 0) {
        return;
    }

    saveReservations(reservations);

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    
    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])//ok
{
    Date currentDate = compCurrentDate();
    if (currentDate.hour >= 23) {
        dateProcess(currentDate);
    }

    for (int i = 1; i <= 7; i++) {
        dateProcess(currentDate);
        availableDates[i] = currentDate;
    }

    for (int i = 1; i <= 7; i++) {
        cout << endl << i << ". " << availableDates[i].year << "/" << availableDates[i].month
            << "/" << availableDates[i].day << endl;
    }
}

void dateProcess(Date &currentDate)//this funtion is a part of "compAvailableDates"okkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk
{
    if (((currentDate.day == 30) && (currentDate.month == 4 || 6 || 9 || 11)) ||
        ((currentDate.day == 31) && (currentDate.month == 1 || 3 || 5 || 7 || 8 || 10 || 12)) ||
        ((currentDate.day == 29) && (currentDate.month == 2) && (((currentDate.year % 4 == 0) && (currentDate.year % 100 != 0)) || (currentDate.year % 400 == 0))) ||
        ((currentDate.day == 28) && (currentDate.month == 2) && ((currentDate.year % 4 != 0) || ((currentDate.year % 100 == 0) && (currentDate.year % 400 != 0))))) {

        currentDate.day = 1;
    }
    else {
        currentDate.day++;
    }

    if (currentDate.month == 12 && currentDate.day == 1) {
        currentDate.month = 1;
    }
    else if (currentDate.day == 1) {
        currentDate.month++;
    }

    if (currentDate.month == 1 && currentDate.day == 1) {
        currentDate.year = 1;
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    for (int i = 1; i <= (sizeof(reservations) / 44); i++) {
        if (lessEqual(currentDate, reservations[i].date)) {
            cout << i << "." << setw(24) << branchNames[reservations[i].branchCode]
                << setw(8) << reservations[i].date.year << '-'
                << setw(2) << setfill('0') << reservations[i].date.month << '-'
                << setw(2) << setfill('0') << reservations[i].date.day
                << setw(8) << setfill(' ') << reservations[i].date.hour
                << setw(19) << reservations[i].numCustomers << endl;
        }
    }

    int c;
    do cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
    while (( c = inputAnInteger(1, 30)) == -1);
    cout << endl;
   
    if (c == 0) {
        return;
    }

    reservations[c].branchCode = '\0';
    reservations[c].idNumber = '\0';
    reservations[c].numCustomers = '\0';
    reservations[c].date.hour = '\0';
    reservations[c].date.hour = '\0'
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";


}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < (sizeof(memberDetails) / 44); i++) {
        if (memberDetails[i].idNumber[12] == idNumber[12]) {
            return true;
        }
    }
    else {
        return false;
    }
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::app || ios::binary);
    if (!outFile) {
        cout << "file could not be opened" << endl;
        return;
    }

    outFile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord));
    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::app || ios::binary);
    if (!outFile) {
        cout << "file could not be opened" << endl;
        return;
    }

    outFile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
    outFile.close();
}