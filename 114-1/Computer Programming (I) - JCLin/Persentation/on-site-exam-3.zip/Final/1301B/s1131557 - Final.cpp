#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inputFile("Members.dat", ios::in | ios::binary);
    int entriesNum = 0;

    if (inputFile.fail() == true)
    {
        cout << "loadMemberDetails File could not be load.";
        exit(1);
    }

    // count entriesNum
    inputFile.seekg(0, ios::end);
    entriesNum = static_cast<int>(inputFile.tellg()) / sizeof(MemberRecord);
    inputFile.seekg(0, ios::beg);

    // load data
    MemberRecord tempMemberRecord;
    for (int i = 0; i < entriesNum; i++)
    {
        inputFile.read(reinterpret_cast<char*>(&tempMemberRecord), sizeof(MemberRecord));
        memberDetails.push_back(tempMemberRecord);
    }

    inputFile.close();
}

// -> compCurrentDate()
// -> lessEqual()
void loadReservations(vector< ReservationRecord >& reservations)
{
    //cout << "loadReservations()" << endl; // debug
    ifstream inputFile("Reservations.dat", ios::in | ios::binary);
    int entriesNum = 0;
    Date currentDate = compCurrentDate();

    if (inputFile.fail() == true)
    {
        cout << "loadReservations File could not be load.";
        exit(1);
    }
    
    // count entriesNum
    inputFile.seekg(0, ios::end);
    entriesNum = static_cast<int>(inputFile.tellg()) / sizeof(ReservationRecord);
    inputFile.seekg(0, ios::beg);

    //cout << "reservations entriesNum: " << entriesNum << endl; // debug

    // load data and check the date
    ReservationRecord tempReservation;
    for (int i = 0; i < entriesNum; i++)
    {
        inputFile.read(reinterpret_cast<char*>(&tempReservation), sizeof(ReservationRecord));
        //cout << "tempReservation.date: " << tempReservation.date.day << tempReservation.date.hour; // debug
        //cout << ", currentDate: " << currentDate.day << currentDate.hour << endl; // debug
        //cout << lessEqual(tempReservation.date, currentDate) << endl; // debug
        if (lessEqual(tempReservation.date, currentDate) == false)
        {
            //cout << "reservations.push_back(tempReservation);" << endl; // debug
            reservations.push_back(tempReservation);
        }
    }

    inputFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    // int offset = 3 * 24 * 60 * 60 - 5 * 60 * 60;
    //int offset = 3 * 24 * 60 * 60;
    int offset = 2 * 24 * 60 * 60;
    time_t rawTime = time(0) - offset;
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year > date2.year) // 2026 > 2025
    {
        return false;
    }
    else if (date1.year < date2.year)
        return true;
    else // date1.year == date2.year
    {
        if (date1.month > date2.month) // 2025.12 > 2025.11
            return false;
        else if (date1.month < date2.month)
            return true;
        else // date1.year == date2.year && date1.month == date2.month
        {
            if (date1.day >= date2.day) // 2025.12.31 >= 2025.12.30
                return false;
            else // if (date1.day <= date2.day)
                return true;
            //else // date1.year == date2.year && date1.month == date2.month && date1.day == date2.day
            //{
            //    if (date1.hour > date2.hour)
            //        return false;
            //    else // date1.hour <= date2.hour
            //        return true;
            //}
        }
    }
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');
    //cin >> string;

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    bool isLogin = false;
    for (int i = 0; i < memberDetails.size(); i++)
    {
        // compare idNumber
        if (strcmp(memberDetails.at(i).idNumber, idNumber) == 0)
        {
            // existed idNumber, compare password
            if (strcmp(memberDetails.at(i).name, password) == 0)
            {
                // existed idNumber and existed password
                isLogin = true;
                return isLogin;
            }
        }
    }

    cout << "\nInvalid account number or password. Please try again.\n\n";
    return isLogin;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    // --- My code ---

    for (int i = 1; i <= 18; i++)
        cout << i << ". " << branchNames[i] << endl;

    int choice = 0;
    do
    {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice;
    } while (choice < 0 || choice > 18);
    cin.ignore();

    if (choice == 0)
        return;
    newReservation.branchCode = choice;

    Date currentHour = compCurrentDate();
    cout << "\nThe current hour is " << currentHour.year << "/" << currentHour.month << "/" << currentHour.day << ":" << currentHour.hour << endl;

    Date availableDates[8]; // use 1 ~ 7
    cout << "\nAvailable days:\n";
    compAvailableDates(availableDates);
    for (int i = 1; i <= 7; i++)
        cout << i << ". " << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << endl;

    do
    {
        cout << "Enter your choice(0 to end) : ";
        cin >> choice;
    } while (choice < 0 || choice > 7);
    cin.ignore();

    if (choice == 0)
        return;

    newReservation.date = availableDates[choice];

    // enter hour
    int beginHour = 0;
    int endHour = 23;

    if (currentHour.year == newReservation.date.year && currentHour.month == newReservation.date.month && currentHour.day == newReservation.date.day && currentHour.hour < 23)
        beginHour = currentHour.hour + 1;

    do
    {
        cout << "Enter hour (" << beginHour << "~" << endHour << "): ";
        cin >> choice;
    } while (choice < beginHour || choice > endHour);
    cin.ignore();
    newReservation.date.hour = choice;

    do
    {
        cout << "Enter the number of customers (1~30, 0 to end): ";
        cin >> choice;
    } while (choice < 0 || choice > 30);
    cin.ignore();

    if (choice == 0)
        return;

    newReservation.numCustomers = choice;

    // --- My code ---

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    if (currentDate.hour < 23)
    {
        for (int i = 1; i <= 7; i++)
        {
            availableDates[i].year = currentDate.year;
            availableDates[i].month = currentDate.month;
            availableDates[i].day = currentDate.day + i - 1;
        }
    }
    else // currentDate.hour == 23
    {
        for (int i = 1; i <= 7; i++)
        {
            availableDates[i].year = currentDate.year;
            availableDates[i].month = currentDate.month;
            availableDates[i].day = currentDate.day + i;
        }
    }

    // deal with day overflow
    // ���~
    int month[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    for (int i = 1; i <= 7; i++)
    {
        // �|�~
        if ((availableDates[i].year % 4 == 0 && availableDates[i].year % 100 != 0) || (availableDates[i].year % 400 == 0))
            month[2] = 29;
        else // ���~
            month[2] = 28;

        if (availableDates[i].day > month[availableDates[i].month])
        {
            availableDates[i].day -= month[availableDates[i].month];
            availableDates[i].month++;
        }

        if (availableDates[i].month > 12)
        {
            availableDates[i].month -= 12;
            availableDates[i].year++;
        }
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    int choice = 0;

    if (reservations.size() == 0)
    {
        cout << "\nNo reservations!\n";
        return;
    }
    else // reservations.size() != 0
    {
        cout << endl << setw(28) << "Branch"
            << setw(14) << "Date" << setw(8) << "Hour"
            << setw(19) << "No of Customers" << endl;

        for (int i = 1; i <= reservations.size(); i++)
        {
            cout << i << ".";
            output(reservations.at(i - 1));
        }

        do
        {
            cout << "Choose a reservation to cancel (0: keep all reservations): ";
            cin >> choice;
        } while (choice < 0 || choice > reservations.size());
        cin.ignore();

        if (choice == 0)
            return;
        else
        {
            int index = choice - 1;
            reservations.erase(reservations.begin() + index);
        }
    }
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(memberDetails.at(i).idNumber, idNumber) == 0)
            return true;
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outputFile("Members.dat", ios::out | ios::trunc | ios::binary);

    if (outputFile.fail() == true)
    {
        cout << "saveMemberDetails File could not be load.";
        exit(1);
    }

    for (int i = 0; i < memberDetails.size(); i++)
    {
        //cout << memberDetails.at(i).idNumber << endl; // debug
        outputFile.write(reinterpret_cast<const char*>(&memberDetails.at(i)), sizeof(MemberRecord));
    }

    outputFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outputFile("Reservations.dat", ios::out | ios::trunc | ios::binary);

    if (outputFile.fail() == true)
    {
        cout << "saveReservations File could not be load.";
        exit(1);
    }

    for (int i = 0; i < reservations.size(); i++)
    {
        outputFile.write(reinterpret_cast<const char*>(&reservations.at(i)), sizeof(ReservationRecord));
    }

    outputFile.close();
}