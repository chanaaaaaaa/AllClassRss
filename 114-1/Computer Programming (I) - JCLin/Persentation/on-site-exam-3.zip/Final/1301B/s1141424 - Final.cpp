#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream M("Members.dat", ios::binary);
    if (!M)
    {
        cout << "Members.dat could not be opened.\n";
        exit(0);
    }
    M.clear();
    M.seekg(0, ios::end);
    int Msize = M.tellg();
    M.seekg(0, ios::beg);
    MemberRecord m;
    for (int i = 0; i < Msize / sizeof(MemberRecord); i++)
    {
        M.read(reinterpret_cast<char*>(&m), sizeof(MemberRecord));
        memberDetails.push_back(m);
    }
    M.close();
    return;
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream R("Reservations.dat", ios::binary);
    if (!R)
    {
        cout << "Reservations.dat could not be opened.\n";
        exit(0);
    }
    R.seekg(0, ios::end);
    R.clear();
    int Rsize = R.tellg();
    R.seekg(0, ios::beg);
    ReservationRecord r;
    Date currentDate = compCurrentDate();
    for (int i = 0; i < Rsize / sizeof(ReservationRecord); i++)
    {
        R.read(reinterpret_cast<char*>(&r), sizeof(ReservationRecord));
        if (lessEqual(currentDate, r.date))
            reservations.push_back(r);
    }
    R.close();
    return;
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    long long totalD1 = 0, totalD2 = 0;
    //totalD1
    int Monthdays[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    Monthdays[2] = (date1.year % 400 == 0 || (date1.year % 4 == 0 && date1.year % 100 != 0)) ? 29 : 28;
    for (int i = 1900; i < date1.year; i++)
    {
        int day = (i % 400 == 0 || (i % 4 == 0 && i % 100 != 0)) ? 366 : 365;
        totalD1 += day;
    }
    for (int i = 1; i < date1.month; i++)
        totalD1 += Monthdays[i];
    totalD1 += date1.day;
    //totalD2
    Monthdays[2] = (date2.year % 400 == 0 || (date2.year % 4 == 0 && date2.year % 100 != 0)) ? 29 : 28;
    for (int i = 1900; i < date2.year; i++)
    {
        int day = (i % 400 == 0 || (i % 4 == 0 && i % 100 != 0)) ? 366 : 365;
        totalD2 += day;
    }
    for (int i = 1; i < date2.month; i++)
        totalD2 += Monthdays[i];
    totalD2 += date2.day;
    //diff
    int diff = totalD1 - totalD2;
    if (diff < 0)
        return true;
    else if (diff == 0)
        return true;
    else
        return false;
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 && strcmp(password, memberDetails[i].password) == 0)
            return true;
    }
    cout << "Invalid account number or password. Please try again.\n";
    return false;
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;
   strcpy_s(newReservation.idNumber, sizeof(idNumber), idNumber);
   Date currentDate = compCurrentDate(), choiceDate[7] = {};
   int Bchoice = 0;
   for (int i = 1; i <= 18; i++)
       cout << setw(2) << i << ". " << branchNames[i] << "\n";
   cout << "\n";
   do
   {
       cout << "Enter your choice (0 to end): ";
       cin >> Bchoice;
       //end
       if (Bchoice == 0)
       {
           cin.ignore();
           return;
       }
   } while (Bchoice < 1 || Bchoice > 18);
   newReservation.branchCode = Bchoice;
   cout << "The current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ": " << currentDate.hour << "\n";
   //Date
   int Dchoice = 0, year = currentDate.year, month = currentDate.month, day = currentDate.day;
   int Monthdays[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
   Monthdays[2] = (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) ? 29 : 28;
   for (int i = 0; i < 7; i++)
   {
       if (day > Monthdays[month])
       {
           day -= Monthdays[month];
           month++;
           if (month > 12)
           {
               month -= 12;
               year++;
           }
       }
       choiceDate[i] = { year, month, day, 0};
       day++;
   }
   choiceDate[0].hour = currentDate.hour + 1;
   if (choiceDate[0].hour > 23)
   {
       for (int i = 0; i < 7; i++)
       {
           choiceDate[i].day++;
           choiceDate[i].hour = 0;
           if (choiceDate[i].day > Monthdays[choiceDate[i].month])
           {
               choiceDate[i].day -= Monthdays[choiceDate[i].month];
               choiceDate[i].month++;
               if (choiceDate[i].month > 12)
               {
                   choiceDate[i].month -= 12;
                   choiceDate[i].year++;
               }
           }
       }
   }
   cout << "Available days:\n";
   compAvailableDates(choiceDate);
   do
   {
       cout << "Enter your choice (0 to end): ";
       cin >> Dchoice;
       if (Dchoice == 0)
       {
           cin.ignore();
           return;
       }
   } while (Dchoice < 1 || Dchoice > 7);
   newReservation.date = choiceDate[Dchoice - 1];
   //hour
   int Hchoice = 0;
   do
   {
       cout << "Enter hour (" << choiceDate[Dchoice - 1].hour << "~" << 23 << "): ";
       cin >> Hchoice;
   } while (Hchoice < choiceDate[Dchoice - 1].hour || Hchoice > 23);
   newReservation.date.hour = Hchoice;
   //customers
   int cus = 0;
   do
   {
       cout << "Enter the number of customers (1~30, 0 to end): ";
       cin >> cus;
       if (cus == 0)
       {
           cin.ignore();
           return;
       }
   } while (cus < 0 || cus > 30);
   newReservation.numCustomers = cus;
   //
   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
   cin.ignore();
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();
   for (int i = 0; i < 7; i++)
       cout << setw(2) << i + 1 << ". " << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << "\n";
   return;
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();
   vector <ReservationRecord> myRservations;
   int choice = 0;
   bool exit = false;
   for (int i = 0; i < reservations.size(); i++)
   {
       if (strcmp(reservations[i].idNumber, idNumber) == 0)
       {
           myRservations.push_back(reservations[i]);
           exit = true;
       }
   }
   if (!exit)
   {
       cout << "No reservations!\n";
       return;
   }
   cout << setw(26) << "Branch" << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;
   for (int i = 0; i < myRservations.size(); i++)
   {
       cout << setw(2) << i + 1 << ". ";
       output(myRservations[i]);
   }
   //
   do
   {
       cout << "Choose a reservation to cancel (0: keep all reservations): ";
       cin >> choice;
       if (choice == 0)
       {
           cin.ignore();
           return;
       }
   } while (choice < 0 || choice > myRservations.size());
   //
   for (int i = 0; i < reservations.size(); i++)
   {
       if (reservations[i].branchCode == myRservations[choice - 1].branchCode
           && reservations[i].numCustomers == myRservations[choice - 1].numCustomers
           && strcmp(reservations[i].idNumber, myRservations[choice - 1].idNumber) == 0
           && reservations[i].date.day == myRservations[choice - 1].date.day
           && reservations[i].date.hour == myRservations[choice - 1].date.hour
           && reservations[i].date.year == myRservations[choice - 1].date.year
           && reservations[i].date.month == myRservations[choice - 1].date.month)
       {
           reservations.erase(reservations.begin() + i);
           break;
       }
   }
   cin.ignore();
   return;
}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
            return true;
    }
    return false;
}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream M("Members.dat", ios::binary);
    if (!M)
    {
        cout << "Members.dat could not be opened.\n";
        exit(0);
    }
    M.seekp(0, ios::beg);
    M.clear();
    for (int i = 0; i < memberDetails.size(); i++)
    {
        MemberRecord m = memberDetails[i];
        M.write(reinterpret_cast<char*>(&m), sizeof(MemberRecord));
    }
    M.close();
}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream R("Reservations.dat", ios::binary);
    if (!R)
    {
        cout << "Reservations.dat could not be opened.\n";
        exit(0);
    }
    R.seekp(0, ios::beg);
    R.clear();
    for (int i = 0; i < reservations.size(); i++)
    {
        ReservationRecord r = reservations[i];
        R.write(reinterpret_cast<char*>(&r), sizeof(ReservationRecord));
    }
    R.close();
}