#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream loadMemberFile("Members.dat", ios::in | ios::binary);

    if (!loadMemberFile) {
        cout << "Members.dat could not be open" << endl;
        system("pause");
        exit(1);
    }

    MemberRecord member;
    
    while (loadMemberFile.read(reinterpret_cast<char*>(&member), sizeof(MemberRecord))) {
      
        memberDetails.push_back(member);
    }
    


    loadMemberFile.close();

    return;
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream loadReservationFile("Reservations.dat", ios::in | ios::binary);

    if (!loadReservationFile) {
        cout << "Reservations.dat could not be open" << endl;
        system("pause");
        exit(1);
    }

    ReservationRecord reservation;

    int loadReservationNumber = 0;


    while (loadReservationFile.read(reinterpret_cast<char*>(&reservation), sizeof(ReservationRecord))) {

        Date currentDate = compCurrentDate();

        reservations.push_back(reservation);

        if (!lessEqual(reservations[loadReservationNumber].date , currentDate)) {

            loadReservationNumber++;

        }
    }

    loadReservationNumber--;

    loadReservationFile.close();
    return;



}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    if (date1.year < date2.year)
    {
        return true;
    }
    else if (date1.year == date2.year) 
    {
        if (date1.month < date2.month) 
        {
            return true;
        }
        else if (date1.month == date2.month)
        {
            if(date1.day < date2.day)
            {
                return true;
            }
            else if(date1.day == date2.day)
            {
                if (date1.hour <= date2.hour)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    else 
    {
        return false;
    }

}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i <= memberDetails.size(); i++) {

        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 && strcmp(password , memberDetails[i].password) == 0) {

            return true;
        }
        else {

            cout << "Invalid account number or password. Please try again." << endl;

            return false;
        }
    }

}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;

   for (int i = 0; i <= 17; i++) {
       cout << i+1<<". " << branchNames[i] << endl;
   }

   int choice1;

   do {
       cout << "Enter your choice( 0 to end ): ";
       cin >> choice1;
       cout << endl;

       if (choice1 == 0) {
           return;
       }

   } while (choice1 > 18);

   Date currentDate = compCurrentDate();
   cout << "The current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;
   cout << "Available days:" << endl;
   cout << endl;

   Date availableDates[1] ;

   if (currentDate.hour == 23) {
       availableDates->day = currentDate.day + 1;
       availableDates->hour = 0;
   }
   else {
       availableDates->day = currentDate.day;
       availableDates->hour = currentDate.hour;
   }

   availableDates->month = currentDate.month;
   availableDates->year = currentDate.year;

   compAvailableDates(availableDates);

   Date coutDate[1];
   coutDate->year = availableDates->year;
   coutDate->month = availableDates->month;
   coutDate->day = availableDates->day;
   coutDate->hour = availableDates->hour;


   for (int i = 1; i <= 7; i++) {
       compAvailableDates(coutDate);
       cout << i << ". " << coutDate->year << "/" << coutDate->month << "/" << coutDate->day << endl;
       coutDate->day = coutDate->day + 1;
       
   }

   int choice2;

   do{
       cout << "Enter your choice (0 to end): ";
       cin >> choice2;
       cout << endl;

       if (choice2 == 0) 
       {
           return;
       }

   } while (choice2 > 7);
   
   int enterHour;

   do {
       cout << "Enter hour ("<<availableDates->hour<<"~23): ";
       cin >> enterHour;
       cout << endl;
   } while (enterHour < availableDates->hour || enterHour > 23);

   availableDates->day = availableDates->day + choice2 - 1;

   compAvailableDates(availableDates);

   int enterCustomers;

   do {
       cout << "Enter the number of customers (1~30, 0 to end): ";
       cin >> enterCustomers;
       cout << endl;

   } while (enterCustomers < 1 || enterCustomers > 30);

   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   newReservation.branchCode = choice1;
   newReservation.numCustomers = enterCustomers;
   newReservation.date.year = availableDates->year;
   newReservation.date.month = availableDates->month;
   newReservation.date.day = availableDates->day;
   newReservation.date.hour = enterHour;
   for (int i = 0; i <= 11; i++) {

       newReservation.idNumber[i] = idNumber[i];
   }


   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();

   
   
   bool leapYear;

   if (availableDates->year % 400) {
       leapYear = true;
   }
   else if (availableDates->year % 4 == 0 && availableDates->year % 100 != 0) {
       leapYear = true;
   }
   else {
       leapYear = false;
   }

   if (leapYear) {

       if (availableDates->month == 4 || availableDates->month == 6 || availableDates->month == 9 || availableDates->month == 11) {
           if (availableDates->day > 30) {
               availableDates->day = 1;
               availableDates->month = availableDates->month + 1;
           }
       }
       else if (availableDates->month == 2) {
           if (availableDates->day > 29) {
               availableDates->day = 1;
               availableDates->month = availableDates->month + 1;
           }
       }
       else {
           if (availableDates->day > 31) {
               availableDates->day = 1;
               availableDates->month = availableDates->month + 1;
           }
       }

   }
   else {
       if (availableDates->month == 4 || availableDates->month == 6 || availableDates->month == 9 || availableDates->month == 11) {
           if (availableDates->day > 30) {
               availableDates->day = 1;
               availableDates->month = availableDates->month + 1;
           }
       }
       else if (availableDates->month == 2) {
           if (availableDates->day > 28) {
               availableDates->day = 1;
               availableDates->month = availableDates->month + 1;
           }
       }
       else {
           if (availableDates->day > 31) {
               availableDates->day = 1;
               availableDates->month = availableDates->month + 1;
           }
       }
   }

   if (availableDates->month > 12) {
       availableDates->month = 1;
       availableDates->year = availableDates->year + 1;
   }
   else {
       availableDates->year = availableDates->year;
   }

}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();

   cout << endl << setw(26) << "Branch"
       << setw(14) << "Date" << setw(8) << "Hour"
       << setw(19) << "No of Customers" << endl;

   int k = 0;

   for (int i = 0; i <= reservations.size(); i++) {
       if (strcmp( idNumber , reservations[i].idNumber)==0) {

           k++;
           cout << k << ".";

           output(reservations[i]);
       }
   }

   int choice;

   do {
       cout << " Choose a reservation to cancel(0: keep all reservations) : ";
       cin >> choice;
       cout << endl;
       if (choice == 0) {
           return;
       }
   } while (choice > k);

   for (int i = 0; i <= reservations.size(); i++) {
       if (strcmp(idNumber, reservations[i].idNumber) == 0) {

           k++;
           if (k == choice) {
               for (int j = i; j <= reservations.size(); j++) {
                   reservations[j] = reservations[j + 1];
               }
               
           }
       }
   }

}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }
   
   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";

 
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i <= memberDetails.size(); i++) {
        
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {

            return true;
        }
        else {

            return false;
        }
    }


}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream saveMemberFile("Members.dat" , ios::out | ios::binary);

    if (!saveMemberFile) {
        cout << "Reservations.dat could not be open" << endl;
        system("pause");
        exit(1);
    }

    int memberNumber = 0;

    vector<MemberRecord> member;

    member = memberDetails;

    while (saveMemberFile.write(reinterpret_cast<char*>(&member[memberNumber]), sizeof(MemberRecord))) {
        memberNumber++;
    }

    saveMemberFile.close();

}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream saveReservationFile("Reservations.dat", ios::out | ios::binary);

    if (!saveReservationFile) {
        cout << "Reservations.dat could not be open" << endl;
        system("pause");
        exit(1);
    }

    int ReservationsNumber = 0;

    vector<ReservationRecord> reservation;

    reservation = reservations;

    while (saveReservationFile.write(reinterpret_cast<char*>(&reservation[ReservationsNumber]), sizeof(ReservationRecord))) {
        ReservationsNumber++;
    }

    saveReservationFile.close();

}