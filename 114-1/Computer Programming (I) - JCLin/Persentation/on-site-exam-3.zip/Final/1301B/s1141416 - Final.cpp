#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream inFile("Members.dat", ios::binary);

    inFile.read(reinterpret_cast<char*>(&memberDetails), sizeof(MemberRecord));

    inFile.close();
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream inFile("Reservations.dat", ios::binary);

    inFile.read(reinterpret_cast<char*>(&reservations), sizeof(ReservationRecord));

    inFile.close();
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    if (date1.year <= date2.year || date1.month <= date2.month || date1.day < date2.day)
        return true;

    if (date1.day == date2.day)
    {
        if (date1.hour < date2.hour)
            return true;
        else
            return false;
    }

    return false;
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    ifstream inFile("Members.dat", ios::binary);

    MemberRecord Id;

    int found = false;

    if (!inFile)
        cout << "Members.dat could not be opened." << endl;

    while (inFile.read(reinterpret_cast<char*>(&Id), sizeof(MemberRecord)))
    {
        if (strcmp(Id.idNumber, idNumber) == 0 &&
            strcmp(Id.password, password) == 0)
            found = true;
        else
            found = false;
    }

    if (!found)
        cout << "\nInvalid account number or password. Please try again.\n\n";

    return found;
    inFile.close();
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;

   int count = 0;

   ifstream inFile("Reservations.dat", ios::binary);
   while (inFile.read(reinterpret_cast<char*>(&newReservation), sizeof(ReservationRecord)))
   {
       count++;
       cout << count << ". " << branchNames[count] << endl;
   }

   if (!inFile)
       cout << "\nReservations.dat could not be opened.\n";

   int choice;

   do {
       cout << "\nEnter your choice (0 to end): ";
       cin >> choice;

       if (choice == 0)
       {
           break;
       } 
   } while ((choice = inputAnInteger(1, 18)) == -1);

   cout << "\nThe current hour is ";
   cout << compCurrentDate().year << "/" << compCurrentDate().month << "/" << compCurrentDate().day << ":" << compCurrentDate().hour << endl;

   Date availableDate = compCurrentDate();
   compAvailableDates(&availableDate);

   int numCustomers;
   do {
       cout << "Enter the number of customers (1~30, 0 to end): ";
       cin >> numCustomers;
       if (numCustomers == 0)
       {
           break;
       }
   } while ((numCustomers = inputAnInteger(1, 30)) == -1);

   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();

   int daysInMonth[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
   if ((currentDate.year) % 400 == 0 || ((currentDate.year) % 4 == 0 && (currentDate.year) % 100 != 0))
       daysInMonth[2] = 29;

   int monthShift = 0;
   if (currentDate.day >= daysInMonth[currentDate.month])
       monthShift = 1;
   
   cout << "\nAvailable days:\n";

   for (int i = 1; i <= 7; i++)
   {
       availableDates->year = currentDate.year - 1900;
       availableDates->month = currentDate.month - 1;
       availableDates->day = currentDate.day;

       if (availableDates->month > 12)
       {
           availableDates->year++;
           availableDates->month -= 12;
       }

       if ((currentDate.year) % 400 == 0 || ((currentDate.year) % 4 == 0 && (currentDate.year) % 100 != 0))
           daysInMonth[2] = 29;

       cout << i++ << ". " << availableDates->year << "/" << availableDates->month << "/" << availableDates->day << endl;
   }

   int mainChoice;
   do {
       cout << "\nEnter your choice (0 to end): ";
       cin >> mainChoice;
       if (mainChoice == 0)
       {
           break;
       }
   } while ((mainChoice = inputAnInteger(1, 7)) == -1);

   int displayYear, displayMonth, displayDay;
   displayYear = currentDate.year - 1900;
   displayMonth = currentDate.month + monthShift + mainChoice - 1;
   displayDay = currentDate.day;

   int displayTime;
   if (currentDate.day == compCurrentDate().day)
       displayTime = compCurrentDate().hour + 1;
   else
       displayTime = 0;

   int startTime = displayTime;
   int endTime = 23;
   int chooseTime;

   do {
       cout  << "Enter hour (" << displayTime << "~23): ";
       cin >> chooseTime;
   } while (chooseTime<startTime || chooseTime>endTime);
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();
   ifstream inFile("Reservations.dat", ios::binary);
   ofstream outFile("Reservations.dat", ios::out | ios::binary);

   if (!inFile)
       cout << "\nNo reservations!\n";

   ReservationRecord reservation;
   while (inFile.read(reinterpret_cast<char*>(&reservation), sizeof(ReservationRecord)))
   {
       if (lessEqual(reservation.date, currentDate))
           continue;
       outFile.write(reinterpret_cast<char*>(&reservation), sizeof(ReservationRecord));
   }
   
   inFile.close();
   outFile.close();
}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    int found = false;
    ifstream inFile("Members.dat", ios::binary);

    MemberRecord memberDetail;

    while (inFile.read(reinterpret_cast<char*>(&memberDetail), sizeof(MemberRecord)))
    {
        if (strcmp(memberDetail.idNumber, idNumber) == 0)
        {
            found = true;
        }
    }

    return found;
    inFile.close();
}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ifstream inFile("Members.dat", ios::binary);
    ofstream outFile("Members.dat", ios::out | ios::binary);
    
    MemberRecord memberDetail;
    outFile.write(reinterpret_cast<const char*>(&memberDetail), sizeof(MemberRecord));
    
    inFile.close();
    outFile.clear();
    outFile.seekp(0, ios::beg);
    outFile.close();
}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ifstream inFile("Members.dat", ios::binary);
    ofstream outFile("Reservations.dat", ios::out | ios::binary);
    Date currentDate = compCurrentDate();

    ReservationRecord reservation;
    while (inFile.read(reinterpret_cast<char*>(&reservation), sizeof(ReservationRecord)))
    {
        if (lessEqual(reservation.date, currentDate))
            continue;
        outFile.write(reinterpret_cast<char*>(&reservation), sizeof(ReservationRecord));
    }

    inFile.close();
    outFile.clear();
    outFile.seekp(0, ios::beg);
    outFile.close();
}