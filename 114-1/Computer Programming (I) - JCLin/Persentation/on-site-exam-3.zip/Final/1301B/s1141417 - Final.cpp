#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    int num = 0;
    ifstream infile("Members.dat", ios::in | ios::binary);

    if (!infile) {
        cout << "loadMemberDetails error";
    }

    MemberRecord memberrecord;
    while (infile.read(reinterpret_cast<char*>(&memberrecord), sizeof(MemberRecord))) {
        num++;
        memberDetails[num] = memberrecord;

    }

    infile.close();

}

void loadReservations(vector< ReservationRecord >& reservations)
{
    int num = 0;
    ifstream infile("Reservations.dat", ios::in | ios::binary);

    if (!infile) {
        cout << "loadReservations error";
    }

    ReservationRecord reservationrecord;
    while (infile.read(reinterpret_cast<char*>(&reservationrecord), sizeof(ReservationRecord))) {
        num++;
        reservations[num] = reservationrecord;

    }

    infile.close();

}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}
// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year) {
        return true;
    }
    else if (date1.year == date2.year) {
        if (date1.month < date2.month) {
            return true;
        }
        else if (date1.month == date2.month) {
            if (date1.day < date2.day) {
                return true;
            }
            else if (date1.day == date2.day) {
                if (date1.hour <= date2.hour) {
                    return true;
                }
                else return false;
            }
            else return false;
        }
        else return false;

    }
    else return false;


}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}
// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    bool val = false;
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 && strcmp(password, memberDetails[i].password) == 0) {
            return true;
        }
        else {
            val = false;
        }
    }
    cout << "\nInvalid account number or password. Please try again." << endl;
    return val;


}
// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    strcpy_s(newReservation.idNumber, idNumber);

    for (int i = 1; i < 19; i++) {
        cout << setw(2) << i << ". " << branchNames[i] << endl;
    }

    int choice;
    do {
        cout << "\nEnter your choice (0 to end):";
        cin >> choice;
    } while (choice > 19 && choice < 0);

    newReservation.branchCode = choice;

    //compAvailableDates(newReservation.date[]);

    int customers;
    do {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> customers;
        if (customers == 0)  break;
    } while (customers < 0 && customers > 31);

    newReservation.numCustomers = customers;

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}
// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    int maxdays[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
    if (currentDate.year % 400 == 0) {
        if (currentDate.year % 100 != 0) {
            maxdays[2] = 29;
        }
    }
    else if (currentDate.year % 4 == 0) {
        if (currentDate.year % 100 != 0) {
            maxdays[2] = 29;
        }
    }
    int y = currentDate.year;
    int m = currentDate.month;
    int d = currentDate.day;
    int h = currentDate.hour;

    int outyear[7];
    int outmonth[7];
    int outday[7];


    cout << "\nAvailable days:\n";

    for (int i = 1; i < 8; i++) {
        cout << setw(2) << i << y << "/" << m << "/" << d << "/" << endl;
        outyear[i] = y;
        outmonth[i] = m;
        outday[i] = d;
        d++;
        if (d > maxdays[m]) {
            m++;
            d = 1;
        }
        if (m > 12) {
            y++;
            m = 1;
        }
    }

    int choice;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice;
    } while (choice < 8 && choice > 0);
    //sprintf(availableDates[], 12, "%d/%d/%d", outyear[choice], outmonth[choice], outday[choice]);
    int inputhour;

    if (outday[choice] > currentDate.day) {
        h = 0;
    }
    if (h + 1 > 23) {
        h = 0;
    }
    do {
        cout << "\nEnter hour (" << h << "~" << 23 << "): ";

        cin >> inputhour;
    } while (inputhour > h && inputhour < 23);
    availableDates->hour = inputhour;

}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{

    ifstream infile("Reservations.dat", ios::in | ios::binary | ios::app | ios::out);
    ofstream outfile("Reservations.dat", ios::in | ios::binary | ios::app | ios::out);
    ReservationRecord reservation;
    Date currentDate = compCurrentDate();
    int num = 0;

    while (infile.read(reinterpret_cast<char*>(&reservation), sizeof(ReservationRecord))) {
        num++;
        reservations[num] = reservation;
    }

    infile.close();

    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(idNumber, reservations[i].idNumber) == 0) {
            if (lessEqual(reservations[i].date, currentDate)) {
                output(reservation);
            }
        }
    }
    int choice;
    do {
        cout << "Choose a reservation to cancel (0: keep all reservations):";
        cin >> choice;

        if (choice > 0 && choice <= reservations.size()) {
            outfile.seekp(-static_cast<int>(sizeof(ReservationRecord), ios::cur));
            outfile.write(reinterpret_cast<const char*>(&reservation), sizeof(ReservationRecord));
        }
    } while (choice >= 0 && choice <= reservations.size());

}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    MemberRecord memberrecord;
    bool exist = false;
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {
            return true;
        }
        else exist = false;
    }
    return exist;



}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    MemberRecord memberrecord;

    ofstream outfile("Members.dat", ios::out | ios::binary);

    if (!outfile) {
        cout << "saveMemberDetails error";
    }


    outfile.write(reinterpret_cast<const char*>(&memberrecord), sizeof(MemberRecord));
    outfile.close();



}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ReservationRecord reservationrecord;

    ofstream outfile("Reservations.dat", ios::out | ios::binary);

    if (!outfile) {
        cout << "saveReservations error";
    }
    outfile.write(reinterpret_cast<const char*>(&reservationrecord), sizeof(ReservationRecord));
    outfile.close();

}