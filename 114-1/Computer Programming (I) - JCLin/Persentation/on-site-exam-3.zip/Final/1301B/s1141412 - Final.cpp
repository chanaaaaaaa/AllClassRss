#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations ); //�L�����������n

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

bool leapYear(int year);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile)
        return;
    MemberRecord currentRecord;
    int i = 0;
    while (inFile.read(reinterpret_cast<char*>(&currentRecord), sizeof(MemberRecord))){
        i++;
         memberDetails = currentRecord;
    }
    inFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::binary);
    if (!inFile)
        return;
    ReservationRecord currentReservation;
    int i = 0;
    while (inFile.read(reinterpret_cast<char*>(&currentReservation), sizeof(ReservationRecord))) {
        if (!lessEqual) {
            inFile.seekg(inFile.tellg() - sizeof(ReservationRecord));
            break;
        }
        i++;
        reservations[i] = currentReservation;
        inFile.close();
    }

}
Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

//true = date2>date1
bool lessEqual( const Date &date1, const Date &date2 )
{ 
    if (date1.year > date2.year)
        return false;
    else if (date1.year == date2.year) {
        if (date1.month > date2.month)
            return false;
        else if (date1.month == date2.month) {
            if (date1.day > date2.day)
                return false;
            else
                return true;
        }
        else
            return true;
    }
    else
        return true;

}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{ 
    if (memberDetails[memberDetails.size()].idNumber == idNumber && memberDetails[memberDetails.size()].password == password)
        return true;
    else
        return false;

}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    for (int i = 1; i <= 18; i++) {
        cout << setw(2) << i << ". " << branchNames[i] << endl;
    }

    int targetplace;
    do {
        cout << "Enter your choice (0 to end): ";
        cin >> targetplace;

        if (targetplace == 0)
            break;
    } while (targetplace > 18 || targetplace < 0);

    Date compCurrentDate;

    cout << "The current hour is " << compCurrentDate.hour << endl;

    compAvailableDates(compCurrentDate.day);

    cout << "Enter the number of customers (1~30, 0 to end):";
    
    int records = 0;
    for (int i = 0; i <= reservations.size(); i++) {
        if (newReservation.idNumber == idNumber && reservations[i].idNumber == idNumber) {
            for (int j = 0; j <= newReservation.numCustomers; j++) {
                if (newReservation.idNumber == idNumber && reservations[j].idNumber == idNumber) {
                    records = newReservation.numCustomers;
                }
            }
        }
    }

    if (records > 0) {
        cout << endl << setw(26) << "Branch"
            << setw(14) << "Date" << setw(8) << "Hour"
            << setw(19) << "No of Customers" << endl;

        output(newReservation);

        cout << "\nReservation Completed!\n";

        reservations.push_back(newReservation);
    }
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    int choice;
    int tempmonthdays[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
    if ((currentDate.month == 2) && leapYear(currentDate.year))
        tempmonthdays[2] = 29;

    int startoffset;
    if (currentDate.day == tempmonthdays[currentDate.month] )
        startoffset = 1;
    else
        startoffset = 0;

    do {
        cout << "Available days:";
        for (int i = 0; i < 7; i++) {
            int m = (i + currentDate.month + startoffset - 1) % 12 + 1;
            int y = currentDate.year + (i + currentDate.month + startoffset - 1) / 12;
            int d = currentDate.day + i;
            cout << i+1 << ". " << y << "/" << m << "/" << d << endl;
        }

        cout << "Enter your choice (0 to end):" << endl;
        cin >> choice; 

        if (choice == 0)
            break;
    } while (choice < 1 || choice >7);

    int targetMonth = (choice + currentDate.month + startoffset - 1) % 12 + 1;
    int targetYear = currentDate.year + (choice + currentDate.month + startoffset - 1) / 12;
    int targetDay = currentDate.day + choice;

    int monthdays[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
    if (targetMonth == 2 && leapYear(currentDate.year))
        monthdays[targetMonth] = 29;

    int starthour;
    if (currentDate.hour==23)
        starthour = 0;
    else
        starthour = currentDate.hour+1 ;

    int endhour = 23;
    int targetDay;
    do {
        cout << "Enter hour ( " << starthour << " - " << endhour << " ): " << endl;
        cin >> targetDay;
    } while (targetDay < starthour || targetDay > endhour);
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();

   int choice;
   do {
       cout << "Choose a reservation to cancel (0: keep all reservations):";
       cin >> choice;

       if (choice == 0)
           break;
   } while (choice<0 || choice > reservations.size());

   ofstream outFile("Reservations.dat", ios::binary | ios::trunc);

   if (outFile) {
       for (int i = 0; i <= reservations.size(); i++) {
           if (choice != idNumber[i])
               outFile.write(reinterpret_cast<char*>(&reservations[reservations.size()], sizeof(ReservationRecord)));
       }
   }
   outFile.close();
}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    bool found = false;

    for (int i = 0; i <= memberDetails.size(); i++) {
        if (idNumber[i] == memberDetails[i].idNumber) {
            found = true;
        }
        if (found)
            return;
    }
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::binary | ios::app);

    //int i;
    if (outFile) {
        while (outFile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord)))
     //i++

     outFile.close();
    }
}

void saveReservations(const vector< ReservationRecord > &reservations)
 {
     ofstream outFile("Reservations.dat", ios::binary | ios::app);

     if (outFile) {
         while (outFile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord)))

      outFile.close();
     }
}

bool leapYear(int year)
{
    return (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0));
}