#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream fin;
    fin.open("Members.dat", ios::in | ios::binary);
    if (!fin)
        cout << "error\n";

    MemberRecord Member;
    while (!fin.eof()) {
        fin.read(reinterpret_cast<char*>(&Member), sizeof(Member));
        memberDetails.push_back(Member);
    }

    fin.close();
  
    for (int i = 0; i < memberDetails.size(); i++)
        cout << memberDetails[i].idNumber <<"  "
        << memberDetails[i].name << "  "
        << memberDetails[i].password << "  "<<"\n";


}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream fin;
    fin.open("Reservations.dat", ios::in | ios::binary);
    if (!fin)
        cout << "error\n";

    ReservationRecord Reservation;
    while (!fin.eof()) {
        fin.read(reinterpret_cast<char*>(&Reservation), sizeof(Reservation));
        reservations.push_back(Reservation);
    }

    fin.close();

    
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    if (date1.year < date2.year)
        return true;
    else if (date1.year == date2.year) {        
        if (date1.month < date2.month)
            return true;
        else if (date1.month == date2.month){
            if (date1.day <= date2.day)
                return true;
            else
                return false;
        }
        else
            return false;
        
    }
    else
        return false;

    
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    //MemberRecord compare;
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0)
            if (strcmp(memberDetails[i].password, password) == 0)
                return true;
    }

    cout << "\nInvalid account number or password. Please try again.\n\n";
    return false;

}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;

   for (int i = 1; i < 19; i++)
   {
       cout << setw(3) << i << "."
            << " "<< branchNames[i] << endl;
   }

   int choice;
   do {
       cout << "\nEnter your choice (0 to end):";
       cin >> choice;
   } while (choice<0||choice>18);
   if (choice == 0) return;
   newReservation.branchCode = choice;
      
   compAvailableDates(&newReservation.date);
   if (newReservation.date.day == 0)
       return;

   do {
       cout << "\nEnter the number of customers (1~30, 0 to end):";
       cin >> choice;
   } while (choice < 0 || choice>30);
   if (choice == 0) return;
   newReservation.numCustomers = choice;

   cout << endl << setw( 26 ) << setfill(' ')<<"Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();   

   cout << "\nThe current hour is "
       << setw(4) << currentDate.year << "/"
       << setw(2) << setfill('0') << currentDate.month << "/"
       << setw(2) << setfill('0') << currentDate.day << ":"
       << setw(2) << setfill('0') << currentDate.hour << "\n\n";

   cout << "\nAvailable days:\n\n";

   vector<int> monthday = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
   int year = currentDate.year;
   if ((year % 400 == 0) || ((year % 4 == 0) && (year % 100 != 0)))
       monthday[2] = 29;

   vector<Date> choices(8);
   for (int i = 1; i < 8; i++)
   {
       cout << i << "." << " "
           << setw(4) << currentDate.year << "/"
           << setw(2) << setfill('0') << currentDate.month << "/"
           << setw(2) << setfill('0') << currentDate.day << "\n";
       choices[i] = currentDate;

       if (currentDate.month == 12 && currentDate.day == 31) {
           currentDate.year ++;
           currentDate.month = 1;
           currentDate.day = 1;
       }
       else if (currentDate.day == monthday[currentDate.month]) {
           currentDate.month++;
           currentDate.day = 1;
       }
       else
           currentDate.day ++;           
   }
   cout << "\n";

   int choice;
   do {
       cout << "\nEnter your choice (0 to end):";
       cin >> choice;
   } while (choice < 0 || choice>7);
   if (choice == 0) {
       availableDates->day = 0;
       return;
   }
   availableDates->year = choices[choice].year;
   availableDates->month = choices[choice].month;
   availableDates->day = choices[choice].day;

   int hourchoice;
   if (choice == 1) {
       do {
           cout << "\nEnter hour (" << currentDate.hour
               << "~23): ";
           cin >> hourchoice;
       } while (hourchoice < currentDate.hour || hourchoice>23);
       availableDates->hour = hourchoice;
   }
   else {
       do {
           cout << "\nEnter hour (0~23): ";
           cin >> hourchoice;
       } while (hourchoice < 0 || hourchoice>23);
       availableDates->hour = hourchoice;
   }


}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
    for (int i = 0; i < reservations.size(); i++)
    {
        if (strcmp(reservations[i].idNumber, idNumber) == 0)
            break;
        else {
            cout << "\nNo reservations!\n\n";
            return;
        }
    }
    //cur
    Date currentDate = compCurrentDate();

    cout << endl << setw(26) << setfill(' ') << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    int num = 0;
    vector<int> temp;
    for (int i = 0; i < reservations.size(); i++)
    {
        if (lessEqual(reservations[i].date, currentDate))
            continue;
        else {
            num++;
            cout << num << ".";
            output(reservations[i]);
            temp.push_back(i);
        }
    }

    int choice;
    do {
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
        cin >> choice;
    } while (choice < 0 || choice>num);
    if (choice == 0) return;
   


}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0)
            return true;
                
    }
    return false;


}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream outfile;
    outfile.open("Members.dat", ios::out | ios::binary);
    if (!outfile)
        cout << "error\n";

    MemberRecord Member;
    outfile.seekp(0, ios::beg);
    for (int i = 0; i < memberDetails.size(); i++) {
        Member = memberDetails[i];
        outfile.write(reinterpret_cast<char*>(&Member), sizeof(Member));
    }

    outfile.close();



}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream outfile;
    outfile.open("reservations.dat", ios::out | ios::binary);
    if (!outfile)
        cout << "error\n";

    ReservationRecord reservation;
    outfile.seekp(0, ios::beg);
    for (int i = 0; i < reservations.size(); i++) {
        reservation = reservations[i];
        outfile.write(reinterpret_cast<char*>(&reservation), sizeof(reservations));
    }

    outfile.close();



}