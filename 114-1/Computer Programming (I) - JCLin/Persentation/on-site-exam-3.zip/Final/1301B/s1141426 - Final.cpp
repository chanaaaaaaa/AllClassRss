#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

bool leapYear(int year);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}
// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream loadMemberFile("Members.dat", ios::in | ios::binary);
    MemberRecord blank = {};
    loadMemberFile.clear();
    while (loadMemberFile.read(reinterpret_cast<char*>(&blank), sizeof(MemberRecord))) {
        memberDetails.push_back(blank);
    }

}
// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream loadReservationsFile("Reservations.dat", ios::in | ios::binary);
    ReservationRecord in = {};
    loadReservationsFile.clear();
    Date currentDate = compCurrentDate();
    while (loadReservationsFile.read(reinterpret_cast<char*>(&in), sizeof(ReservationRecord))) {
        if (!lessEqual(in.date, currentDate)) {
            reservations.push_back(in);
        }
    }
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}
// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year) {
        return true;
    }
    else if (date1.year > date2.year) {
        return false;
    }
    else {
        if (date1.month < date2.month) {
            return true;
        }
        else if (date1.month > date2.month) {
            return false;
        }
        else {
            if (date1.day < date2.day) {
                return true;
            }
            else if (date1.day > date2.day) {
                return false;
            }
            else {
                return false;
            }
        }
    }



}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end || number == 0)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}
// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    MemberRecord in = {};
    for (int i = 0; i < memberDetails.size(); i++) {
        in = memberDetails[i];
        if (strcmp(in.idNumber, idNumber) == 0 && strcmp(in.password, password) == 0) {
            return true;
        }
    }
    cout << endl << "Invalid account number or password.Please try again." << endl << endl;
    return false;




}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation = {};
    strcpy(newReservation.idNumber, idNumber);

    for (int i = 1; i <= 18; i++) {
        cout << setw(2) << i << ". " << branchNames[i] << endl;
    }
    int placechoice;
    do {
        cout << "\nEnter your choice (0 to end): ";
    } while ((placechoice = inputAnInteger(1, 18)) == -1);
    if (placechoice == 0) return;
    newReservation.branchCode = placechoice;
    cout << endl;
    Date currentDate = compCurrentDate();
    cout << "The current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;
    cout << endl;
    Date availableDates[7];
    compAvailableDates(availableDates);
    cout << "Available days:" << endl;
    cout << endl;
    for (int i = 0; i <= 6; i++) {
        cout << i + 1 << ". " << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << endl;
    }
    int datechoice;
    do cout << "\nEnter your choice (0 to end): ";
    while ((datechoice = inputAnInteger(1, 7)) == -1);
    if (datechoice == 0) return;


    int hourchoice;
    if (availableDates[datechoice - 1].day == currentDate.day) {
        do {
            cout << endl << "Enter hour (" << availableDates[datechoice - 1].hour << "~23): ";
        } while ((hourchoice = inputAnInteger(availableDates[datechoice - 1].hour, 23)) == -1);
    }
    else {
        do cout << "\nEnter hour (0~23): ";
        while ((hourchoice = inputAnInteger(0, 23)) == -1);
    }
    newReservation.date = availableDates[datechoice - 1];
    newReservation.date.hour = hourchoice;

    int customerschoice;
    do cout << "\nEnter the number of customers(1~30, 0 to end): ";
    while ((customerschoice = inputAnInteger(1, 30)) == -1);
    if (customerschoice == 0) return;
    newReservation.numCustomers = customerschoice;





    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

bool leapYear(int year) {
    if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0) {
        return true;
    }
    else {
        return false;
    }
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    currentDate.hour++;
    if (currentDate.hour == 24) {
        currentDate.hour = 0;
        currentDate.day++;
    }

    if (currentDate.month == 1 || currentDate.month == 3 || currentDate.month == 5 || currentDate.month == 7
        || currentDate.month == 8 || currentDate.month == 10 || currentDate.month == 12) {
        if (currentDate.day > 31) {
            currentDate.day = 1;
            currentDate.month++;
        }
    }
    else if (currentDate.month == 2) {
        if (leapYear(currentDate.year)) {
            if (currentDate.day > 29) {
                currentDate.day = 1;
                currentDate.month++;
            }
        }
        else {
            if (currentDate.day > 28) {
                currentDate.day = 1;
                currentDate.month++;
            }
        }
    }
    else {
        if (currentDate.day > 30) {
            currentDate.day = 1;
            currentDate.month++;
        }
    }

    if (currentDate.month > 12) {
        currentDate.month = 1;
        currentDate.year++;
    }

    availableDates[0] = currentDate;

    for (int i = 1; i <= 6; i++) {
        currentDate.hour = 0;
        currentDate.day++;

        if (currentDate.month == 1 || currentDate.month == 3 || currentDate.month == 5 || currentDate.month == 7
            || currentDate.month == 8 || currentDate.month == 10 || currentDate.month == 12) {
            if (currentDate.day > 31) {
                currentDate.day = 1;
                currentDate.month++;
            }
        }
        else if (currentDate.month == 2) {
            if (leapYear(currentDate.year)) {
                if (currentDate.day > 29) {
                    currentDate.day = 1;
                    currentDate.month++;
                }
            }
            else {
                if (currentDate.day > 28) {
                    currentDate.day = 1;
                    currentDate.month++;
                }
            }
        }
        else {
            if (currentDate.day > 30) {
                currentDate.day = 1;
                currentDate.month++;
            }
        }

        if (currentDate.month > 12) {
            currentDate.month = 1;
            currentDate.year++;
        }

        availableDates[i] = currentDate;
    }

}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    if (reservations.size() == 0) {
        cout << "No reservations!" << endl;
        return;
    }

    ReservationRecord newReservation[20] = {};
    int newReservationSize = 0;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(reservations[i].idNumber, idNumber) == 0) {
            newReservation[newReservationSize] = reservations[i];
            newReservationSize++;
        }
    }

    cout << setw(29) << "Branch" << setw(14) << "Date" << setw(8) << "Hour" << setw(19) << "No of Customers" << endl;
    for (int i = 0; i < newReservationSize; i++) {
        cout << i + 1 << ". ";
        output(newReservation[i]);
    }

    int reservationchoice;
    do {
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
    } while ((reservationchoice = inputAnInteger(1, newReservationSize)) == -1);
    if (reservationchoice == 0) return;

    ReservationRecord deleteRecord = {};
    deleteRecord = newReservation[reservationchoice - 1];
    for (int i = 0; i < reservations.size(); i++) {
        if (reservations[i].branchCode == deleteRecord.branchCode && reservations[i].numCustomers == deleteRecord.numCustomers &&
            reservations[i].date.year == deleteRecord.date.year && reservations[i].date.month == deleteRecord.date.month &&
            reservations[i].date.day == deleteRecord.date.day && reservations[i].date.hour == deleteRecord.date.hour) {
            for (int j = i; j < reservations.size() - 1; j++) {
                reservations[j] = reservations[j + 1];
            }
            reservations.pop_back();
            return;
        }
    }

}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    MemberRecord in = {};
    for (int i = 0; i < memberDetails.size(); i++) {
        in = memberDetails[i];
        if (strcmp(in.idNumber, idNumber) == 0) {
            return true;
        }
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream saveMemberFile("Members.dat", ios::out | ios::binary );
    for (int i = 0; i < memberDetails.size(); i++) {
        saveMemberFile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream saveReservationsFile("Reservations.dat", ios::out | ios::binary );
    Date currentDate = compCurrentDate();
    for (int i = 0; i < reservations.size(); i++) {
        if (!lessEqual(reservations[i].date, currentDate)) {
            saveReservationsFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
        }
    }
}