#include <iostream>
using std::cin;
using std::cout;
using std::endl;
using namespace std;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);
    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inOutfile("Members.dat", ios::in | ios::binary);
    if (!inOutfile)
    {
        cout << "File could not opened!" << endl;
        system("pause");
        exit(1);
    }
    inOutfile.clear();
    inOutfile.seekg(0, ios::beg);
    while (inOutfile.read(reinterpret_cast<char*>(&memberDetails), sizeof(memberDetails)))
    {
    }
    inOutfile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inOutfile("Reservations.dat", ios::in | ios::binary);
    if (!inOutfile)
    {
        cout << "File could not opened!" << endl;
        system("pause");
        exit(1);
    }
    inOutfile.clear();
    inOutfile.seekg(0, ios::beg);
    while (inOutfile.read(reinterpret_cast<char*>(&reservations), sizeof(reservations)))
    {
    }
    inOutfile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year <= date2.year)
    {
        if (date1.month <= date2.month)
        {
            if (date1.day <= date2.day)
                return true;
            else
                return false;
        }
        else
            return false;
    }
    else
        return false;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    saveMemberDetails(memberDetails);
    MemberRecord newMember;
    ifstream inOutfile("Members.dat", ios::in | ios::binary);
    if (!inOutfile)
    {
        cout << "File could not opened!" << endl;
        system("pause");
        exit(1);
    }
    inOutfile.clear();
    inOutfile.seekg(0, ios::beg);
    while (inOutfile.read(reinterpret_cast<char*>(&newMember), sizeof(newMember)))
    {
        if (strcmp(idNumber, newMember.idNumber) == 0 && strcmp(password, newMember.password) == 0)
        {
            return true;
        }
    }
    inOutfile.close();
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    for (int i = 1; i <= 18; i++)
    {
        cout << i << ". " << branchNames[i] << endl;
    }

    do
    {
        cout << "\nEnter your choice (0 to end): ";
        cin >> newReservation.branchCode;
        cout << endl;
        if (newReservation.branchCode == 0)
            return;
    } while (newReservation.branchCode < 1 || newReservation.branchCode > 18);
    
    newReservation.date = compCurrentDate();
    cout << "\nThe current hour is " 
        << newReservation.date.year << "/" 
        << newReservation.date.month << "/" 
        << newReservation.date.day << ":" 
        << newReservation.date.hour << endl;

    cout << "\nAvailable days:" << endl;

    Date availableDates[7];
    compAvailableDates(availableDates);
    for (int i = 1; i <= 7; i++)
    {
        cout << "\nThe current hour is "
            << availableDates[i].year << "/"
            << availableDates[i].month << "/"
            << availableDates[i].day << endl;
    }

    int choice;
    do
    {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice;
        cout << endl;
        if (choice == 0)
            return;
    } while (choice < 1 || choice > 7);

    int starthour, endhour;

    if (availableDates[choice].month == newReservation.date.month && availableDates[choice].day == newReservation.date.day)
    {
        starthour = newReservation.date.hour;
        endhour = 23;
    }
    else
    {
        starthour = 0;
        endhour = 23;
    }

    do
    {
        cout << "\nEnter hour (" << starthour << "~" << endhour << "): ";
        cin >> newReservation.date.hour;
        cout << endl;
    } while (newReservation.date.hour < starthour || newReservation.date.hour > endhour);

    do
    {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> newReservation.numCustomers;
        cout << endl;
        if (newReservation.numCustomers == 0)
            return;
    } while (newReservation.numCustomers < 1 || newReservation.numCustomers > 30);

    for (int i = 0; i < 12; i++)
        newReservation.idNumber[i] = idNumber[i];

    newReservation.date.day = availableDates[choice].day;
    newReservation.date.month = availableDates[choice].month;
    newReservation.date.year = availableDates[choice].year;

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    int leapyear;
    if (currentDate.year % 400 == 0)
        leapyear = 1;
    else if (currentDate.year % 100 == 0 && currentDate.year % 400 != 0)
        leapyear = 0;
    else if (currentDate.year % 4 == 0 && currentDate.year % 100 != 0)
        leapyear = 1;
    else
        leapyear = 0;
    for (int i = 1; i <= 7; i++)
    {
        availableDates[i].year = currentDate.year;
        availableDates[i].month = currentDate.month;
        availableDates[i].day = currentDate.day;
        if (leapyear == 1)
        {
            if (currentDate.month == 4 || currentDate.month == 6 || currentDate.month == 9 || currentDate.month == 11)
            {
                if (currentDate.day + i - 1 > 30)
                {
                    availableDates[i].day = availableDates[i].day + i - 1 - 30;
                    availableDates[i].month = availableDates[i].month + 1;
                }
                else
                {
                    availableDates[i].day = availableDates[i].day + i - 1;
                }
            }
            else if (currentDate.month == 2)
            {
                if (currentDate.day + i - 1 > 29)
                {
                    availableDates[i].day = availableDates[i].day + i - 1 - 29;
                    availableDates[i].month = availableDates[i].month + 1;
                }
                else
                {
                    availableDates[i].day = availableDates[i].day + i - 1;
                }
            }
            else
            {
                if (currentDate.day + i - 1 > 31)
                {
                    availableDates[i].day = availableDates[i].day + i - 1 - 31;
                    if (currentDate.month + 1 > 12)
                    {
                        availableDates[i].month -= 12;
                        availableDates[i].year++;
                    }
                }
                else
                {
                    availableDates[i].day = availableDates[i].day + i - 1;
                }
            }
        }
        else
        {
            if (currentDate.month == 4 || currentDate.month == 6 || currentDate.month == 9 || currentDate.month == 11)
            {
                if (currentDate.day + i - 1 > 30)
                {
                    availableDates[i].day = availableDates[i].day + i - 1 - 30;
                    availableDates[i].month = availableDates[i].month + 1;
                }
                else
                {
                    availableDates[i].day = availableDates[i].day + i - 1;
                }
            }
            else if (currentDate.month == 2)
            {
                if (currentDate.day + i - 1 > 28)
                {
                    availableDates[i].day = availableDates[i].day + i - 1 - 28;
                    availableDates[i].month = availableDates[i].month + 1;
                }
                else
                {
                    availableDates[i].day = availableDates[i].day + i - 1;
                }
            }
            else
            {
                if (currentDate.day + i - 1 > 31)
                {
                    availableDates[i].day = availableDates[i].day + i - 1 - 31;
                    if (currentDate.month + 1 > 12)
                    {
                        availableDates[i].month -= 12;
                        availableDates[i].year++;
                    }
                }
                else
                {
                    availableDates[i].day = availableDates[i].day + i - 1;
                }
            }
        }
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    ReservationRecord newReservation[100];
    fstream inOutfile("Reservations.dat", ios::in | ios::out | ios::binary);
    if (!inOutfile)
    {
        cout << "File could not opened!" << endl;
        system("pause");
        exit(1);
    }
    inOutfile.clear();
    inOutfile.seekg(0, ios::beg);
    int i = 1;
    while (inOutfile.read(reinterpret_cast<char*>(&newReservation[i]), sizeof(newReservation[i])))
    {
        if (!lessEqual(currentDate, newReservation[i].date))
            continue;
        if (strcmp (idNumber, newReservation[i].idNumber) == 0)
        {
            cout << endl << setw(26) << "Branch"
                << setw(14) << "Date" << setw(8) << "Hour"
                << setw(19) << "No of Customers" << endl;
            output(newReservation[i]);
            i++;
        }
    }
    i--;
    int j;
    do
    {
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
        cin >> j;
        cout << endl;
        if (j == 0)
            return;
    } while (j < 1 || j > i);
    inOutfile.seekg(-static_cast<int>(sizeof(newReservation)), ios::cur);
    for (int k = j; k < i; k++)
    {
        newReservation[i] = newReservation[i + 1];
        inOutfile.write(reinterpret_cast<char*>(&newReservation[i]), sizeof(newReservation[i]));
    }
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;
    ifstream inOutfile("Members.dat", ios::in | ios::binary);
    if (!inOutfile)
    {
        cout << "File could not opened!" << endl;
        system("pause");
        exit(1);
    }
    inOutfile.clear();
    inOutfile.seekg(0, ios::beg);
    while (inOutfile.read(reinterpret_cast<char*>(&newMember), sizeof(newMember)))
    {
        if (strcmp(idNumber, newMember.idNumber) == 0)
        {
            return true;
        }
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream inOutfile("Members.dat", ios::out | ios::binary);
    if (!inOutfile)
    {
        cout << "File could not opened!" << endl;
        system("pause");
        exit(1);
    }
    inOutfile.clear();
    inOutfile.seekp(0, ios::beg);
    while (inOutfile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(memberDetails)))
    {
    }
    inOutfile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream inOutfile("Reservations.dat", ios::out | ios::binary);
    if (!inOutfile)
    {
        cout << "File could not opened!" << endl;
        system("pause");
        exit(1);
    }
    inOutfile.clear();
    inOutfile.seekp(0, ios::beg);
    while (inOutfile.write(reinterpret_cast<const char*>(&reservations), sizeof(reservations)))
    {
    }
    inOutfile.close();
}