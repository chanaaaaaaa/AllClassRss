#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream InFile;
    InFile.open( "Members.dat" , ios::in | ios::binary);

    if (!InFile) {
        return;
    }

    MemberRecord MR;
    while (InFile.read(reinterpret_cast<char*>(&MR), sizeof(MemberRecord))) {
        memberDetails.push_back(MR);
    }
    InFile.close();
    return;
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream InFile( "Reservations.dat" , ios::in | ios::binary);
    if (!InFile) {
        return;
    }

    ReservationRecord RR;
    Date current = compCurrentDate();

    while (InFile.read(reinterpret_cast<char*>(&RR), sizeof(ReservationRecord))) {
        if (lessEqual(RR.date, current)) {
            reservations.push_back(RR);
        }
    }
    InFile.close();
    return;
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
   /*
   Date testDate;
   testDate.year = 2026;
   testDate.month = 1;
   testDate.day = 1;
   testDate.hour = 18;
   return testDate;
   */
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year > date2.year) {
        return true;
    }else if (date1.year < date2.year) {
        return false;
    }
    else {
        if (date1.month > date2.month) {
            return true;
        }
        else if (date1.month < date2.month) {
            return false;
        }
        else {
            return date1.day >= date2.day;
        }
    }
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); ++i) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 &&
            strcmp(password,memberDetails[i].password) == 0) 
        {
            return true;
        }
    }

    cout << "\nInvalid account number or password. Please try again.\n\n";
    return false;
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
    ReservationRecord newReservation;

   //list all of branch name
   for (int i = 1; i <=18 ; ++i) {
       cout << i <<". "<< branchNames[i] << '\n';
   }
   
   //user choose the branch
   int user_choice_branch = 0;
   do {
       cout << "\nEnter your choice (0 to end): ";
       user_choice_branch = inputAnInteger(0, 18);
       if (user_choice_branch == 0) { return; }
   } while (user_choice_branch  == -1);
   
   //user choose Available days
   Date current = compCurrentDate();
   Date AD[8];//Available Dates
   int pin = 1,
       year = current.year,
       month = current.month,
       day = current.day,
       hour = current.hour+1,
       DaysOfMonth[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
   if (hour == 24) {
       ++day;
       hour = 0;
   }
   while (pin <= 7) {
       //leap?
       if (year % 400 == 0) {
           DaysOfMonth[2] = 29;
       }
       else if (year % 100 != 0 && year % 4 == 0) {
           DaysOfMonth[2] = 29;
       }
       else {
           DaysOfMonth[2] = 28;
       }
       //judge
       if (day > DaysOfMonth[month]) {
           day -= DaysOfMonth[month];
           ++month;
       }
       if (month > 12) {
           month -= 12;
           ++year;
       }
       AD[pin].year = year;
       AD[pin].month = month;
       AD[pin].day = day;
       AD[pin].hour = hour;
       ++day; ++pin;
   }
   compAvailableDates(AD);

   //user choose the date
   int user_choice_date = 0;
   do {
       cout << "\nEnter your choice (0 to end): ";
       user_choice_date = inputAnInteger(0, 7);
       if (user_choice_date == 0) { return; }
   } while (user_choice_date == -1);

   //user choose the hour
   int user_choice_hour = 0;
   if (user_choice_date == 1) {
       do {
           cout << "\nEnter hour (" << hour << '~' << "23): ";
           user_choice_hour = inputAnInteger(hour, 23);
       } while (user_choice_hour == -1);
   }
   else {
       do {
           cout << "\nEnter hour (" << 0 << '~' << "23): ";
           user_choice_hour = inputAnInteger(0, 23);
       } while (user_choice_hour == -1);
   }
   
   //user choose the hour
   int user_choice_member = 0;
   do {
       cout << "\nEnter the number of customers (1~30, 0 to end): ";
       user_choice_member = inputAnInteger(0, 30);
       if (user_choice_member == 0) { return; }
   } while (user_choice_member == -1);

   newReservation.branchCode = user_choice_branch;

   AD[user_choice_date].hour = user_choice_hour;
   newReservation.date = AD[user_choice_date];
   strcpy_s(newReservation.idNumber, idNumber);
   newReservation.numCustomers = user_choice_member;


   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;
   output( newReservation );

   cout << "\nReservation Completed!\n";
   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();
   cout << "\nThe current hour is "
       << currentDate.year << '/'
       << currentDate.month << '/'
       << currentDate.day << ':'
       << currentDate.hour << '\n';

   cout << "\nAvailable days :\n\n";
   for (int i = 1; i <= 7; ++i) {
       cout << i << ". " 
            << availableDates[i].year << '/'
            << availableDates[i].month << '/'
            << availableDates[i].day << '\n';
   }
   return;
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();

   int count = 0;
   for (int i = 0; i < reservations.size(); ++i) {
       if (strcmp(reservations[i].idNumber, idNumber) == 0) {
           if (count == 0) {
               cout << endl << setw(26) << "Branch"
                   << setw(14) << "Date" << setw(8) << "Hour"
                   << setw(19) << "No of Customers" << endl;
           }
           cout << ++count << '.';
           
           int MakeUpSpace = 1;
           int tmp = count;
           while (tmp) {
               ++MakeUpSpace;
               tmp /= 10;
           }

           cout << setw(26-MakeUpSpace) << branchNames[reservations[i].branchCode]
               << setw(8) << reservations[i].date.year << '-'
               << setw(2) << setfill('0') << reservations[i].date.month << '-'
               << setw(2) << setfill('0') << reservations[i].date.day
               << setw(8) << setfill(' ') << reservations[i].date.hour
               << setw(19) << reservations[i].numCustomers << '\n';

       }
   }

   if (count == 0) {
       cout << "No reservations!\n";
       return;
   }

   int choice = 0;
   do {
       cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
       choice = inputAnInteger(0, (int)reservations.size());
   } while (choice == -1);
   
   if (choice != 0) {
       int count = 0;
       for (int i = 0; i < reservations.size(); ++i) {
           if (strcmp(idNumber, reservations[i].idNumber) == 0) {
               ++count;
               if (count == choice) {
                   reservations.erase(reservations.begin() + i);
                   break;
               }
           }
       }
   }
   return;
}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); ++i) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {
            return true;
        }
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream OutFile("Members.dat", ios::out | ios::binary);

    if (!OutFile) {
        cout << "Can't Open Members.dat\n";
        return;
    }

    for (int i = 0; i < memberDetails.size(); ++i) {
        OutFile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    OutFile.close();
    return;
}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream OutFile("Reservations.dat", ios::out | ios::binary);

    if (!OutFile) {
        cout << "Can't Open Reservations.dat\n";
        return;
    }

    for (int i = 0; i < reservations.size(); ++i) {
        OutFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }
    OutFile.close();
    return;
}