﻿#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setfill;
using std::setw;

#include <fstream>
using std::ifstream;
using std::ios;
using std::ofstream;

#include <vector>
using std::vector;

struct Date {
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord {
    char idNumber[12];  // account number
    char password[24];  // password
    char name[8];       // name
};

struct ReservationRecord {
    char idNumber[12];  // account number
    int branchCode;     // branch code
    Date date;          // reservation date
    int numCustomers;   // number of customers
};

char branchNames[19][24] = {"", "Taipei Dunhua South", "Taipei Zhongxiao", "Taipei Songjiang", "Taipei Nanjing", "Taipei Linsen", "Taipei Zhonghua New", "Banqiao Guanqian", "Yonghe Lehua", "Taoyuan Zhonghua", "Taoyuan Nankan", "Zhongli Zhongyang", "Hsinchu Beida", "Taichung Ziyou", "Chiayi Ren'ai", "Tainan Ximen", "Kaohsiung Zhonghua New", "Kaohsiung Jianxing", "Pingtung Kending"};

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector<MemberRecord>& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector<ReservationRecord>& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector<MemberRecord>& memberDetails, vector<ReservationRecord>& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[], const vector<MemberRecord>& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector<ReservationRecord>& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector<ReservationRecord>& reservations);

// add a new member
void registration(vector<MemberRecord>& memberDetails);

// return true if idNumber is a legal ID number
// bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector<MemberRecord>& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector<MemberRecord>& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector<ReservationRecord>& reservations);

int monthDay(int year, int month);
void addDate(Date& date, int day);
char* outputDate(Date date, int format);

void strcpy(char* a, char* b) {
    if (b == NULL) {
        a[0] = '\0';
        return;
    }
    for (int i = 0;;++i) {
        a[i] = b[i];
        if (b[i] == '\0') return;
    }
}

int main() {
    vector<MemberRecord> memberDetails;      // member details for all members
    vector<ReservationRecord> reservations;  // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true) {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do
            cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice) {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector<MemberRecord>& memberDetails) {
    ifstream file("Members.dat", ios::binary);
    if (!file) {
        cout << "open file 'Members.dat' error\n";
        system("pause");
        exit(1);
    }
    MemberRecord temp;
    while (file.read((char*)&temp, sizeof(MemberRecord)))
        memberDetails.push_back(temp);
}

void loadReservations(vector<ReservationRecord>& reservations) {
    ifstream file("Reservations.dat", ios::binary);
    if (!file) {
        cout << "open file 'Reservations.dat' error\n";
        system("pause");
        exit(1);
    }
    ReservationRecord temp;
    while (file.read((char*)&temp, sizeof(ReservationRecord))) {
        Date currentDate = compCurrentDate();
        Date tempDate = temp.date;
        if (lessEqual(currentDate, tempDate))
            reservations.push_back(temp);
    }
}

Date compCurrentDate() {
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    // return currentDate;
    return Date({2100, 2, 27, 22});
}

bool lessEqual(const Date& date1, const Date& date2) {
    if (date1.year != date2.year)
        return date1.year < date2.year;
    if (date1.month != date2.month)
        return date1.month < date2.month;
    return date1.day <= date2.day;
}

int inputAnInteger(int begin, int end) {
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        return inputAnInteger(begin, end);
        // exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector<MemberRecord>& memberDetails, vector<ReservationRecord>& reservations) {
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true) {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do
            cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice) {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector<MemberRecord>& memberDetails) {
    for (const MemberRecord& t : memberDetails)
        if (strcmp(idNumber, t.idNumber) == 0 && strcmp(password, t.password) == 0)
            return true;
    cout << "\nInvalid account number or password. Please try again.\n\n";
    return false;
}

void reservation(char idNumber[], vector<ReservationRecord>& reservations) {
    ReservationRecord newReservation;

    strcpy(newReservation.idNumber, idNumber);

    for (int i = 1; i <= 18; ++i)
        cout << i << ". " << branchNames[i] << endl;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> newReservation.branchCode;
    } while (newReservation.branchCode < 0 || newReservation.branchCode > 18);
    if (newReservation.branchCode == 0) return;

    Date currentDate = compCurrentDate();
    cout << "\nThe current hour is " << outputDate(currentDate, 1) << endl;
    cout << "\nAvailable days:\n";
    Date availableDates[7];
    compAvailableDates(availableDates);

    for (int i = 0; i < 7; ++i)
        cout << i + 1 << ". " << outputDate(availableDates[i], 2) << endl;
    int choiceDay;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choiceDay;
    } while (choiceDay < 0 || choiceDay > 7);
    if (choiceDay == 0) return;
    newReservation.date = availableDates[choiceDay - 1];

    int minHour = newReservation.date.hour + 1;
    do {
        cout << "\nEnter hour (" << minHour << "~23): ";
        cin >> newReservation.date.hour;
    } while (newReservation.date.hour < minHour || newReservation.date.hour > 23);

    do {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> newReservation.numCustomers;
    } while (newReservation.numCustomers < 0 || newReservation.numCustomers > 30);
    if (newReservation.numCustomers == 0) return;

    cout << endl
         << setw(26) << "Branch"
         << setw(14) << "Date" << setw(8) << "Hour"
         << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

int monthDay(int year, int month) {
    if (month == 2)
        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
            return 29;
        else
            return 28;
    else if (month == 4 || month == 6 || month == 9 || month == 11)
        return 30;
    else
        return 31;
}

void addDate(Date& date, int day) {
    for (int i = 0; i < day; ++i) {
        ++date.day;
        if (date.day > monthDay(date.year, date.month)) {
            ++date.month;
            date.day = 1;
        }
        if (date.month > 12) {
            ++date.year;
            date.month = 1;
        }
    }
    date.hour = -1;
}

char* outputDate(Date date, int format) {
    char* str = new char[14]();
    if (format == 1) {  // "yyyy/mm/dd:hh"
        char t[14] = {'0' + date.year / 1000, '0' + date.year % 1000 / 100, '0' + date.year % 100 / 10, '0' + date.year % 10, '/', '0' + date.month / 10, '0' + date.month % 10, '/', '0' + date.day / 10, '0' + date.day % 10, ':', '0' + date.hour / 10, '0' + date.hour % 10, '\0'};
        strcpy(str, t);
    } else if (format == 2) {  // "yyyy/mm/dd"
        char t[11] = {'0' + date.year / 1000, '0' + date.year % 1000 / 100, '0' + date.year % 100 / 10, '0' + date.year % 10, '/', '0' + date.month / 10, '0' + date.month % 10, '/', '0' + date.day / 10, '0' + date.day % 10, '\0'};
        strcpy(str, t);
    }
    return str;
}

void compAvailableDates(Date availableDates[]) {
    Date currentDate = compCurrentDate();
    if (currentDate.hour == 23)
        addDate(currentDate, 1);
    for (int i = 0; i < 7; ++i) {
        availableDates[i] = currentDate;
        addDate(currentDate, 1);
    }
}

void output(ReservationRecord reservation) {
    cout << setw(26) << branchNames[reservation.branchCode]
         << setw(8) << reservation.date.year << '-'
         << setw(2) << setfill('0') << reservation.date.month << '-'
         << setw(2) << setfill('0') << reservation.date.day
         << setw(8) << setfill(' ') << reservation.date.hour
         << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector<ReservationRecord>& reservations) {
    Date currentDate = compCurrentDate();
    int index = 0;
    for (ReservationRecord& t : reservations)
        if (strcmp(t.idNumber, idNumber) == 0 && lessEqual(currentDate, t.date))
            ++index;
    if (index == 0) {
        cout << "\nNo reservations!\n";
        return;
    }
    index = 0;
    cout << setw(28) << "Branch" << setw(14) << "Date" << setw(8) << "Hour" << setw(19) << "No of Customers" << endl;
    for (ReservationRecord& t : reservations)
        if (strcmp(t.idNumber, idNumber) == 0 && lessEqual(currentDate, t.date)) {
            cout << ++index << ".";
            output(t);
        }
    int choice;
    do {
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
        cin >> choice;
    } while (choice < 0 || choice > index);
    if (choice == 0)
        return;
    vector<ReservationRecord> newReservations;
    for (const ReservationRecord& t : reservations) {
        if (strcmp(t.idNumber, idNumber) == 0 && lessEqual(currentDate, t.date)) {
            if (--choice == 0) continue;
        }
        newReservations.push_back(t);
    }
    reservations = newReservations;
}

void registration(vector<MemberRecord>& memberDetails) {
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails)) {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector<MemberRecord>& memberDetails) {
    for (const MemberRecord& t : memberDetails)
        if (strcmp(t.idNumber, idNumber) == 0)
            return true;
    return false;
}

void saveMemberDetails(const vector<MemberRecord>& memberDetails) {
    ofstream file("Members.dat", ios::binary);
    if (!file) {
        cout << "open file 'Members.dat' error\n";
        system("pause");
        exit(1);
    }
    for (const MemberRecord& t : memberDetails)
        file.write((char*)&t, sizeof(MemberRecord));
}

void saveReservations(const vector<ReservationRecord>& reservations) {
    ofstream file("Reservations.dat", ios::binary);
    if (!file) {
        cout << "open file 'Reservations.dat' error\n";
        system("pause");
        exit(1);
    }
    for (const ReservationRecord& t : reservations)
        file.write((char*)&t, sizeof(ReservationRecord));
}
