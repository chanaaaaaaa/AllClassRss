#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;
using namespace std;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream infile("Members.dat", ios::in | ios::binary);
    if (!infile)
        cout << "can't open";

    infile.clear();
    infile.seekg(0);
    MemberRecord temp[100];
    int count = 0;
    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord)))
        count++;

    for (int i = 0; i < count; ++i)
        memberDetails.push_back(temp[count]);
    
    infile.close();


}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream infile("Reservations.dat", ios::in | ios::binary);
    if (!infile)
        cout << "can't open";

    infile.clear();
    infile.seekg(0);
    int count = 0;
    ReservationRecord temp[100];
    Date currentDate = compCurrentDate();
    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord)))
        count++;

        for (int i = 0; i < count; ++i)
            if (!lessEqual(temp[i].date, currentDate))
                reservations.push_back(temp[i]);
    
    infile.close();

}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date2.year > date1.year) return true;
    if (date2.month > date1.month) return true;
    if (date2.day > date1.day) return true;

    return false;

}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < sizeof(memberDetails); ++i)
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
            if (strcmp(password, memberDetails[i].password) == 0)
                return true;

    cout << "Invalid account number or password. Please try again." << endl;
    return false;

}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)//�w���\��
{
    ReservationRecord newReservation = {};

    for (int i = 1; i < 19; ++i)
        cout << setw(2) << i << branchNames[i] << endl;

    do
    {
        cout << "Enter your choice (0 to end):";
        cin >> newReservation.branchCode;
        if (newReservation.branchCode == 0)
            return;
    } while (newReservation.branchCode < 0 || newReservation.branchCode > 19);


    Date currentDate = compCurrentDate();
    cout << "The current hour is " << ("%4d/%d/%d:%d", currentDate.year, currentDate.month, currentDate.day, currentDate.hour) << endl;
    cout << "Available days:" << endl;

    Date availableDates[8];
    compAvailableDates(availableDates);
    for (int i = 1; i <= 7; ++i)
        cout << ("%4d/%d/%d", availableDates[i].year, availableDates[i].month, availableDates[i].day) << endl;

    int choice;
    do
    {
        cout << "Enter your choice (0 to end):";
        cin >> choice;
        if (choice == 0)
            return;
    } while (choice < 0 || choice > 8);

    newReservation.date.day = availableDates[choice].day;
    newReservation.date.month = availableDates[choice].month;
    newReservation.date.year = availableDates[choice].year;

    int first = 0;
    int last = 23;
    if (choice == 1 && newReservation.date.day == currentDate.day)
        first = currentDate.hour;

    do
    {
        cout << "Enter hour (" << first << "~" << last << "):";
        cin >> newReservation.date.hour;
    } while (newReservation.date.hour < first || newReservation.date.hour > last);

    do
    {
        cout << "Enter the number of customers (1~30, 0 to end):";
        cin >> newReservation.numCustomers;
        if (newReservation.numCustomers == 0)
            return;
    } while (newReservation.numCustomers < 0 || newReservation.numCustomers > 30);

    cout << endl << setw(26) << "Branch"
        << (14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    int month[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
    if (currentDate.year % 400 == 0 || (currentDate.year % 4 == 0 && currentDate.year % 100 != 0))
        month[2] = 29;

    if (currentDate.hour != 23)
    {
        availableDates[1].year = currentDate.year;
        availableDates[1].month = currentDate.month;
        availableDates[1].day = currentDate.day;
    }
    else
    {
        availableDates[1].day = currentDate.day + 1;
        if (availableDates[1].day > month[availableDates[1].month])
        {
            availableDates[1].month = currentDate.month + 1;
            availableDates[1].day -= month[availableDates[1].month];
        }
        else
            availableDates[1].month = currentDate.month;
        if (availableDates[1].month > 12)
        {
            availableDates[1].month -= 12;
            availableDates[1].year++;
        }
        else
            availableDates[1].year = currentDate.year;
    }

    for (int i = 2; i < 7; ++i)
    {
        availableDates[i].day = currentDate.day + i;
        if (availableDates[i].day > month[availableDates[i].month])
        {
            availableDates[i].month = currentDate.month + 1;
            availableDates[i].day -= month[currentDate.month-1];
        }
        else
            availableDates[i].month = currentDate.month;
        if (availableDates[i].month > 12)
        {
            availableDates[i].month -= 12;
            availableDates[i].year++;
        }
        else
            availableDates[i].year = currentDate.year;
    }


}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)//�d�w��&�R�w��
{
    Date currentDate = compCurrentDate();
    cout << setw(26) << "branchNames" << setw(8) << " Date" << setw(8) << "Hour" << setw(19) << "No of Customers" << endl;
    int count = 0;
    int index[100] = {};
    for (int i = 0; i < sizeof(reservations); ++i)
    {
        if (strcmp(idNumber, reservations[i].idNumber) == 0)
        {
            index[count++] = i;
            cout << count << ".";
            output(reservations[i]);
        }
    }

    int choice;
    do
    {
        cout << "Choose a reservation to cancel (0: keep all reservations):";
        cin >> choice;
        if (choice == 0)
            return;
    } while (choice > count || choice < 0);

    reservations[index[choice]] = { '\0' };

}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < sizeof(memberDetails); ++i)
        if (strcmp(memberDetails[i].idNumber,idNumber) == 0)
            return true;
    return false;

}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    fstream outfile("Members.dat", ios::out | ios::binary);

    for (int i = 0; i < sizeof(memberDetails); ++i)
        outfile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));

    outfile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    fstream outfile("Reservations.dat", ios::out | ios::binary);

    for (int i = 0; i < sizeof(reservations); ++i)
        if (reservations[i].idNumber[0] != '\0')
            outfile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));

    outfile.close();

}