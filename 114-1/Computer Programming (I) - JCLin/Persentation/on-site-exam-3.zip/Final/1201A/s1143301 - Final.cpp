#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

#include <cstring>

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break; 

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream infile("Members.dat", ios::in | ios::binary);
    if (!infile)
    {
        cout << "Members.dat open failed" << endl;
        system("pause");
    }
    MemberRecord data;
    while (infile.read(reinterpret_cast<char*>(&data), sizeof(MemberRecord)))
    {
        memberDetails.push_back(data);
    }
    infile.close();
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    Date currentDate = compCurrentDate();
    ifstream infile("Reservations.dat", ios::in | ios::binary);
    if (!infile)
    {
        cout << "Reservations.dat open failed" << endl;
        system("pause");
    }
    ReservationRecord data;
    while (infile.read(reinterpret_cast<char*>(&data), sizeof(ReservationRecord)))
    {
        if (lessEqual(currentDate,data.date))
        {
            reservations.push_back(data);
        }
    }
    infile.close();
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   /*//debug
   currentDate.year = 2026;
   currentDate.month = 1;
   currentDate.day = 1;
   currentDate.hour = 18;
   */
 
   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    if (date1.year > date2.year)
    {
        return false;
    }
    else if (date1.year == date2.year)
    {
        if (date1.month > date2.month)
        {
            return false;
        }
        else if (date1.month == date2.month)
        {
            if (date1.day > date2.day)
            {
                return false;
            }
        }
    }
    return true;
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   //cin.getline( string, 80, '\n' );
   cin >> string;
   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {   
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (!strcmp(idNumber, memberDetails[i].idNumber) and !strcmp(password, memberDetails[i].password))
        {
            return true;
        }
    }
    cout << "\nInvalid account number or password. Please try again." << endl << endl;
    return false;
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;
   strcpy_s(newReservation.idNumber, 12, idNumber);
   for (int i = 1; i <= 18; i++)
   {
       cout <<setw(2) << i;
       cout << "." << branchNames[i] << endl;
   }

   int input = -1;
   while (!(input >= 0 and input <= 18))
   {
       cout << "\nEnter your choice (0 to end):";
       cin >> input;
   }
   if (input == 0)
   {
       return;
   }
   else
   {
       newReservation.branchCode = input;
   }

   Date currentDate = compCurrentDate();
   cout << "\nThe current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;

   Date availableDates[8];
   compAvailableDates(availableDates);

   input = -1;
   while (!(input >= 0 and input <= 7))
   {
       cout << "\nEnter your choice (0 to end):";
       cin >> input;
   }
   if (input == 0)
   {
       return;
   }
   else
   {
       newReservation.date.year = availableDates[input].year;
       newReservation.date.month = availableDates[input].month;
       newReservation.date.day = availableDates[input].day;
   }

   input = -1;
   int fhour;
   if (currentDate.year == newReservation.date.year and currentDate.month == newReservation.date.month and currentDate.day == newReservation.date.day)
   {
       fhour = currentDate.hour + 1;
   }
   else
   {
       fhour = 0;
   }
   while (!(input >= fhour and input <= 23))
   {
       cout << "\nEnter hour (" << fhour << "~23):";
       cin >> input;
   }
   newReservation.date.hour = input;

   input = -1;
   while (!(input >= 0 and input <= 30))
   {
       cout << "\nEnter the number of customers (1~30, 0 to end):";
       cin >> input;
   }
   if (input == 0)
   {
       return;
   }
   newReservation.numCustomers = input;

   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();
   int day[13] = {-1,31,28,31,30,31,30,31,31,30,31,30,31 };
   if (currentDate.hour == 23)
   {
       currentDate.day++;
   }
   cout << "\nAvailable days:" << endl << endl;
   for (int i = 1; i <= 7; i++)
   {
       if (currentDate.year % 400 == 0 or (currentDate.year % 100 != 0 and currentDate.year % 4 == 0))
       {
           day[2] = 29;
       }
       else
       {
           day[2] = 28;
       }
      
       if (currentDate.day > day[currentDate.month])
       {
           currentDate.day = 1;
           currentDate.month++;
       }
       if (currentDate.month > 12)
       {
           currentDate.month = 1;
           currentDate.year++;
       }
       availableDates[i].year = currentDate.year;
       availableDates[i].month = currentDate.month;
       availableDates[i].day = currentDate.day;
       cout << i << "." << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << endl;
       currentDate.day++;
   }
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();

   int count = 0;
   for (int i = 0; i < reservations.size(); i++)
   {
       if (!strcmp(reservations[i].idNumber, idNumber))
       {
           count++;
           if (count == 1)
           {
               cout << endl << setw(27) << "Branch"
                   << setw(14) << "Date" << setw(8) << "Hour"
                   << setw(19) << "No of Customers" << endl;
           }
           cout << count <<setw(26) << branchNames[reservations[i].branchCode]
               << setw(8) << reservations[i].date.year << '-'
               << setw(2) << setfill('0') << reservations[i].date.month << '-'
               << setw(2) << setfill('0') << reservations[i].date.day
               << setw(8) << setfill(' ') << reservations[i].date.hour
               << setw(19) << reservations[i].numCustomers << endl;
       }
   }
   if (count == 0)
   {
       cout << "No reservations!" << endl;
       return;
   }

   int input = -1;
   while (!(input >= 0 and input <= count))
   {
       cout << "\nChoose a reservation to cancel (0: keep all reservations):";
       cin >> input;
   }
   if (input == 0)
   {
       return;
   }
   else
   {
       for (int i = 0; i <reservations.size(); i++)
       {
           if (!strcmp(idNumber, reservations[i].idNumber))
           {
               if (input > 1)
               {
                   input--;
               }
               else if(input==1)
               {
                   strcpy_s(reservations[i].idNumber, 12, "-1");
                   break;
               }
           }
       }
   }

}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (!strcmp(idNumber, memberDetails[i].idNumber))
        {
            return true;
        }
    }
    return false;
}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream outfile("Members.dat", ios::out | ios::binary);
    if (!outfile)
    {
        cout << "Members.dat open failed" << endl;
        system("pause");
    }
    for (int i = 0; i < memberDetails.size(); i++)
    {
        outfile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    outfile.close();
}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream outfile("Reservations.dat", ios::out | ios::binary);
    if (!outfile)
    {
        cout << "Reservations.dat open failed" << endl;
        system("pause");
    }
    for (int i = 0; i < reservations.size(); i++)
    {
        if (!strcmp(reservations[i].idNumber, "-1"))
        {
            continue;
        }
        outfile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }
    outfile.close();
}