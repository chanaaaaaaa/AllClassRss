#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
bool legalID(char idNumber[]);

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}
//Ū��
void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    int numMembertails = 0;
    ifstream inFile("Members.dat", ios::binary);
    while (reinterpret_cast<char*>(&memberDetails), sizeof(MemberRecord)) {
        ++numMembertails;
    }
    inFile.close();
}
//Ū��
void loadReservations(vector< ReservationRecord >& reservations)
{
    int numreservations = 0;
    ifstream inFile("Reseravtions.dat", ios::binary);
    if (!inFile) {
        cout << "file could not be open" << endl;
        return;
    }
    while (reinterpret_cast<char*>(&reservations), sizeof(ReservationRecord)) {
        ++numreservations;
    }
    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0) - 3 * 24 * 60 * 60;
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}
// �^��true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{
    int totalhour1 = date1.hour + date1.day * 24 + date1.month * 720 + date1.year * 720 * 12;
    int totalhour2 = date2.hour + date2.day * 24 + date2.month * 720 + date2.year * 720 * 12;
    if (totalhour1 <= totalhour2) {
        return true;
    }
    else return false;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}
//�۵��Τ��۵�
bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < sizeof(memberDetails); i++) {
        if ((strcmp(memberDetails[i].idNumber, idNumber) != 0) or
            (strcmp(memberDetails[i].password, password) != 0)) {
            return true;
        }
        else {
            return false;
            break;
        }
    }
    //�S���@�ӲŦX �^��false
    return false;
}

//�g�J�s���w��
//��ܥi�w�����a�I
//�H�ƭ���
void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    Date currentDate = compCurrentDate();
    for (int i = 1; i <= 19; i++) {
        cout << i << " " << "." << " " << branchNames[i][24] << endl;
    }
    do {
        cout << "Enter your choice (0 to end):\n";
        cin >> reservations[0].branchCode;
        if (reservations[0].branchCode == 0) system("pause");
    } while (reservations[0].branchCode < 0 || reservations[0].branchCode >18);
    int userchoicedays = 0;
    //The current hour is 2025 / 12 / 31:18
    do {
        compAvailableDates(newReservation.date);
        cin >> userchoicedays;
        if (userchoicedays == 0)  system("pause");
    } while (userchoicedays < 0 or userchoicedays>7 or userchoicedays != 0);
    int userchoicehour = 0;
    do {
        cout << "Enter hour" << "(" << currentDate.hour + 1 << "~" << "23" << ")" << endl;
        cin >> userchoicehour;
        if (userchoicedays == 0)  system("pause");
    } while (userchoicedays < currentDate.hour + 1 or userchoicedays>24 or currentDate.hour != 0);
    int userchoicenumber = 0;

    do {
        cout << "Enter the number of customers (1~30, 0 to end): " << endl;
        cin >> userchoicenumber;
        if (userchoicenumber == 0)  system("pause");
    } while (userchoicenumber < 0 or userchoicenumber>31 or userchoicenumber != 0);


    ofstream outFile("Reservations.dat", ios::binary | ios::app);
    if (!outFile) {
        cout << "file could not be open" << endl;
        return;
    }
    int numreservations = 0;
    while (outFile.write(reinterpret_cast<char*>(&newReservation), sizeof(ReservationRecord))) {
        numreservations++;
    }
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}
//��X�C�Ѥ����Ѽ�(�B�z�|�~)
void compAvailableDates(Date availableDates[])
{
    //���J�{�b���ɶ�
    Date currentDate = compCurrentDate();
    int daysinmonth[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
    bool leapyear;
    //�P�_�|�~
    if ((currentDate.year) % 400 == 0)  leapyear = true;
    if ((currentDate.year) % 4 == 0 and ((currentDate.year) % 100 != 0)) leapyear = true;
    if ((currentDate.year) % 400 != 0 and ((currentDate.year) % 100 == 0)) leapyear = false;
    if (leapyear) daysinmonth[2] = 29;
    //The current hour is 2025 / 12 / 31:18
    cout << "The current hour is" << " " << currentDate.year << " " << "/" << " " << currentDate.month << " " << "/" << " " << currentDate.day << ":" << currentDate.hour << endl;
    //��X�i�諸�ɶ�(7�Ѥ�)    
    cout << "\nAvailable days :\n";
    for (int i = 1; i <= 7; i++) {
        if ((currentDate.day) + i > daysinmonth[currentDate.month]) {
            currentDate.day -= daysinmonth[currentDate.month];
            currentDate.month++;
            if (currentDate.month > 12) {
                currentDate.year++;
                currentDate.month -= 12;
                currentDate.day = 1;
                cout << i << " " << "." << " " << currentDate.year << " " << "/" << " " << currentDate.month << " " << "/" << " " << currentDate.day << ":" << currentDate.hour << endl;
            }
        }
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}
//display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
//pos=?��X�ϥΪ̿�w���ɮרçR��
//��ܩҦ��w�����ɮ�
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{

    Date currentDate = compCurrentDate();
    char userid[12];
    for (int i = 0; i < sizeof(reservations); i++) {
        output(reservations[i]);
    }
    int pos = 0;
    int userchoice = 0;
    int no = 0;
    do {
        cout << "\nChoose a reservation to cancel (0: keep all reservations) \n"
            cin >> userchoice;
        pos = userchoice;
        ofstream outFile("Reservations.dat", ios::binary);
        if (!outFile) {
            cout << "file could not be open!" << endl;
            return;
        }

        while (outFile.write(reinterpret_cast<char*>(&reservations), sizeof(ReservationRecord))) {
            if (no = userchoice;) continue;
            no++;
        }
        if (pos == 0) cout << "\nNo reservations!\n";
        outFile.close();
    } while (userchoice != 0 &&
        userchoice < sizeof(reservations) &&
        userchoice>0);
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}
//ID�w�s�b �^��true
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < sizeof(memberDetails); i++) {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0) {
            return  true;
            break;
        }
        else {
            return false;
        }
    }
    return false;
}
//�g��
void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{

    ofstream outFile("Members.dat", ios::binary);
    if (!outFile) {
        cout << "file could not be open!" << endl;
        return;
    }
    vector< MemberRecord >temp;
    int notemp = 0;
    while (outFile.write(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        notemp++;
    }
    outFile.close();
}
//�g��(�P�_���S���L��)
void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::binary);
    if (!outFile) {
        cout << "file could not be open!" << endl;
        return;
    }
    vector< ReservationRecord >temp;
    int notemp = 0;
    while (outFile.write(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        notemp++;
    }
    outFile.close();
}
//���n���ګ��U