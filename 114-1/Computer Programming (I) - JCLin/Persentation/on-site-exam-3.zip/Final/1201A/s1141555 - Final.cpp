#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat//
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)//�q�ɮ׿W��vector��
{
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile)
    {
        cout << "loadMemberDetails's Members.dat can not be opened" << endl;
        return;
    }
    MemberRecord record;
    while (inFile.read(reinterpret_cast<char*>(&record), sizeof(record)))
    {
        memberDetails.push_back(record);
    }

    inFile.close();


}

void loadReservations(vector< ReservationRecord >& reservations)//�L�X�S���W�ɪ��q��//�٬O�O�@�}�l�s�N�S�s�F?
{

    ifstream inFile("Reservations.dat", ios::binary);
    if (!inFile)
    {
        cout << "loadReservations's Reservations.dat can not be opened" << endl;
    }
    ReservationRecord record;
    // Date d;
    // d = compCurrentDate();
    while (inFile.read(reinterpret_cast<char*>(&record), sizeof(record)))
    {
        //if(record.date>d)//��W�ɫ���?���Date�p��񦳵L�W��?
        reservations.push_back(record);
    }


}

Date compCurrentDate()
{
    Date currentDate;//date avail[7]
    tm structuredTime;
    time_t rawTime = time(0);//-3*24*60*60?
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)//�֩�ثe�Ѽ�// return true if and only if date1 <= date2//return true�ثe���Ѽ�>�q���Ѽ�?
{
    Date current;
    current= compCurrentDate();
    
    return true;


}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)//�^��true�����o�ӷ|�����
{
    /*
     ifstream inFile("Members.dat", ios::binary);
     if (!inFile)
     {
         cout << "valid's Members.dat can not be opened" << endl;
     }
     MemberRecord record;
     while (inFile.read(reinterpret_cast<char *>(&record), sizeof(record)))
     {


     }
     */
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0 && strcmp(memberDetails[i].password, password) == 0)
        {
            return true;
            break;
        }



    }
    cout << endl;
    cout << "Invalid account number or password. Please try again." << endl;
    return false;
    cout << endl;


}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)//�w����reservation�}�C��
{
    ReservationRecord newReservation{};
    strcpy_s(newReservation.idNumber, sizeof(newReservation.idNumber), idNumber);
    for (int i = 1; i <= 18; i++)
    {
        cout << i << ". " << branchNames[i] << endl;
    }
    int choice;
    cout << endl;
    do
    {

        cout << "Enter your choice (0 to end):";
        cin >> choice;
        cout << endl;
    } while (choice < 0 || choice>18);
    newReservation.branchCode = choice;
    Date d[7];
    compAvailableDates(d);//�p�G����0�n�B�z?
    newReservation.date = d[0];
    //��J�H��
    int people;
    do
    {
        cout << "Enter the number of customers (1~30, 0 to end): ";
        cin >> people;
        cout << endl;
    } while (people < 0 || people>30);
    newReservation.numCustomers = people;

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])//��X�᭱7��
{
    Date currentDate = compCurrentDate();
    cout << "The current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;
    cout << endl;
    tm current;
    time_t rawTime = time(0);
    localtime_s(&current, &rawTime);
    availableDates[0].year = current.tm_year + 1900;//�ثe�~��
    availableDates[0].month = current.tm_mon + 1;
    if (currentDate.hour == 23)
        availableDates[0].day = current.tm_mday + 1;
    else
        availableDates[0].day = current.tm_mday;
    mktime(&current);

    cout << "Available days:" << endl;
    cout << endl;
    cout << "1. " << availableDates[0].year << "/" << availableDates[0].month << "/" << availableDates[0].day << endl;

    for (int i = 1; i < 7; i++)
    {
        availableDates[i] = availableDates[i - 1];
        availableDates[i].day = availableDates[i - 1].day + 1;
        mktime(&current);
        cout << i + 1 << ". " << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << endl;
    }
    cout << endl;
    /*if (currentDate.hour == 23)//���Ѥ���
    {

        currentDate[0].day = currentDate.day + 1;
        for (int i = 0; i < 7; i++)
        {
            availableDates[i] = currentDate;
            cout<<
        }
    }
    else//���Ѻ�
    {
        availableDates[0] = currentDate;
        for (int i = 1; i < 7; i++)
        {


        }
    }*/
    //��J�Ѽ�
    int choice;//(1��7)
    do
    {
        cout << "Enter your choice (0 to end): ";
        cin >> choice;
        cout << endl;
    } while (choice < 0 || choice>7);

    if (choice == 0)
        return;
    //��J�p��
    int starthour, endhour = 23;
    if (availableDates[choice - 1].day == currentDate.day)
        starthour = currentDate.hour + 1;
    else
        starthour = 0;

    int selecthour;
    do
    {
        cout << "Enter hour (" << starthour << "~" << endhour << "):";
        cin >> selecthour;
        cout << endl;
    } while (selecthour<starthour || selecthour>endhour);

    availableDates[0].hour = selecthour;
    availableDates[0].day = availableDates[choice - 1].day;

}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)//�L�X�������
{
    Date currentDate = compCurrentDate();
    //�p�G�S����� 
    bool found = false;
    for (int i = 0; i < reservations.size(); i++)
    {
        if (strcmp(reservations[i].idNumber, idNumber) == 0)
        {
            found = true;
            break;
        }

    }
    if (!found)
    {
        cout << "No reservations! " << endl;
        return;
    }
    //�L�X���
    int count = 0;
    for (int i = 0; i < reservations.size(); i++)
    {
        if (strcmp(reservations[i].idNumber, idNumber) == 0)
        {
            count++;
            cout << count;
            output(reservations[i]);
        }
    }

    int icount;
    do
    {
        cout << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> icount;
        cout << endl;
    } while (icount > count);


}

void registration(vector< MemberRecord >& memberDetails)//���U
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)//����member�����o�W�|��return true
{
    /*
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile)
    {
        cout << "existingID's file can not be opened" << endl;

    }

    while (inFile.read(reinterpret_cast<char*>(&memberDetails), sizeof(MemberRecord)))
    {
        if (strcmp(memberDetails.idNumber, idNumber) == 0)
        {
            return true;
            break;
        }
    }
    return false;*/
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0)
        {
            return true;
            break;
        }
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)//�smember�}�C��member�Ҥ�
{
    ofstream outFile("Members.dat", ios::binary);
    if (!outFile)
    {
        cout << "saveMemberDetails's file can not be opened" << endl;
        return;
    }
    MemberRecord record;
    for (int i = 0; i < memberDetails.size(); i++)
    {
        outFile.write(reinterpret_cast<char*>(&record), sizeof(record));
    }


}

void saveReservations(const vector< ReservationRecord >& reservations)
{

    ofstream outFile("Reservations.dat", ios::binary);
    if (!outFile)
    {
        cout << "saveReservations's file can not be opened" << endl;
        return;
    }
    ReservationRecord record;
    for (int i = 0; i < reservations.size(); i++)
    {
        outFile.write(reinterpret_cast<char*>(&record), sizeof(record));
    }


}