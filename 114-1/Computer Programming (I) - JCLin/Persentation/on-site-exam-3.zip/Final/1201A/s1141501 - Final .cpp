#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream infile("Members.dat", ios::in | ios::binary);
    if (!infile)
    {
        cout << "Members.dat can't open in loadMenberDetails.\n";
        return;
    }

    infile.seekg(0, ios::end);
    size_t number = static_cast<size_t>(infile.tellg()) / sizeof(MemberRecord);   
    infile.seekg(0, ios::beg);

    MemberRecord tem;
    memberDetails.push_back(tem);                 //��0�����s�F��
    for (size_t i = 1; i <= number; i++)            
    {
        infile.read(reinterpret_cast<char*>(&tem), sizeof(MemberRecord));
        memberDetails.push_back(tem);
    }

    infile.close();
    return;
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream infile("ReservationInfo.dat", ios::in | ios::binary);
    if (!infile)
    {
        cout << "ReservationInfo.dat can't open in  loadResevations.\n";
        return;
    }

    infile.seekg(0, ios::end);
    size_t number = static_cast<size_t>(infile.tellg()) / sizeof(ReservationRecord);
    infile.seekg(0, ios::beg);

    Date curDate = compCurrentDate();

    ReservationRecord tem;
    reservations.push_back(tem);
    for (size_t i = 1; i <= number; i++)//-------------------------------------------------------------------------------------------------------
    {
        infile.read(reinterpret_cast<char*>(&tem), sizeof(MemberRecord));
        if(lessEqual(curDate, tem.date)==1)
            reservations.push_back(tem);
    }
    infile.close();
    return;

}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    if (date1.year > date2.year)
        return false;
    else
    {
        if (date1.month > date2.month)
            return false;
        else
        {
            if (date1.day > date2.day)
                return false;
            
              
        }
    }

    return true;

}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    for (size_t i = 1; i <= memberDetails.size() - 1; i++)                //---------------------------------------------------------------------------------------------
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0 &&
            strcmp(memberDetails[i].password, password) == 0)
        {
            return true;            
        }             
    }
    cout << "\nInvalid account number or password. Please try again.\n\n";
    return false;
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;
   
   
   for (int i = 1; i <= 18; i++)
   {
       cout << i << ". " << branchNames[i]<<endl;
   }
   int branchchoice; 
   do {
             
       cout << "\nEnter your choice (0 to end):";
       cin >> branchchoice;

       if (branchchoice == 0)
           return;

   } while (branchchoice > 18 || branchchoice < 1);
   newReservation.branchCode = branchchoice;



   Date curDate = compCurrentDate();

   cout << "\nThe current hour is " << curDate.year << "/"
       << curDate.month << "/"
       << curDate.day << ":"
       << curDate.hour << endl << endl;

   cout << "Available days:\n\n";

   Date availableDates[8];
   compAvailableDates(&availableDates[8]);


   for (int i = 1; i <= 7; i++)
   {
       cout << i << ". " << availableDates[i].year << "/"
           << availableDates[i].month << "/"
           << availableDates[i].day << endl;
   }

   int monthchoice;
   do {
       cout << "\nEnter your choice (0 to end):";
       cin >> monthchoice;
       if (monthchoice == 0)
           return;
   } while (monthchoice > 7 || monthchoice < 1);
   newReservation.date.year = availableDates[monthchoice].year;
   newReservation.date.month = availableDates[monthchoice].month;
   newReservation.date.day = availableDates[monthchoice].day;
  



   int hourchoice;
   do {
       cout << "\nEnter hour (" << availableDates[monthchoice].hour << "~" << "23):";
       cin >> hourchoice;
   } while (hourchoice > 23 || hourchoice < availableDates[monthchoice].hour);
   newReservation.date.hour = hourchoice;


   cout << endl;
   int numberchoice;
   do {
       cout << "\nEnter the number of customers (1~30, 0 to end):";
       cin >> numberchoice;
       if (numberchoice == 0)
           return;
   } while (numberchoice > 30 || numberchoice < 1);
   newReservation.numCustomers = numberchoice;

   cout << endl;


   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
   int monthlist[13]{ 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
   Date currentDate = compCurrentDate();

   if (currentDate.year % 400 == 0 || (currentDate.year % 100 != 0 && currentDate.year % 4 == 0))
       monthlist[2] = 29;

   bool is23 = false;
   if (currentDate.hour == 23)                                //�p�G���b23hr
   {
       if (currentDate.day + 1 > monthlist[currentDate.month])   //���
       {
           if (currentDate.month + 1 > 12)                       //��~
           {
               currentDate.year++;
               currentDate.month = 1;
               currentDate.day = 1;
               
           }
           else
           {
               currentDate.month ++;
               currentDate.day = 1;
           }

       }
       else                                                  //���Ӥw
       {
           currentDate.day++;
       }
       currentDate.hour = 0;
       is23 = true;
   }
   int plus = 0;    
   for (int i = 1; i <= 7; i++)
   {
       
       if (currentDate.day + i - 1 > monthlist[currentDate.month])           //����n�i��
       {
           plus++;
           if (currentDate.month + 1 > 12)                                   //�~���n�i��
           {
               availableDates[i].year = currentDate.year + 1;
               availableDates[i].month = 1;
               availableDates[i].day = plus;
               availableDates[i].hour = 0;
               
           }
           else
           {
               availableDates[i].year = currentDate.year;
               availableDates[i].month = currentDate.month + 1;
               availableDates[i].day = plus;
               availableDates[i].hour = 0;
           }
           
       }
       else if(currentDate.day==currentDate.day+i-1)                 //���ζi�����
       {
           availableDates[i].year = currentDate.year;
           availableDates[i].month = currentDate.month;
           availableDates[i].day = currentDate.day + i - 1;                                                                    
           availableDates[i].hour = currentDate.hour;          
       }
       else                                                         //���ζi�줣�O����
       {
           availableDates[i].year = currentDate.year;
           availableDates[i].month = currentDate.month;
           availableDates[i].day = currentDate.day + i - 1;
           availableDates[i].hour = 0;
       }

   }

   return;



}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();
   int countnumber = 0;
   for (size_t i = 1; i <= reservations.size() - 1; i++)                    //-----------------------------------------------------------------------------------------------------
   {
       if (strcmp(reservations[i].idNumber, idNumber) == 0)
       {
           output(reservations[i]);
           countnumber++;
           cout << endl;
       }                  
   }
   if (countnumber == 0)
   {
       cout << "No reservations!\n";
       return;
   }

   int choice;
   do {
       cout << "\n\nChoose a reservation to cancel (0: keep all reservations): ";
       cin >> choice;
       if (choice == 0)
           return;
   } while (choice<0 || choice>countnumber);

   countnumber = 0;
   size_t targetpos;
   for (size_t i = 1; i <= reservations.size() - 1; i++)                 //-----------------------------------------------------------------------------------------------
   {
       if (strcmp(reservations[i].idNumber, idNumber) == 0)
           countnumber++;
       if (countnumber == choice)
           targetpos = i;              
   }

   for (size_t i = targetpos; i < reservations.size() - 1; i++)                  //---------------------------------------------------------------------------------------
       reservations[i] = reservations[i + 1];
   reservations.pop_back();

  



}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    if (memberDetails.size() < 2)
        return false;

    for (size_t i = 1; i <= memberDetails.size() - 1; i++)                  //--------------------------------------------------------------------------------------------
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0)
            return true;       
    }
    return false;
   


}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream outfile("Members.dat", ios::out | ios::binary);
    if (!outfile)
    {
        cout << "Menbers.dat can't open in saveMenberDetails.\n";
        return;
    }

    for (size_t i = 1 ; i <= memberDetails.size() - 1; i++)                       //-------------------------------------------------------------------------------------------------
    {
        outfile.write(reinterpret_cast<const char*> (&memberDetails[i]), sizeof(MemberRecord));
    }

    outfile.close();
    return;

}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream outfile("ReservationInfo.dat", ios::out | ios::binary);
    if (!outfile)
    {
        cout << "ReservationInfo.dat can't open in saveReservations.\n";
        return;
    }
    
    for (size_t i = 1; i <= reservations.size() - 1; i++)                                        //------------------------------------------------------------------------
    {
        outfile.write(reinterpret_cast<const char *> (&reservations[i]), sizeof(ReservationRecord));
    }

    outfile.close();
    return;

}