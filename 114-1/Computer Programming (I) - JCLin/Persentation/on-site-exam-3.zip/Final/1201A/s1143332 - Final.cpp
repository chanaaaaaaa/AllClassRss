﻿#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    if (!inFile) {
        cout << "File could not be opened.\n";
        exit(1);
    }
    inFile.read(reinterpret_cast<char*>(&memberDetails), sizeof(MemberRecord));
    inFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::in | ios::binary);
    if (!inFile) {
        cout << "File could not be opened.\n";
        exit(1);
    }
    inFile.read(reinterpret_cast<char*>(&reservations), sizeof(ReservationRecord));
    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0) - 3 * 24 * 60 * 60;
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    tm a = { 0 };
    tm b = { 0 };
    a.tm_year = date1.year - 1900;
    a.tm_mon = date1.month - 1;
    a.tm_mday = date1.day;
    a.tm_hour = date1.hour;
    b.tm_year = date2.year - 1900;
    b.tm_mon = date2.month - 1;
    b.tm_mday = date2.day;
    b.tm_hour = date2.hour;
    mktime(&a);
    mktime(&b);
    if (a.tm_sec - b.tm_sec <= 0) {
        return true;
    }
    else return false;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); ++i) {
        if (idNumber == memberDetails[i].idNumber && password == memberDetails[i].password) {
            return true;
        }
    }
    cout << "Invalid account number or password. Please try again.\n";
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    for (int i = 1; i < 19; ++i) {
        cout << i << ". " << branchNames[i][24] << "\n";
    }
    do {
        cout << "\nEnter your choice(0 to end): ";
        cin >> newReservation.branchCode;
    } while (newReservation.branchCode < 1 || newReservation.branchCode>18);
    cout << "The currenet hour is: ";

    do {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> newReservation.numCustomers;
    } while (newReservation.numCustomers > 30);
    if (newReservation.numCustomers == 0) {
        return;
    }

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    int menumonth[20];
    int menuyear[20];
    int menuday[20];
    int monthindex[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
    if (currentDate.year % 400 == 0 || (currentDate.year % 4 == 0 && currentDate.year % 100 != 0)) {
        monthindex[2] = 29;
    }
    cout << "\nAvailible days: \n";
    for (int i = 1; i < 7; ++i) {
        int showmonth = currentDate.month;
        int showyear = currentDate.year;
        int showday = currentDate.day + i;
        if (showmonth > 12) {
            showmonth -= 12;
            showyear += 1;
        }
        cout << i << ". " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << "/\n";
        menuyear[i] = showyear;
        menumonth[i] = showmonth;
        menuday[i] = showday;

    }
    int selectnum = 0;
    do {
        cout << "\nEnter your choice(0 to end): ";
        cin >> selectnum;
    } while (selectnum > 7);
    availableDates->year = menuyear[selectnum];
    availableDates->month = menumonth[selectnum];
    availableDates->day = menuday[selectnum];

    cout << "\nEnter hour(0~23): ";
    cin >> currentDate.hour;

}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    vector<ReservationRecord> newreservation[10];
    int count = 1;
    int index[20];
    for (int i = 0; i < reservations.size(); ++i) {
        if (idNumber == reservations[i].idNumber) {
            cout << count << "." << setw(26) << reservations[i].branchCode
                << setw(14) << reservations[i].idNumber << setw(8) << reservations[i].idNumber
                << setw(19) << reservations[i].numCustomers << endl;
            index[count] = i;

            newreservation[count].push_back(reservations[i]);
            count++;
        }
    }
    int select = 0;
    do {
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
        cin >> select;
    } while (select > count);
    int match = index[select];
    if (select == 0)cout << "\n";
    else reservations[match] = { "",0,0 };
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); ++i) {
        if (idNumber == memberDetails[i].idNumber)return true;
        else return false;
    }
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::out | ios::binary);
    if (!outFile) {
        cout << "File could not be opened.\n";
        exit(1);
    }
    outFile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord));
    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::out | ios::binary);
    if (!outFile) {
        cout << "file could not be opened.\n";
        exit(1);
    }
    outFile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
    outFile.close();
}