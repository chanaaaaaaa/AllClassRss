#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream infile("Members.dat", ios::in | ios::binary);
    if (!infile) {
        cout << "file can not open;";
        return;
    }
    MemberRecord* buffer = new MemberRecord[300];
    int numbuffer = 0;
    
    while (infile.read(reinterpret_cast<char*>(&buffer[numbuffer]), sizeof(MemberRecord))) {
        numbuffer++;
    }
    for (int i = 0; i <= numbuffer; i++) {
        memberDetails.push_back(buffer[i]);
    }
    infile.close();
    delete[]buffer;

}

void loadReservations(vector< ReservationRecord >& reservations)
{
    Date currentdate = compCurrentDate();
    ifstream infile("Reservations.dat", ios::in | ios::binary);
    if (!infile) {
        cout << "file can not open;";
        return;
    }
    ReservationRecord buffer[300];
    int numbuffer = 0;
    while (infile.read(reinterpret_cast<char*>(&buffer[numbuffer]), sizeof(ReservationRecord))) {
        
        if (lessEqual(currentdate,buffer[numbuffer].date) == 1) {
            numbuffer++;
        }
        
    }
    for (int i = 0; i <= numbuffer; i++) {
        reservations.push_back(buffer[i]);
    }
    infile.close();
    

}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0) - 3 * 24 * 60 * 60;
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year ) {
        return true;
    }
    else if(date1.year == date2.year){
        if (date1.month < date2.month) {
            return true;
        }
        else if (date1.month > date2.month) {
            return false;
        }
        else{
            
            if (date1.day <= date2.day) {
                return true;
            }
            else
                return false;
            
        }
        
    }
    else {
        return false;
    }



}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 &&
            strcmp(password, memberDetails[i].password) == 0)
        {
            return true;
        }
    }
    cout << "\nInvalid account number or password. Please try again." << endl;
    cout << endl;
    return false;


}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation = {};
    for (int i = 1; i <= 18; i++) {
        cout << setw(2) << i << ". " << branchNames[i] << endl;
    }
    int inputchoice = -1;

     do {
         cout << "\nEnter your choice (0 to end): ";
         cin >> inputchoice;
         if (inputchoice == 0)
            return;
     } while (inputchoice < 1  && inputchoice != 0 || inputchoice > 18);
  
    newReservation.branchCode = inputchoice;
    Date current = compCurrentDate();
    cout << "\nThe current hour is " << current.year << "/" << current.month << "/" << current.day << ": " << current.hour << endl;
    Date buffer[7] = {};
    compAvailableDates(buffer);

    int inputdaychoice = -1;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> inputdaychoice;
        if (inputdaychoice == 0)
            return;
    } while (inputdaychoice < 1 && inputdaychoice != 0 || inputdaychoice > 7);
    newReservation.date.year = buffer[inputdaychoice - 1].year;
    newReservation.date.month = buffer[inputdaychoice - 1].month;
    newReservation.date.day = buffer[inputdaychoice - 1].day;

    int starthour = 0, lasthour = 23;
    if (inputdaychoice == 1 && newReservation.date.day == current.day) {
        starthour = current.hour;
        if (current.hour == 23)
            starthour = 0;
    }
    int inputhourchoice = 0;
    do {
        cout << "\nEnter hour (" << starthour << "~" << lasthour << "): ";
        cin >> inputhourchoice;
    } while (inputhourchoice < starthour || inputhourchoice > lasthour);
    newReservation.date.hour = inputhourchoice;
    int numcuschoice = -1;
    do {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> numcuschoice;
        if (numcuschoice == 0)
            return;
    } while (numcuschoice < 1 || numcuschoice > 30);
    newReservation.numCustomers = numcuschoice;


    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    int daysinmonth[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
    if (currentDate.year % 400 == 0 || ((currentDate.year % 4 == 0) && (currentDate.year % 100 != 0))) {
        daysinmonth[2] = 29;
    }
    else if (currentDate.year % 100 == 0 && currentDate.year % 400 != 0) {
        daysinmonth[2] = 28;
    }
    cout << "\nAvailable days:" << endl;
    Date bufferdate[7] = {};
    for (int i = 0; i <= 6; i++) {
        int showyear = currentDate.year, showmonth = currentDate.month, showday = currentDate.day + i;
        if (currentDate.hour == 23)
            showday++;
        if (showday > daysinmonth[showmonth]) {
            showday -= daysinmonth[showmonth];
            showmonth++;
        }
        if (showmonth > 12) {
            showmonth -= 12;
            showyear++;
        }
        availableDates[i].year = showyear;
        availableDates[i].month = showmonth;
        availableDates[i].day = showday;
        cout << i + 1 << ". " << showyear << "/" << showmonth << "/" << showday << endl;
    }
    
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    int count = 0;
    int deleteindex = -1;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(idNumber, reservations[i].idNumber) == 0) {
            count++;
            cout << count << ". ";
            output(reservations[i]);
        }
    }
    
    do {
        cout << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> deleteindex;
        if (deleteindex == 0) {
            saveReservations(reservations);
            continue;
        }
    } while (deleteindex < count || deleteindex > count);

    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(idNumber, reservations[i].idNumber) == 0 ) {
            count++;
            if (count == deleteindex) {
                deleteindex = i;
            }
        }
    }
    vector< ReservationRecord > buffer;
    for (int i = 0; i < reservations.size(); i++) {
        buffer[i] = reservations[i];
    }
    for (int i = 0; i < buffer.size(); i++) {
        if (i != deleteindex) {
            reservations[i] = buffer[i];
        }
    }
    
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {
            return true;
        }
    }
    return false;

}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outfile("Members.dat", ios::out | ios::binary);
    if (!outfile) {
        return;
    }
    for (int i = 0; i < memberDetails.size(); i++) {
        outfile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    outfile.close();


}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outfile("Reservations.dat", ios::out | ios::binary);
    if (!outfile) {
        return;
    }
    for (int i = 0; i < reservations.size(); i++) {
        outfile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }
    outfile.close();
}