#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        cout << "\nEnter your choice (1~3): ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream infile("Members.dat", ios::binary | ios::in);
    if (!infile) {
        cout << "Members.dat could not be found." << endl;
        system("pause");
        exit(0);
    }

    MemberRecord temp;
    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        memberDetails.push_back(temp);
    }

    infile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    Date now = compCurrentDate();

    ifstream infile("Reservations.dat", ios::binary | ios::in);
    if (!infile) {
        cout << "Reservations.dat could not be found." << endl;
        system("pause");
        exit(0);
    }

    ReservationRecord temp;
    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord))) {
        if (lessEqual(now, temp.date)) {
            reservations.push_back(temp);
        }
    }

    infile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year != date2.year) {
        return date1.year < date2.year;
    }

    if (date1.month != date2.month) {
        return date1.month < date2.month;
    }

    if (date1.day != date2.day) {
        return date1.day < date2.day;
    }

    if (date1.hour != date2.hour) {
        return date1.hour < date2.hour;
    }

    return false;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "\nPlease enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        cout << "\nEnter your choice (1~3): ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 &&
            strcmp(password, memberDetails[i].password) == 0)

            return true;
    }

    cout << "\nInvalid account number or password. Please try again.\n";
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date now = compCurrentDate();

    ReservationRecord newReservation;

    for (int i = 1; i < 19; i++) {
        cout << setw(2) << i << "." << branchNames[i] << endl;
    }

    int choice_branchCode;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice_branchCode;
        if (choice_branchCode == 0) return;
    } while (choice_branchCode < 0 || choice_branchCode > 18);
    newReservation.branchCode = choice_branchCode;

    cout << "\nThe current hour is " << now.year << "/" << now.month << "/" << now.day << ":" << now.hour << endl;

    Date availableDates[7];
    compAvailableDates(availableDates);
    cout << "\nAvailable days:\n";
    for (int i = 0; i < 7; i++) {
        cout << i + 1 << ". " << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << endl;
    }

    int choice_date;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice_date;
        if (choice_date == 0) return;
    } while (choice_date < 0 || choice_date > 7);
    newReservation.date = availableDates[choice_date - 1];

    int min_hour = 0, max_hour = 23;
    if (now.year == newReservation.date.year &&
        now.month == newReservation.date.month &&
        now.day == newReservation.date.day) {

        min_hour = now.hour + 1;
    }

    int choice_hour;
    do {
        cout << "\nEnter hour (" << min_hour << "~" << max_hour << "): ";
        cin >> choice_hour;
    } while (choice_hour < min_hour || choice_hour > max_hour);
    newReservation.date.hour = choice_hour;

    int customer_number;
    do {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> customer_number;
        if (customer_number == 0) return;
    } while (customer_number < 0 || customer_number > 30);
    newReservation.numCustomers = customer_number;

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date now = compCurrentDate();

    int month_day[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    if ((now.year % 4 == 0 && now.year % 100 != 0) || now.year % 400 == 0) {
        month_day[3] == 29;
    }

    Date temp = now;
    bool have_skip = false;
    for (int i = 0; i < 7; i++) {
        if (now.hour == 23 && !have_skip) {
            temp.day++;
            have_skip == true;
            continue;
        }
        
        if (temp.day > month_day[temp.month]) {
            temp.day -= month_day[temp.month];
            temp.month++;
        }

        if (temp.month > 12) {
            temp.month -= 12;
            temp.year++;
        }

        availableDates[i] = temp;
        temp.day++;
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    vector< ReservationRecord > my_reservations;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(idNumber, reservations[i].idNumber) != 0) continue;
        if (reservations[i].numCustomers == 0) continue;

        my_reservations.push_back(reservations[i]);
    }

    if (my_reservations.size() == 0) {
        cout << "\nNo reservations!\n";
        return;
    }

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;
    for (int i = 0; i < my_reservations.size(); i++) {
        cout << i + 1 << ". ";
        output(my_reservations[i]);
    }

    int choice_cancel;
    do {
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
        cin >> choice_cancel;
        if (choice_cancel == 0) return;
    } while (choice_cancel < 0 || choice_cancel > my_reservations.size());

    ReservationRecord cancel_reservation = my_reservations[choice_cancel - 1];
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(reservations[i].idNumber, cancel_reservation.idNumber) == 0 &&
            reservations[i].branchCode == cancel_reservation.branchCode &&
            reservations[i].date.year == cancel_reservation.date.year &&
            reservations[i].date.month == cancel_reservation.date.month &&
            reservations[i].date.day == cancel_reservation.date.day &&
            reservations[i].date.hour == cancel_reservation.date.hour &&
            reservations[i].numCustomers == cancel_reservation.numCustomers)

            reservations[i].numCustomers = 0;
    }
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {
            return true;
        }
    }

    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outfile("Members.dat", ios::binary | ios::out);
    if (!outfile) {
        cout << "Members.dat could not be found." << endl;
        system("pause");
        exit(0);
    }

    for (int i = 0; i < memberDetails.size(); i++) {
        outfile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }

    outfile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    Date now = compCurrentDate();

    ofstream outfile("Reservations.dat", ios::binary | ios::out);
    if (!outfile) {
        cout << "Reservations.dat could not be found." << endl;
        system("pause");
        exit(0);
    }

    for (int i = 0; i < reservations.size(); i++) {
        if (reservations[i].numCustomers == 0) continue;

        if (lessEqual(now, reservations[i].date)) {
            outfile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
        }
    }

    outfile.close();
}