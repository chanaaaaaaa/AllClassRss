#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

int inputAnInteger(int begin, int end);
void login(const vector< MemberRecord >& memberDetails, vector< ReservationRecord >& reservations);
bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails);
void reservation(char idNumber[], vector< ReservationRecord >& reservations);
void compAvailableDates(Date availableDates[]);
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);
void output(ReservationRecord reservation);
void registration(vector< MemberRecord >& memberDetails);
void loadMemberDetails(vector< MemberRecord >& memberDetails);
void loadReservations(vector< ReservationRecord >& reservations);
void saveMemberDetails(const vector< MemberRecord >& memberDetails);
void saveReservations(const vector< ReservationRecord >& reservations);
Date compCurrentDate();
bool lessEqual(const Date& date1, const Date& date2);
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);
    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            continue;

        case 2:
            registration(memberDetails);
            continue;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            continue;
        }
    }

    system("pause");
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin >> string;

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    bool exist = false;
    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
        for (int i{ 0 }; i < memberDetails.size(); i++)
        {
            if (!strcmp(idNumber, memberDetails[i].idNumber))
            {
                exist = true;
                break;
            }
        }
        if (!exist)
        {
            cout << "Invalid account number. Please assign an account." << endl;
            return;
        }
        if (!valid(idNumber, password, memberDetails))
            cout << endl << "Invalid account number or password. Please try again." << endl << endl;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            continue;

        case 2:
            queryDelete(idNumber, reservations);
            continue;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            continue;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i{ 0 }; i < memberDetails.size(); i++)
    {
        if (!strcmp(idNumber, memberDetails[i].idNumber))
            if (!strcmp(password, memberDetails[i].password))
                return true;
    }

    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    for (int i{ 1 }; i <= 18; i++)
        cout << setw(2) << i << ". " << branchNames[i] << endl;
    do {
        cout << endl << "Enter your choice (0 to end): ";
        cin >> newReservation.branchCode;
        if (newReservation.branchCode == 0)
            return;
    } while (newReservation.branchCode > 18 || newReservation.branchCode < 1);

    cout << endl << "The current hour is " << compCurrentDate().year << '/' << compCurrentDate().month
        << '/' << compCurrentDate().day << ':' << compCurrentDate().hour << endl;
    cout << endl << "Available days:" << endl << endl;

    Date availableDates[8];
    compAvailableDates(availableDates);

    for (int i{ 1 }; i <= 7; i++)
    {
        cout << i << ". " << availableDates[i].year << '/'
            << availableDates[i].month << '/'
            << availableDates[i].day << endl;
    }

    int choose{ 0 };
    do {
        cout << endl << "Enter your choice (0 to end): ";
        cin >> choose;
        if (choose == 0)
            return;
    } while (choose < 1 || choose > 7);

    do {
        cout << "Enter hour (" << availableDates[choose].hour << "~23): ";
        cin >> newReservation.date.hour;
    } while (newReservation.date.hour < availableDates[choose].hour || newReservation.date.hour > 23);

    do {
        cout << "Enter the number of customers (1~30, 0 to end): ";
        cin >> newReservation.numCustomers;
        if (newReservation.numCustomers == 0)
            return;
    } while (newReservation.numCustomers < 1 || newReservation.numCustomers > 30);

    strcpy_s(newReservation.idNumber, sizeof(idNumber), idNumber);
    newReservation.date.year = availableDates[choose].year;
    newReservation.date.month = availableDates[choose].month;
    newReservation.date.day = availableDates[choose].day;

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);

    return;
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    int EndOfMonth[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    for (int i{ 1 }; i <= 7; i++)
    {
        if (currentDate.year % 400 == 0 || (currentDate.year % 4 == 0 && currentDate.year % 100 != 0))
            EndOfMonth[2] = 29;
        else
            EndOfMonth[2] = 28;
        if (currentDate.hour > 22)
        {
            availableDates[i].day = currentDate.day + 1;
            availableDates[i].hour = 0;
        }
        else if (currentDate.hour != 0)
        {
            availableDates[i].hour = currentDate.hour + 1;
            availableDates[i].day = currentDate.day;
        }
        else
        {
            availableDates[i].hour = currentDate.hour;
            availableDates[i].day = currentDate.day + 1;
        }

        if (availableDates[i].day > EndOfMonth[currentDate.month])
        {
            availableDates[i].day = 1;
            availableDates[i].month = currentDate.month + 1;
        }
        else
            availableDates[i].month = currentDate.month;
        if (availableDates[i].month > 12)
        {
            availableDates[i].month = 1;
            availableDates[i].year = currentDate.year + 1;
        }
        else
            availableDates[i].year = currentDate.year;

        currentDate.hour = 0;
        currentDate.day = availableDates[i].day;
        currentDate.month = availableDates[i].month;
        currentDate.year = availableDates[i].year;
    }
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    int j{ 0 };
    for (int i{ 0 }; i < reservations.size(); i++)
        if (!strcmp(idNumber, reservations[i].idNumber))
            ++j;

    if (j == 0)
    {
        cout << "No reservations!" << endl;
        return;
    }

    cout << endl << setw(28) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;
    j = 0;
    for (int i{ 0 }; i < reservations.size(); i++)
        if (!strcmp(idNumber, reservations[i].idNumber))
        {
            cout << ++j << '.';
            output(reservations[i]);
        }
    int choose{ 0 };
    do {
        cout << endl << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> choose;
        if (choose == 0)
            return;
    } while (choose < 1 || choose > j);

    reservations.erase(reservations.begin() + (choose - 1));
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i{ 0 }; i < memberDetails.size(); i++)
    {
        if (!strcmp(idNumber, memberDetails[i].idNumber))
            return true;
    }

    return false;
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream infile("Members.dat", ios::in | ios::binary);
    if (!infile)
    {
        cout << "File can't open" << endl;
        return;
    }

    memberDetails.resize(0);
    MemberRecord temp;
    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(temp)))
    {
        memberDetails.push_back(temp);
    }
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream infile("Reservations.dat", ios::in | ios::binary);
    if (!infile)
    {
        cout << "File can't open" << endl;
        return;
    }

    reservations.resize(0);
    ReservationRecord temp;
    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(temp)))
    {
        if (lessEqual(temp.date, compCurrentDate()))
            continue;
        else
            reservations.push_back(temp);
    }

}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outfile("Members.dat", ios::out | ios::binary);
    if (!outfile)
    {
        cout << "The file can't open" << endl;
        return;
    }

    MemberRecord temp;
    for (int i{ 0 }; i < memberDetails.size(); i++)
    {
        temp = memberDetails[i];
        outfile.write(reinterpret_cast<char*>(&temp), sizeof(temp));
    }
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outfile("Reservations.dat", ios::out | ios::binary);
    if (!outfile)
    {
        cout << "The file can't open" << endl;
        return;
    }

    ReservationRecord temp;
    for (int i{ 0 }; i < reservations.size(); i++)
    {
        temp = reservations[i];
        outfile.write(reinterpret_cast<char*>(&temp), sizeof(temp));
    }
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year)
        cout << 1 << endl;
    else if (date1.year == date2.year && date1.month < date2.month)
        cout << 2 << endl;
    else if (date1.year == date2.year && date1.month == date2.month && date1.day < date2.day)
        return true;
    else
        return false;
}