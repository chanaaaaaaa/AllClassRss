#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream infile("Members.dat", ios::in | ios::binary);
    if (!infile) {
        cout << "File could not be opened.";
        exit(1);
    }

    MemberRecord memberRecord;
    while (infile.read(reinterpret_cast<char*>(&memberRecord), sizeof(MemberRecord))) {
        memberDetails.push_back(memberRecord);
    }
    infile.close();


}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream infile("Reservations.dat", ios::in | ios::binary);
    if (!infile) {
        cout << "File could not be opened.";
        exit(1);
    }
    Date currentDate = compCurrentDate();
    ReservationRecord reservation;
    while (infile.read(reinterpret_cast<char*>(&reservation), sizeof(ReservationRecord))) {
        if (lessEqual(currentDate, reservation.date)) {
            reservations.push_back(reservation);
        }
    }
    infile.close();



}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 ) - 3 * 24 * 60 * 60;
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    vector<int>monthDays = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    int days1 = 0;
    for (int i = 1970; i < date1.year; i++) {
        if ((i % 400 == 0) || (i % 4 == 0 && i % 100 != 0))
            days1 += 366;
        else
            days1 += 365;
    }
    for (int i = 1; i < date1.month; i++) {
        if (((date1.year % 400 == 0) || (date1.year % 4 == 0 && date1.year % 100 != 0)) && i == 2)
            days1 += 29;
        else
            days1 += monthDays[i - 1];
    }
    days1 += date1.day;

    int days2 = 0;
    for (int i = 1970; i < date2.year; i++) {
        if ((i % 400 == 0) || (i % 4 == 0 && i % 100 != 0))
            days2 += 366;
        else
            days2 += 365;
    }
    for (int i = 1; i < date2.month; i++) {
        if (((date2.year % 400 == 0) || (date2.year % 4 == 0 && date2.year % 100 != 0)) && i == 2)
            days2 += 29;
        else
            days2 += monthDays[i - 1];
    }
    days2 += date2.day;

    if (days1 <= days2)
        return true;
    else
        return false;
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    bool foundMember = false;
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0 &&
            strcmp(memberDetails[i].password, password) == 0){ 
            foundMember = true;
            break;
        }
    }
    
    if (foundMember) {
        return true;
    }
    else {
        cout << "\nInvalid account number or password. Please try again.\n\n";
        return false;
    }
    
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;
  
   cout << endl;
   for (int i = 1; i <= 18; i++) {
       cout << setw(2) << i << ". " << branchNames[i] << endl;
   }

   do cout << "\nEnter your choice (0 to end): ";
   while (( newReservation.branchCode = inputAnInteger(0, 18)) == -1);
   cout << endl;

   if (newReservation.branchCode == 0) {
       return; 
   }



   Date availableDates[7];
   compAvailableDates(availableDates);


   int dateChoice;
   do { cout << "\nEnter your choice (0 to end):"; } 
   while ((dateChoice = inputAnInteger(0, 18)) == -1);
   if (newReservation.branchCode == 0) {
       return;
   }
   newReservation.date.year = availableDates[dateChoice - 1].year;
   newReservation.date.month = availableDates[dateChoice - 1].month;
   newReservation.date.day = availableDates[dateChoice - 1].day;

   int minHr = 0;
   Date currentDate = compCurrentDate();
   if (dateChoice == 1 && currentDate.hour == 23) {
       minHr = 1;
   }
   else {
       minHr = currentDate.hour + 1;
   }
   do {
       cout << "\nEnter hour (" << minHr << "~" << 23 << "):";
   } while ((newReservation.date.hour = inputAnInteger(minHr, 23)) == -1);

   do {
       cout << "\nEnter the number of customers (1~30, 0 to end):";
   } while ((newReservation.numCustomers = inputAnInteger(0, 30)) == -1);
   if (newReservation.numCustomers == 0) {
       return;
   }

   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();

   cout << "\nThe current hour is " <<
       currentDate.year << "/" << 
       currentDate.month << "/" << 
       currentDate.day << ":" << 
       currentDate.hour << endl;
   
   vector<int>monthDays = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
   for (int i = 0; i < 7; i++) {
       if (currentDate.hour == 23) {
           availableDates[i].day = currentDate.day + 1 + i;
       } else {
           availableDates[i].day = currentDate.day + i;

       }
       if (availableDates[i].day > monthDays[currentDate.month - 1]) {

           availableDates[i].day = 1;
           availableDates[i].month++;

           if (availableDates[i].month > 12) {
               availableDates[i].year++;
               availableDates[i].month = 1;
           }
           else {
               availableDates[i].year = currentDate.year;
           }
       }
       else {
           availableDates[i].month = currentDate.month;
       }
       
   }

   cout << "\nAvailable days:\n";
   cout << endl;
   for (int i = 0; i < 7; i++) {
       cout << (i + 1) << ". " <<
           availableDates[i].year << "/"
           << availableDates[i].month << "/"
           << availableDates[i].day << endl;
   }
   
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();

   vector <int> matches;
   int matchCounter = 1;
   bool foundReservation = false;
   for (int i = 0; i < reservations.size(); i++) {
       if (strcmp(reservations[i].idNumber, idNumber) == 0) {
           foundReservation = true;
           matches[matchCounter] = i;
           matchCounter++;
       }
   }

   if (foundReservation == false) {
       cout << "\nNo reservations!\n";
       return;
   }

   cout << endl << setw(26) << "Branch"
       << setw(14) << "Date" << setw(8) << "Hour"
       << setw(19) << "No of Customers" << endl;

   
   int ticketNum = 1;
   for (int i = 0; i < reservations.size(); i++) {
       if (strcmp(reservations[i].idNumber, idNumber) == 0 &&
           lessEqual(currentDate, reservations[i].date)) {
           cout << ticketNum << ".           ";
           output(reservations[i]);
           ticketNum++;
       }
   }

   int deleteChoice;
   do { cout << "\nChoose a reservation to cancel (0: keep all reservations):"; }
   while ((deleteChoice = inputAnInteger(0, matchCounter )) == -1);

   if (deleteChoice == 0)
       return;

   ofstream outfile("Reservations.dat", ios::out | ios::binary);
   if (!outfile) {
       cout << "File could not be saved";
       exit(1);
   }

   for (int i = 0; i < reservations.size(); i++) {
       if (i == matches[deleteChoice]) {
           continue;
       }
       outfile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
   }
   outfile.close();

}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0)
            return true;
    }
    return false;
}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream outfile("Members.dat", ios::out | ios::binary);
    if (!outfile) {
        cout << "File could not be saved";
        exit(1);
    }
    for (int i = 0; i < memberDetails.size(); i++) {
        outfile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    outfile.close();
}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream outfile("Reservations.dat", ios::out | ios::binary);
    if (!outfile) {
        cout << "File could not be saved";
        exit(1);
    }

    Date currentDate = compCurrentDate();
    for (int i = 0; i < reservations.size(); i++) {
        if (lessEqual(currentDate, reservations[i].date)) {
            outfile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
        }
    }
    outfile.close();


}