﻿#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}
//空
void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream infile("Members.dat", ios::in | ios::binary);
    if (!infile)
    {
        cout << "File could not be opened.";
        return;
    }

    MemberRecord temp{};
    //int num = 0;
    

    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord)))
    {
        memberDetails.push_back(temp);
    }


    infile.close();
}
//空
void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream infile("Reservations.dat", ios::in | ios::binary);
    if (!infile)
    {
        cout << "File could not be opened.";
        return;
    }

    ReservationRecord temp{};

    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord)))
    {
        //如果現在時間>訂位就不要讀
        if (!lessEqual(temp.date, compCurrentDate()))
        {
            reservations.push_back(temp);
        }
    }


    infile.close();
}

Date compCurrentDate()
{
    Date currentDate{};
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}
//空
bool lessEqual(const Date& date1, const Date& date2)
{
    //如果1>2 回傳false
    if (date1.year > date2.year) return date1.year < date2.year;
    if (date1.month > date2.month) return date1.month < date2.month;
    if (date1.day > date2.day) return date1.day < date2.day;
    //if (date1.hour > date2.hour) return date1.hour < date2.hour;

    return true;




}
// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Inquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

//空
bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (size_t i = 0; i < memberDetails.size(); i++)
    {
        //看帳號密碼有沒有對應
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0 &&
            strcmp(memberDetails[i].password,password) == 0)
        {
            return true;
        }
    }
    
    cout << "\nInvalid account number or password. Please try again.\n";
    return false;




}

//空
void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation{};

    //輸入分店選項
    for (int i = 1; i <= 18; i++)
    {
        cout << setw(2) << i << ". ";
        for (int j = 0; j < 24; j++)
        {
            cout << branchNames[i][j];
        }
        cout << endl;
    }
    do
    {
        cout << "\nEnter your choice (0 to end): ";
        cin >> newReservation.branchCode;
        if (newReservation.branchCode == 0)
        {
            return;
        }
    } while (newReservation.branchCode < 0 || newReservation.branchCode>18);

    //輸出現在時間
    Date currentDate = compCurrentDate();
    Date availableDate{};
    cout << "\nThe current hour is " << currentDate.year << '/' << currentDate.month << '/' << currentDate.day << ':' << currentDate.hour << endl;
    cout << "\nAvailable days: \n"<<endl;
    compAvailableDates(availableDate); //輸出七天可選

    //選日期
    int choice;
    do
    {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice;
        if (choice == 0)
        {
            return;
        }
    } while (choice < 0 || choice>7);

    //把日期放到newReservation 日加天數再檢查要不要進位
    int monthdays[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };

    newReservation.date.year = currentDate.year;
    newReservation.date.month = currentDate.month;
    newReservation.date.day = currentDate.day + choice - 1;
    
    //看是不是閏年
    if (newReservation.date.year / 400 == 0) monthdays[2 - 1] = 29;
    if (newReservation.date.year / 4 == 0 && newReservation.date.year / 100 != 0) monthdays[2 - 1] = 29;

    //檢查天數有沒有超過
    if (newReservation.date.day > monthdays[newReservation.date.month - 1]) 
    {
        newReservation.date.day -= monthdays[newReservation.date.month - 1];
        newReservation.date.month ++;
    }
    //檢查月份有沒有超過
    if (newReservation.date.month > 12)
    {
        newReservation.date.month -= 12;
        newReservation.date.year ++;
    }

    //選時間
    int minhour = 0;
    if (choice == 1)
    {
        minhour = currentDate.hour + 1;
        if (minhour > 23) minhour = 0;
    }
    do
    {
        cout << "\nEnter hour (" << minhour << " ~ 23): ";
        cin >> newReservation.date.hour;
    } while (newReservation.date.hour < minhour || newReservation.date.hour>23);

    //輸入人數
    do
    {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> newReservation.numCustomers;
        if (newReservation.numCustomers == 0)
        {
            return;
        }
    } while (newReservation.numCustomers < 1 || newReservation.numCustomers > 30);

    //輸出訂位紀錄
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}
//空
void compAvailableDates(Date availableDates)
{
    Date currentDate = compCurrentDate();

    availableDates.year = currentDate.year;
    availableDates.month = currentDate.month;
    availableDates.day = currentDate.day;

    //每月天數
    int monthdays[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
    
    //超過23點 從隔天開始
    if (currentDate.hour == 23)
    {
        availableDates.day++;
        availableDates.hour = 0;
    }
    //輸出可選的七天
    for (int i = 1; i <= 7; i++)
    {
        
        //超過天數
        if (availableDates.day > monthdays[availableDates.month - 1])
        {
            availableDates.day -= monthdays[availableDates.month - 1];
            availableDates.month++;
        }
        //超過月份
        if (availableDates.month > 12)
        {
            availableDates.month -= 12;
            availableDates.year++;
        }

        cout << i << ". " << availableDates.year << '/' << availableDates.month << '/' << availableDates.day << endl;
        availableDates.day++;
        
    }



}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}
//空
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    loadReservations(reservations); //已經沒有讀超過時間的訂位
 
    //輸出訂位紀錄
    bool found = false;
    for (size_t i = 0; i < reservations.size(); i++)
    {
        if (strcmp(idNumber, reservations[i].idNumber) == 0)
        {
            found = true;
            
            cout << endl << setw(26) << "Branch"
                << setw(14) << "Date" << setw(8) << "Hour"
                << setw(19) << "No of Customers" << endl;

            cout << i+1 << ". ";
            output(reservations[i]);
        }
    }

    if (!found)
    {
        cout << "No reservations!\n";
        return;
    }

    //問刪哪個訂位
    int choice;
    int num = reservations.size();
    do
    {
        cout << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> choice;
        if (choice == 0)
        {
            return;
        }
    } while (choice < 0 || choice > num);

    //寫回檔案
    ofstream outfile("Reservations.dat", ios::out | ios::binary);
    int currentFound = 0; //數這個人總共幾筆訂位

    for (size_t i = 0; i < reservations.size(); i++)
    {
        if (strcmp(idNumber, reservations[i].idNumber) == 0)
        {
            currentFound ++;
        }
        if (currentFound != choice)
        {
            outfile.write(reinterpret_cast<char*>(&reservations[i]), sizeof(ReservationRecord));
        }
    }

    outfile.close();

}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember{};

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}
//空
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    
    vector< MemberRecord > member;
    loadMemberDetails(member);

    //static_cast<int> memberDetails.size();
    for (size_t i= 0; i < memberDetails.size(); i++)
    {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0)
        {
            return true;
        }
        
    }

    return false;
    
    






}
//空
void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outfile("Members.dat", ios::out | ios::binary | ios::app);
    if (!outfile)
    {
        cout << "File could not be opened.";
        return;
    }
    
    outfile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord));

    outfile.close();


}
//空
void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outfile("Reservations.dat", ios::out | ios::binary | ios::app);
    if (!outfile)
    {
        cout << "File could not be opened.";
        return;
    }

    outfile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));

    outfile.close();


}