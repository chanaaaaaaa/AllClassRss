#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inf("Members.dat", ios::binary);
    if (!inf)
    {
        cout << "Members.dat can't open !\n";
        return;
    }
    MemberRecord tmpmb = {};
    while (inf.read(reinterpret_cast<char*>(&tmpmb), sizeof(MemberRecord))) memberDetails.push_back(tmpmb);
    inf.close();
    return;
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inf("Reservations.dat");
    if (!inf)
    {
        cout << "Reservations.dat can't open !\n";
        return;
    }
    Date cur = compCurrentDate();
    ReservationRecord tmprs = {};
    while (inf.read(reinterpret_cast<char*>(&tmprs), sizeof(ReservationRecord))) if (lessEqual(tmprs.date, cur)) reservations.push_back(tmprs);
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;
    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year > date2.year) return true;
    if (date1.year == date2.year && date1.month > date2.month)  return true;
    if (date1.month == date2.month && date1.day >= date2.day) return true;
    return false;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    bool flag = false;
    for (int i = 0; i < memberDetails.size(); ++i)
    {
        if (!strcmp(memberDetails[i].idNumber, idNumber) && !strcmp(memberDetails[i].password, password))
        {
            flag = true;
            break;
        }
    }
    if (!flag) cout << "\nInvalid account number or password. Please try again.\n\n";
    return flag;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    int choice;
    ReservationRecord newReservation;
    for (int i = 0; i < sizeof(idNumber); ++i) newReservation.idNumber[i] = idNumber[i];
    for (int i = 1; i < 19; ++i) cout << setw(2) << i << ". " << branchNames[i] << "\n";
    do
    {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice;
        cin.ignore();
        if (!choice) return;
        cout << "\n";
    } while (choice < 1 || choice>18);
    newReservation.branchCode = choice;
    Date cur = compCurrentDate();
    cout << "\nThe current hour is " << cur.year << '/' << cur.month << '/' << cur.day << ':' << cur.hour << "\n";
    cout << "\nAvailable days:\n\n";
    Date print[7];
    compAvailableDates(print);
    for (int i = 0; i < 7; ++i) cout << i + 1 << ". " << print[i].year << '/' << print[i].month << '/' << print[i].day << "\n";
    do
    {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice;
        cin.ignore();
        if (!choice) return;
        cout << "\n";
    } while (choice < 1 || choice>7);
    int ch;
    do
    {
        cout << "\nEnter hour (" << print[choice - 1].hour << "~23): ";
        cin >> ch;
        cout << "\n";
        cin.ignore();
    } while (ch < print[choice - 1].hour || ch>23);
    print[choice - 1].hour = ch;
    newReservation.date = print[choice - 1];
    int ch2;
    do
    {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> ch2;
        cin.ignore();
        if (!ch2) return;
        cout << "\n";
    } while (ch2 < 1 || ch2>30);
    newReservation.numCustomers = ch2;
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDatse[])
{
    Date currentDate = compCurrentDate();
    int year = currentDate.year, month = currentDate.month, day = currentDate.day, hour = currentDate.hour;
    int m[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
    if ((!(currentDate.year % 4) && currentDate.year % 100) || !(currentDate.year % 400)) m[1] = 29;
    int mxd = m[currentDate.month - 1];
    if (hour == 23)
    {
        ++day;
        hour = 0;
    }
    if (day > mxd)
    {
        day = 1;
        ++month;
        mxd = m[(month - 1) % 12];
    }
    if (month > 12)
    {
        month -= 12;
        ++year;
    }
    availableDatse[0] = { year,month,day++,hour };
    hour = 0;
    for (int i = 1; i < 7; ++i)
    {
        if (day > mxd)
        {
            day = 1;
            ++month;
            mxd = m[(month - 1) % 12];
        }
        if (month > 12)
        {
            month -= 12;
            ++year;
        }
        if ((!(year % 4) && year % 100) || !(year % 400)) m[1] = 29;
        availableDatse[i] = { year,month,day++,hour };
    }
    return;
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    int choice;
    Date currentDate = compCurrentDate();
    if (!reservations.size())
    {
        cout << "No reservations!\n";
        return;
    }
    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;
    for (int i = 0; i < reservations.size(); ++i)
    {
        cout << i + 1 << ". ";
        output(reservations[i]);
    }
    do
    {
        cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
        cin >> choice;
        cin.ignore();
        if (!choice) return;
        cout << "\n";
    } while (choice<1 || choice>reservations.size());
    vector< ReservationRecord > tmp;
    if (reservations.size() == 1) tmp.clear();
    else for (int i = 0; i < reservations.size(); ++i) if (choice - 1 != i) tmp.push_back(reservations[i]);
    reservations = tmp;
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    bool flag = false;
    for (int i = 0; i < memberDetails.size(); ++i)
    {
        if (!strcmp(memberDetails[i].idNumber, idNumber))
        {
            flag = true;
            break;
        }
    }
    return flag;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream of("Members.dat", ios::binary);
    if (!of)
    {
        cout << "Members.dat can't open !\n";
        return;
    }
    for (int i = 0; i < memberDetails.size(); ++i) of.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    of.close();
    return;
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream of("Reservations.dat");
    if (!of)
    {
        cout << "Reservations.dat can't open !\n";
        return;
    }
    for (int i = 0; i < reservations.size(); ++i) of.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    of.close();
    return;
}
