#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream infile("Members.dat", ios::binary);

    while (infile.read(reinterpret_cast<char*>(&memberDetails), sizeof(MemberRecord)));
    
    infile.close();
}

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream infile("Reservations.dat", ios::binary);

    Date currentDate = compCurrentDate();

    ReservationRecord temp;
    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord)))
    {
        if (lessEqual(currentDate.temp.date))
        {
            infile.seekg(-sizeof(ReservationRecord), ios::cur);
            infile.read(reinterpret_cast<char*>(&reservations), sizeof(ReservationRecord));
        }
    } 
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 ) - 3 * 24 * 60 * 60;
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 )
{
    if (date1.year > date2.year)
        return false;

    else if (date1.month > date2.month)
        return false;

    else if (date1.day > date2.day)
        return false;

    else
        return true;
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    for(int i = 0; i < memberDetails.size(); i++)
        for(int j = 0; j<12;j++)
            if (idNumber[j] != memberDetails[i].idNumber[j])
                return false;

    for (int i = 0; i < memberDetails.size(); i++)
        for (int j = 0; j < 24; j++)
            if (password[j] != memberDetails[i].password[j])
                return false;

    return true;
}
   
// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;
   Date currentDate = compCurrentDate();

   for (int i = 1; i <= 18; i++)
       cout << i << ". " << branchNames[i][24] << endl;

   do
   {
       cout << "/nEnter your choice (0 to end):";
       cin >> newReservation.branchCode;
   } while (newReservation.branchCode < 1 || newReservation.branchCode>18);
   
   cout << "/nThe current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;
   cout << "/nAvailable days:/n" << endl;

   compAvailableDates(reservations[]);

   int choice;
   do
   {
       cout << "/nEnter your choice (0 to end):";
       cin >> choice;
   } while (choice < 1 || choice > 7);

   int celhour;
   do
   {
       cout << "/nEnter hour (" << currentDate.hour+1 << "~23): ";
       cin >> celhour;
   } while (celhour < currentDate.hour + 1 || celhour > 23);

   do
   {
       cout << "/nEnter the number of customers (1~30, 0 to end): ";
       cin >> newReservation.numCustomers;
   } while (newReservation.numCustomers < 1 || newReservation.numCustomers > 30);


   
     

   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();

   bool leap = false;
   if (currentDate.year % 400 == 0 || currentDate.year % 4 == 0 && currentDate.year % 100 != 0)
       leap = true;
   
   int monthday[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
   if (currentDate.month = 2 && leap)
       monthday[currentDate.month] = 29;

   int maxday = monthday[currentDate.month];
   int year = currentDate.year;
   int month = currentDate.month;
   int day = currentDate.day;


   for (int i = 1; i <= 7; i++)
   {
        if (day > maxday)
        {
            day -= maxday;
            month++;
        }
        if (month > 12)
        {
            month -= 12;
            year++;
        }

        cout << i << ". " << year << "/" << month << "/" << day << endl;
        day++;
   }
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();
   
   cout << endl << setw(26) << "Branch"
       << setw(14) << "Date" << setw(8) << "Hour"
       << setw(19) << "No of Customers" << endl;
   output(idNumber[]);
   
   int choice;
   do
   {
       cout << "Choose a reservation to cancel (0: keep all reservations): ";
       cin >> choice;
   } while (choice<1 || choice >);

   reservations.pop_back
   


}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++)
        for (int j = 0; j < 12; j++)
            if (idNumber[j] != memberDetails[i].idNumber[j])
                return false;

    return true;
}

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream outfile("Members.dat", ios::binary);

    while(outfile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord)));

    outfile.close();
}

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outfile("Reservations.dat", ios::binary);

    ReservationRecord temp;
    for (int i = 0; i = reservations.size(); i++)
    {
        reservations[i].date[i]
    }
    




}