﻿#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile) return;

    MemberRecord tmp;
    int numMember = 0;
    while (inFile.read(reinterpret_cast<char*>(&tmp), sizeof(MemberRecord))) {
        memberDetails[numMember++] = tmp;
    }
    inFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::binary);
    if (!inFile) return;

    Date currentDate = compCurrentDate();
    ReservationRecord tmp;
    int numReservation = 0;
    while (inFile.read(reinterpret_cast<char*>(&tmp), sizeof(ReservationRecord))) {
        if (lessEqual(currentDate, reservations[numReservation].date))
            reservations[numReservation++] = tmp;
    }
    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    //date1 < date2 => true
    if ((date1.year == date2.year) && (date1.month == date2.month)) {
        if (date1.day < date2.day)
            return true;
    }
    else if (date1.year == date2.year) {
        if (date1.month < date2.month)
            return true;
    }
    else {
        if (date1.year < date2.year)
            return true;
    }
    return false;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    bool ok = false;
    if (!existingID(idNumber, memberDetails)) {
        return false;
    }
    else {
        int i = 0;
        int max = memberDetails.size();
        while (i < max) {
            if (strcmp(password, memberDetails[i].password) == 0) {
                ok = true;
                break;
            }
            i++;
        }
    }
    return ok;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    int branchchoice;
    for (int i = 1; i <= 18; i++) {
        cout << i << ". " << branchNames[i] << endl;
    }

    do {
        cout << "Enter your choice (0 to end): ";
        cin >> branchchoice;
    } while (branchchoice < 0 || branchchoice > 18);
    if (branchchoice != 0) {
        newReservation.branchCode = branchchoice;

        Date currentDate = compCurrentDate();
        cout << "The current hour is " << currentDate.year << "/"
            << currentDate.month << "/" << currentDate.day << ":"
            << currentDate.hour << endl;

        cout << "Available days: \n";
        Date availableDates;
        compAvailableDates(&availableDates);

        int datechoice;
        do {
            cout << "Enter your choice (0 to end): ";
            cin >> datechoice;
        } while (datechoice < 0 || datechoice > 7);
        if (datechoice != 0) {
            newReservation.date.year = availableDates.year;
            newReservation.date.month = availableDates.month;
            newReservation.date.day = availableDates.day;

            int start = 1;
            if (datechoice == 1)
                start = availableDates.hour;

            int hourchoice = 0;
            do {
                cout << "Enter hour (" << start << "~23): ";
                cin >> hourchoice;
            } while (hourchoice < start || hourchoice > 23);
            newReservation.date.hour = hourchoice;

            int memberchoice;
            do {
                cout << "Enter the number of customs (1~30, 0 to end): ";
                cin >> memberchoice;
            } while (memberchoice < 0 || memberchoice > 30);
            if (memberchoice != 0) {
                newReservation.numCustomers = memberchoice;

                cout << endl << setw(26) << "Branch"
                    << setw(14) << "Date" << setw(8) << "Hour"
                    << setw(19) << "No of Customers" << endl;

                output(newReservation);

                cout << "\nReservation Completed!\n";

                reservations.push_back(newReservation);
            }
        }
    }
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    int year = currentDate.year;
    int month = currentDate.month;
    int day = currentDate.day;
    int hour = currentDate.hour;

    int cnt = 0;

    while (cnt + 1 < 8) {
        int days = 0;
        if (month == 2) {
            //leapYear
            if ((year / 400 == 0) || (year / 4 == 0 && year / 100 != 0))
                days = 29;
            else if ((year / 100 == 0) && (year / 400 != 0))
                days = 28;
            else
                days = 28;
        }
        else if (month == 4 || month == 6 || month == 9 || month == 11)
            days = 30;
        else
            days = 31;

        if (hour >= 23) {
            day++;
            hour = 1;
        }
        if (day > days) {
            month++;
            day -= days;
        }
        if (month > 12) {
            year++;
            month -= 12;
        }

        cout << cnt + 1 << ". " << year << "/" << month << "/" << day << endl;
        availableDates[cnt].year = year;
        availableDates[cnt].month = month;
        availableDates[cnt].day = day;
        availableDates[cnt].hour = hour;
        cnt++;
        day++;
    }

}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    int i;
    int max = reservations.size();
    for (i = 0; i < max; i++) {
        cout << i + 1 << ".";
        output(reservations[i]);
    }
    int deletechoice;
    do {
        cout << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> deletechoice;
    } while (deletechoice < 0 || deletechoice > i);
    if (deletechoice != 0) {
        vector<ReservationRecord> tmpReservations;
        int cnt = 0;
        for (i = 0; i < max - 1; i++) {
            if (deletechoice == cnt + 1) {
                continue;
            }
            tmpReservations.push_back(reservations[i]);
            cnt++;
        }

        saveReservations(tmpReservations);
    }
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    int i = 0;
    int max = memberDetails.size();
    bool found = false;
    while (i < max) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {
            found = true;
            break;
        }
        i++;
    }
    return found;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::binary);
    int max = memberDetails.size();
    int i = 0;
    while (i < max) {
        outFile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord));
        i++;
    }
    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::binary | ios::app);
    int max = reservations.size();
    int i = 0;
    while (i < max) {
        outFile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
        i++;
    }
    outFile.close();
}