#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    MemberRecord temp;
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord))) {
        memberDetails.push_back(temp);
    }
    inFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::in | ios::binary);
    ReservationRecord temp;
    Date currentDate = compCurrentDate();
    while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(ReservationRecord))) {
        if (!lessEqual(temp.date , currentDate))
            reservations.push_back(temp);
    }

    inFile.close();

}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;
    
    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year)
        return true;
    if (date1.year > date2.year)
        return false;
    if (date1.month < date2.month)
        return true;
    if (date1.month > date2.month)
        return false;
    if (date1.day < date2.day)
        return true;
    if (date1.day > date2.day)
        return false;
    if (date1.hour < date2.hour)
        return true;
    else
        return false;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 &&
            strcmp(password, memberDetails[i].password) == 0)
            return true;
    }
    cout << "\nInvalid account number or password. Please try again.\n\n";
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    strcpy_s(newReservation.idNumber, 12, idNumber);

    for (int i = 1; i <= 18; i++) {
        cout << i << ". " << branchNames[i] << endl;
    }

    int Code;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> Code;
        cin.ignore();
    } while (Code < 0 || Code > 18);
    if (Code == 0)
        return;
    newReservation.branchCode = Code;

    Date currentDate = compCurrentDate();
    cout << "\nThe current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;

    Date choose[8];
    compAvailableDates(choose);

    int j;
    do {
        cout << "\nEnter your choice (0 to end):";
        cin >> j;
        cin.ignore();
    } while (j > 7 || j < 0);

    if (j == 0)
        return;

    int hour = 0;
    int k;
    do {
        if (choose[j].day == currentDate.day)
            hour = currentDate.hour + 1;
        cout << "\nEnter hour (" << hour << "~23):";
        cin >> k;
    } while (k < hour || k > 23);
    choose[j].hour = k;

    newReservation.date.year = choose[j].year;
    newReservation.date.month = choose[j].month;
    newReservation.date.day = choose[j].day;
    newReservation.date.hour = choose[j].hour;

    int num;
    do {
        cout << "\nEnter the number of customers (1~30, 0 to end):";
        cin >> num;
        cin.ignore();
    } while (num < 0 || num > 30);
    if (num == 0)
        return;
    newReservation.numCustomers = num;

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    cout << "Available days:\n";
    int year = currentDate.year;
    int month = currentDate.month;
    int day = currentDate.day;
    int months[13] = { 0 , 31 , 28 , 31 , 30 , 31 , 30 , 31 , 31 , 30 , 31 , 30 , 31 };
    bool leapyear;
    for (int i = 1; i <= 7; i++) {
        if (currentDate.hour != 23 || i != 1) {
            cout << i << "." << year << "/" << month << "/" << day << endl;
            availableDates[i].year = year;
            availableDates[i].month = month;
            availableDates[i].day = day;
        }
        else
            i--;

        if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
            leapyear = true;
        else
            leapyear = false;

        if (leapyear && month == 2)
            months[2] = 29;

        if (i != 7)
            day++;
        if (day > months[month]) {
            month++;
            day = 1;
        }
        if (month > 12) {
            year++;
            month = 1;
        }
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    bool found = false;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(reservations[i].idNumber, idNumber) == 0) {
            found = true;
            break;
        }
    }

    if (!found) {
        cout << "No reservations!\n";
        return;
    }

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    int cur = 0;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(reservations[i].idNumber, idNumber) == 0) {
            cur++;
            cout << cur << ".";
            output(reservations[i]);
        }
    }

    int del;
    do {
        cout << "\nChoose a reservation to cancel (0: keep all reservations):";
        cin >> del;
        cin.ignore();
    } while (del < 0 || del > cur);
    vector< ReservationRecord >newReservations;
    int newcur = 0;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(reservations[i].idNumber, idNumber) == 0) {
            newcur++;
        }
        if (strcmp(reservations[i].idNumber, idNumber) != 0 ||
            newcur != del) {
            newReservations.push_back(reservations[i]);
        }
    }
    reservations = newReservations;
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(memberDetails[i].idNumber, idNumber) == 0)
            return true;
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::out | ios::binary);
    for (int i = 0; i < memberDetails.size(); i++)
        outFile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));

    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::out | ios::binary);
    for (int i = 0; i < reservations.size(); i++) {
        outFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }

    outFile.close();
}