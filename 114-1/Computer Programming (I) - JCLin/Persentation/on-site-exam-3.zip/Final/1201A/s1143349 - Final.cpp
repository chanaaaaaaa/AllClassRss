#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    if (!inFile)
    {
        cout << "File could not be opened";
        exit(1);
    }

    while (inFile.read(reinterpret_cast<char*>(&memberDetails), sizeof(memberDetails)))
    {
        ;
    }

    inFile.close();
}

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    if (!inFile)
    {
        cout << "File could not be opened";
        exit(1);
    }

    while (inFile.read(reinterpret_cast<char*>(&reservations), sizeof(reservations)))
    {
        ;
    }

    inFile.close();

}


Date compCurrentDate() // compute the current date
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year <= date2.year)
        if (date1.month <= date2.month)
            if (date1.day <= date2.day)
                return true;

    return false;
}

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    bool fit = false;
    for (int i = 0; i < memberDetails.size(); i++)
    {
        // �p�G��J�b�K�M�Y�|����ƪ��b�K�۲�
        if ((idNumber == memberDetails[i].idNumber) ||
            (password == memberDetails[i].password))
            fit = true;
    }

    if (!fit) // �����ŦX
        cout << endl << "Invalid account number or password.Please try again." << endl;

    return fit;
}

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    strcpy(newReservation.idNumber, idNumber);

    // ��ܥ]�[�ﶵ(18��)
    for (int i = 1; i <= 18; i++)
    {
        cout << setw(2) << i << ". " << branchNames[i];
    }

    // ��ܥ]�[
    int choicePlace = 0;
    do {
        cout << endl << "Enter your choice (0 to end):";
        cin >> choicePlace;
        if (choicePlace == 0) return; // ���������o��function
    } while (choicePlace < 0 || choicePlace>18);
    newReservation.branchCode = choicePlace;


    // ��ܷ��U�~����
    Date currentDate = compCurrentDate();
    cout << endl << "The current hour is "
        << currentDate.year << "/"
        << currentDate.month << "/"
        << currentDate.day << ":"
        << currentDate.hour << endl;

    // ��ܥi����
    cout << "Available days:" << endl;
    Date availableDates;
    compAvailableDates(&availableDates);

    // ����
    int choiceDay = 0;
    do {
        cout << "Enter your choice (0 to end):";
        cin >> choiceDay;
        if (choiceDay == 0) return;
    } while (choiceDay < 0 || choiceDay > 7);

    // �B�z���
    Date chooseDate = currentDate;
    chooseDate.day += choiceDay;


    if (chooseDate.month == 12 && chooseDate.day > 31) // ��~
    {
        chooseDate.year += 1;
        chooseDate.month = 1;
        chooseDate.day -= 31;
    }
    if ((chooseDate.month == 1 ||
        chooseDate.month == 3 ||
        chooseDate.month == 5 ||
        chooseDate.month == 7 ||
        chooseDate.month == 8 ||
        chooseDate.month == 10)
        && chooseDate.day > 31) // ��j��
    {
        chooseDate.month += 1;
        chooseDate.day -= 31;
    }
    if ((chooseDate.month == 4 ||
        chooseDate.month == 6 ||
        chooseDate.month == 9 ||
        chooseDate.month == 11)
        && chooseDate.day > 30) // ��p��
    {
        chooseDate.month += 1;
        chooseDate.day -= 30;
    }
    if (chooseDate.month == 2 && chooseDate.day > 28)
    {
        // �O�|�~
        if (chooseDate.year % 400 == 0 || (chooseDate.year % 4 == 0 && chooseDate.year % 100 != 0))
        {
            if (chooseDate.day > 29)
            {
                chooseDate.month += 1;
                chooseDate.day -= 29;
            }
        }
        else // �D�|�~
        {
            chooseDate.month += 1;
            chooseDate.day -= 28;
        }

    }
    newReservation.date = chooseDate;


    // ��ܮɶ�&��ɶ�
    int choiceHour = 0;
    if (currentDate.hour + 1 > 23)
    {
        do {
            cout << endl << "Enter hour (0~23):";
            cin >> choiceHour;
        } while (choiceHour < 0 || choiceHour>23);
    }
    else
    {
        do {
            cout << endl << "Enter hour (" << currentDate.hour + 1 << "~23):";
            cin >> choiceHour;
        } while (choiceHour < currentDate.hour + 1 || choiceHour>23);
    }
    newReservation.date.hour = choiceHour;

    // ��J�H��
    int peopleNum = 0;
    do {
        cout << endl << "Enter the number of customers (1~30, 0 to end):";
        cin >> peopleNum;
        if (peopleNum == 0) return;
    } while (peopleNum < 0 || peopleNum>30);
    newReservation.numCustomers = peopleNum;



    // �H�U��ܭq���T

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

// compute 7 dates which is starting from the current date
// ��X�i�w�����C��
// �|�~:y%400==0||(y%4==0&&y%100!=0)
void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    // ���ݦ��S�����
    Date checkDate = currentDate;
    if (checkDate.hour + 1 > 23)
        checkDate.day++;

    // ��C��
    for (int i = 0; i < 7; i++)
    {
        Date showDate = checkDate;
        showDate.day += i;

        if (showDate.month == 12 && showDate.day > 31) // ��~
        {
            showDate.year += 1;
            showDate.month = 1;
            showDate.day -= 31;
        }
        if ((showDate.month == 1 ||
            showDate.month == 3 ||
            showDate.month == 5 ||
            showDate.month == 7 ||
            showDate.month == 8 ||
            showDate.month == 10)
            && showDate.day > 31) // ��j��
        {
            showDate.month += 1;
            showDate.day -= 31;
        }
        if ((showDate.month == 4 ||
            showDate.month == 6 ||
            showDate.month == 9 ||
            showDate.month == 11)
            && showDate.day > 30) // ��p��
        {
            showDate.month += 1;
            showDate.day -= 30;
        }
        if (showDate.month == 2 && showDate.day > 28)
        {
            // �O�|�~
            if (showDate.year % 400 == 0 || (showDate.year % 4 == 0 && showDate.year % 100 != 0))
            {
                if (showDate.day > 29)
                {
                    showDate.month += 1;
                    showDate.day -= 29;
                }
            }
            else // �D�|�~
            {
                showDate.month += 1;
                showDate.day -= 28;
            }

        }

        cout << i + 1 << ". "
            << showDate.year << "/"
            << showDate.month << "/"
            << showDate.day << endl;
    }

}

// display all fields of reservation
void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    // �D�X�S���W�L���Ѫ�
    vector< ReservationRecord > checkReservation;
    for (int i = 0; i < reservations.size(); i++)
    {
        if (lessEqual(currentDate, reservations[i].date))
        {
            checkReservation.push_back(reservations[i]);
        }
    }

    // ��ܲŦX���q��
    for (int i = 0; i < checkReservation.size(); i++)
    {
        cout << i + 1;
        output(checkReservation[i]);
        cout << endl;
    }

    // ���
    int delChoice = 0;
    do {
        cout << "Choose a reservation to cancel (0: keep all reservations):";
        cin >> delChoice;
        if (delChoice == 0) return;
    } while (delChoice<0 || delChoice>checkReservation.size());


}

// add a new member
void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    bool found = false;
    MemberRecord check;

    for (int i = 0; i < memberDetails.size(); i++)
    {

        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) // �p�G���b�|����Ƹ�
        {
            found = true;
            break;
        }
    }
    return found;
}

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::out | ios::binary);

    if (!outFile)
    {
        cout << "File could not be opened";
        exit(1);
    }

    while (outFile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(memberDetails)))
    {
        ;
    }

    outFile.close();
}

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::out | ios::binary);

    if (!outFile)
    {
        cout << "File could not be opened";
        exit(1);
    }

    Date currentDate = compCurrentDate();

    // �D�X�S���W�L���Ѫ�
    vector< ReservationRecord > checkReservation;
    for (int i = 0; i < reservations.size(); i++)
    {
        if (lessEqual(currentDate, reservations[i].date))
        {
            checkReservation.push_back(reservations[i]);
        }
    }

    while (outFile.write(reinterpret_cast<const char*>(&checkReservation), sizeof(checkReservation)))
    {
        ;
    }

    outFile.close();
}