﻿#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream loadFile("Members.dat", ios::in | ios::binary);

    if (!loadFile)
    {
        cout << "File could not be opened." << endl;
        return;
    }

    MemberRecord temp{};
    char idNumber[12] = "";

    loadFile.read(reinterpret_cast<char*>(&temp), sizeof(MemberRecord));
    memberDetails.push_back(temp);

    loadFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream loadFile("Reservations.dat", ios::in | ios::binary);

    if (!loadFile)
    {
        cout << "File could not be opened." << endl;
        return;
    }

    compCurrentDate();
    Date date1;
    Date date2;

    if (lessEqual(date1, date2))
        loadFile.read(reinterpret_cast<char*>(&reservations), sizeof(ReservationRecord));

    loadFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0) - 3 * 24 * 60 * 60;
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (strcmp(reinterpret_cast<const char*>(&date1), reinterpret_cast<const char*>(&date2)) <= 0)
        return true;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i <= 12; i++)
    {
        if (strcmp(reinterpret_cast<const char*>(idNumber[i]), reinterpret_cast<const char*>(&memberDetails)) == 0 &&
            strcmp(reinterpret_cast<const char*>(password[i]), reinterpret_cast<const char*>(&memberDetails)) == 0)
            return true;
    }
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    ofstream reserveFile("Reservations.dat", ios::out | ios::binary);

    if (!reserveFile)
    {
        cout << "File could not be opened." << endl;
        return;
    }

    char temp[12] = "";
    ReservationRecord temp{};
    while (reserveFile.write(reinterpret_cast<const char*>(&temp), sizeof(ReservationRecord)))
    {
        for (int i = 0; i <= 12; i++)
            idNumber[i] = temp[i];

        newReservation = temp;
    }

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    int year, month, day, hour;
    int count = 0;
    currentDate = { year, month, day, hour };

    cout << "\nThe current hour is " << availableDates << endl;

    do {
        cout << "\nAvailable days: \n";
        for (int i = 1; i <= 7; i++)
        {
            cout << i << "." << " ";
            count++;
            day++;

            int maxDay;

            if (month == 2)
            {
                if (year % 400 == 0 || year % 4 == 0 && year % 100 != 0)
                    maxDay = 29;
                else
                    maxDay = 28;
            }
            else if (month == 4 || month == 6 || month == 9 || month == 11)
                maxDay = 30;
            else
                maxDay = 31;

            if (day == maxDay)
                month++;

            if (month == 13)
            {
                year++;
                month = 1;
            }

            if (hour >= 23)
                day++;

            cout << year << "/" << month << "/" << day << endl;
        }

    } while (count < 1 || count > 6);

    sprintf_s(reinterpret_cast<const char*>(&availableDates), 20, "year, month, day, hour");
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    ofstream deleteFile("Reservations.dat", ios::out | ios::binary);

    if (!deleteFile)
    {
        cout << "File could not be opened." << endl;
        return;
    }

    reservation(idNumber, reservations);
    int deletedIndex;

    cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
    cin >> deletedIndex;

    if (!deletedIndex)
    {
        deleteFile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
    }
    deleteFile.close();
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i <= 12; i++)
    {
        if (strcmp(reinterpret_cast<const char*>(idNumber[i]), reinterpret_cast<const char*>(&memberDetails)) == 0)
            return true;
    }
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream saveFile("Members.dat", ios::out | ios::binary);

    if (!saveFile)
    {
        cout << "File could not be opened." << endl;
        return;
    }

    MemberRecord temp{};
    saveFile.write(reinterpret_cast<const char*>(&temp), sizeof(MemberRecord));

    saveFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream saveFile("Resrevations.dat", ios::out | ios::binary);

    if (!saveFile)
    {
        cout << "File could not be opened." << endl;
        return;
    }

    ReservationRecord temp{};
    saveFile.write(reinterpret_cast<const char*>(&temp), sizeof(MemberRecord));

    saveFile.close();
}