#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South", "Taipei Zhongxiao",
                                 "Taipei Songjiang",    "Taipei Nanjing",
                                 "Taipei Linsen",       "Taipei Zhonghua New",
                                 "Banqiao Guanqian",    "Yonghe Lehua",
                                 "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                 "Zhongli Zhongyang",   "Hsinchu Beida",
                                 "Taichung Ziyou",      "Chiayi Ren'ai",
                                 "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                 "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector<MemberRecord> memberDetails; // member details for all members
    vector<ReservationRecord> reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector<MemberRecord>& memberDetails)
{
    ifstream inFile("Members.dat", ios::binary);
    if (!inFile)
    {
        cout << "File could not be opend.";
        return;
    }

    MemberRecord buffer{};
    while (inFile.read(reinterpret_cast<char*>(&buffer), sizeof(buffer)))
        memberDetails.push_back(buffer);

    inFile.close();
}

void loadReservations(vector<ReservationRecord>& reservations)
{
    ifstream inFile("Reservations.dat", ios::binary);
    if (!inFile)
    {
        cout << "File could not be opend.";
        return;
    }

    ReservationRecord buffer{};
    while (inFile.read(reinterpret_cast<char*>(&buffer), sizeof(buffer)))
        reservations.push_back(buffer);

    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);
    
    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;
/*
    currentDate.year = 2100;
    currentDate.month = 2;
    currentDate.day = 27;
    currentDate.hour = 3;
*/
    return currentDate;
}

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year == date2.year)
    {
        if (date1.month == date2.month)
            return date1.day < date2.day;

        return date1.month <= date2.month;
    }
    return date1.year <= date2.year;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails, vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[], const vector<MemberRecord>& memberDetails)
{
    for (const MemberRecord& memberDetail : memberDetails)
        if (strcmp(idNumber, memberDetail.idNumber) == 0)
            if (strcmp(password, memberDetail.password) == 0)
                return true;

    cout << "\nInvalid account number or password. Please try again.\n" << endl;
    return false;
}

void reservation(char idNumber[], vector<ReservationRecord>& reservations)
{
    ReservationRecord newReservation;
    strcpy_s(newReservation.idNumber, 12, idNumber);

    // ��ܩҦ�����
    for (int i = 1; i <= 18; ++i)
        cout << setw(2) << i << ". " << branchNames[i] << endl;
    
    // ��ܤ���
    int branchChoice;
    do {
        cout << "\n" << "Enter your choice (0 to end): ";
        cin >> branchChoice;

        if (branchChoice == 0)
        {
            cin.ignore();
            return;
        }
    } while (branchChoice < 1 || branchChoice > 18);
    newReservation.branchCode = branchChoice;

    // ��ܲ{�b�ɶ�
    Date currentDate = compCurrentDate();
    cout << "\nThe current hour is " << currentDate.year << '/' << currentDate.month << '/' << currentDate.day << ':' << currentDate.hour << endl;

    // �p����C��
    Date availableDates[7]{};
    compAvailableDates(availableDates);

    // ��ܭ��C��
    cout << "\nAvailable days:\n\n";
    for (int i = 0; i < 7; ++i)
        cout << i + 1 << ". " << availableDates[i].year << '/' << availableDates[i].month << '/' << availableDates[i].day << endl;

    // ��ܭ��@��
    int dateChoice;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> dateChoice;

        if (dateChoice == 0)
        {
            cin.ignore();
            return;
        }
    } while (dateChoice < 1 || dateChoice > 7);
    newReservation.date.year = availableDates[dateChoice - 1].year;
    newReservation.date.month = availableDates[dateChoice - 1].month;
    newReservation.date.day = availableDates[dateChoice - 1].day;

    // ��ܭ��@��
    int hourChoice;
    do {
        cout << "\nEnter hour (" << availableDates[dateChoice - 1].hour << "~23): ";
        cin >> hourChoice;
    } while (hourChoice < availableDates[dateChoice - 1].hour || hourChoice > 23);
    newReservation.date.hour = hourChoice;

    // ��ܦh�֤H
    int numCustomers;
    do {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> numCustomers;

        if (numCustomers == 0)
        {
            cin.ignore();
            return;
        }
    } while (numCustomers < 1 || numCustomers > 30);
    newReservation.numCustomers = numCustomers;

    cout << endl << setw(26) << "Branch"
         << setw(14) << "Date" << setw(8) << "Hour"
         << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
    cin.ignore();
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    auto isLeapYear = [](int year) { return year % 400 == 0 || (year % 4 == 0 && year % 100 != 0); };

    constexpr int days[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int y = currentDate.year, m = currentDate.month, d = currentDate.day, h = currentDate.hour;

    for (int i = 0; i < 7; ++i)
    {
        int maxDay = (m == 2 && isLeapYear(y)) ? 29 : days[m];

        // �Ĥ@�ѯS���B�z�G23 �ɡH�v�T d, h
        if (i == 0)
        {
            if (h == 23)
            {
                d = currentDate.day + 1;
                h = 0;
            }

            else
            {
                d = currentDate.day;
                h = currentDate.hour + 1;
            }
        }

        if (i > 0)
        {
            ++d;
            h = 0;
        }

        // �Ҧ��ѯS���B�z�G���H�v�T y, m
        if (d > maxDay)
        {
            d = 1;
            y += (m + 1)/ (12 + 1);
            m = m % 12 + 1;
        }

        // �O�s
        availableDates[i] = { y, m, d, h };
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
         << setw(8) << reservation.date.year << '-'
         << setw(2) << setfill('0') << reservation.date.month << '-'
         << setw(2) << setfill('0') << reservation.date.day
         << setw(8) << setfill(' ') << reservation.date.hour
         << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector<ReservationRecord>& reservations)
{
    Date currentDate = compCurrentDate();
    int reservationNum = 0;

    bool found = false;

    for (const ReservationRecord& reservation : reservations)
    {
        if (strcmp(reservation.idNumber, idNumber)) continue;
        if (lessEqual(reservation.date, currentDate)) continue;

        found = true;
    }
    
    if (!found)
    {
        cout << "No reservations!\n";
        return;
    }

    // ��ܩҦ�����
    cout << "  ";
    cout << setw(26) << "Branch"
         << setw(14) << "Date" << setw(8) << "Hour"
         << setw(19) << "No of Customers" << endl;
    for (const ReservationRecord& reservation : reservations)
    {
        if (strcmp(reservation.idNumber, idNumber)) continue;
        if (lessEqual(reservation.date, currentDate)) continue;

        found = true;
        cout << ++reservationNum << '.';
        output(reservation);   
    }

    // ��ܬ���
    int deleteChoice;
    do {
        cout << "\nChoose a reservation to cancel(0: keep all reservations) : ";
        cin >> deleteChoice;

        if (deleteChoice == 0) 
        {
            cin.ignore();
            return;
        }
    } while (deleteChoice < 1 || deleteChoice > reservationNum);

    // �Ыإt�@ vector ���L�ӵ�����
    int newReservationNum = 0;
    vector<ReservationRecord> newReservations;
    for (const ReservationRecord& reservation : reservations)
    {
        if (strcmp(reservation.idNumber, idNumber) == 0) ++newReservationNum;
        if (newReservationNum == deleteChoice) continue;

        newReservations.push_back(reservation);
    }
    reservations = newReservations;
    cin.ignore();
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector<MemberRecord>& memberDetails)
{
    for (const MemberRecord& memberDetail : memberDetails)
        if (strcmp(idNumber, memberDetail.idNumber) == 0)
            return true;

    return false;
}

void saveMemberDetails(const vector<MemberRecord>& memberDetails)
{
    ofstream outFile("Members.dat", ios::binary);

    for (const MemberRecord& memberDetail : memberDetails)
        outFile.write(reinterpret_cast<const char*>(&memberDetail), sizeof(memberDetail));

    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::binary);

    for (const ReservationRecord& reservation : reservations)
        outFile.write(reinterpret_cast<const char*>(&reservation), sizeof(reservation));

    outFile.close();
}