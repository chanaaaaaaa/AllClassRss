import argparse
import yaml
import os

def main():
    parser = argparse.ArgumentParser(
        description="Print specific blocks/parameters from a YAML config."
    )

    parser.add_argument("--opt", type=str, required=True,
                        help="Path to YAML config file.")

    parser.add_argument("--stage", type=str, default=None,
                        help=("Choose which config block to print "
                              "(e.g., train, val, network_g, optim_g)."))

    parser.add_argument("--parameter", type=str, default="all",
                        help="Which parameter to print in that block (default: all).")

    parser.add_argument("--h", action="store_true",
                        help="List all top-level config blocks and exit.")

    args = parser.parse_args()

    # ---- Load YAML ----
    if not os.path.isfile(args.opt):
        print(f"[Error] YAML file not found: {args.opt}")
        return

    with open(args.opt, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    # ---- Show block list ----
    if args.h:
        print("Available config blocks:")
        for k in cfg.keys():
            print(f"- {k}")
        return

    # ---- Stage is required unless using --h ----
    if args.stage is None:
        print("[Error] Please specify --stage <block_name>")
        return

    block_name = args.stage

    # ---- Check block exists ----
    if block_name not in cfg:
        print(f"[Error] Block '{block_name}' not found in YAML.")
        return

    block = cfg[block_name]

    print(f"======== {block_name.upper()} BLOCK ========")

    # ---- Print all parameters ----
    if args.parameter == "all":
        if isinstance(block, dict):
            for k, v in block.items():
                print(f"{k}: {v}")
        else:
            print(block)
        return

    # ---- Print specific parameter ----
    param = args.parameter
    if isinstance(block, dict) and param in block:
        print(f"{param}: {block[param]}")
    else:
        print(f"[Error] Parameter '{param}' not found in block '{block_name}'.")
        return


if __name__ == "__main__":
    main()
