#include <iostream>
using namespace std;

class List
{
    private:
        int num,size,*a; // num=quantity of val in array, size=array's size
        void resize()
        {
            int *na=new int[++size]();
            for (int i=0;i<num;++i) na[i]=a[i];
            delete[] a;
            a=na;
        }
    public:
        List()
        {
            num=0,size=5,a=new int[size]();
        }
        void insert(int idx,int val)
        {
            if (num==size) resize();
            for (int i=num;i>idx;--i) a[i]=a[i-1];
            a[idx]=val;
            ++num;
        }
        void remove(int idx)
        {
            for (int i=idx;i<num-1;++i) a[i]=a[i+1];
            --num;
        }
        int get(int idx)
        {
            return a[idx];
        }
        int getSize()
        {
            return num;
        }
        void printList()
        {
            cout<<'[';
            for (int i=0;i<num;++i)
            {
                cout<<a[i];
                if (i!=num-1) cout<<", ";
            }
            cout<<"]\n";
        }
};

int main()
{
    List myList;
    myList.insert(0, 10);
    myList.insert(1, 20);
    myList.insert(2, 30);
    std::cout << "List after initial inserts: ";
    myList.printList();
    myList.insert(1, 15); // Requires shifting
    std::cout << "List after inserting 15 at index 1: ";
    myList.printList();
    myList.remove(3); // Removes 30 (index 3)
    std::cout << "List after removing index 3: ";
    myList.printList();
    std::cout << "Element at index 1: " << myList.get(1) << std::endl;
    std::cout << "List Size: " << myList.getSize() << std::endl;  
}
