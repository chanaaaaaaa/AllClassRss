#include <iostream>
using namespace std;

class Stack
{
    private:
        int top,size,*a;
        void resize()
        {
            int *na=new int[++size]();
            for (int i=0;i<=top;++i) na[i]=a[i];
            delete[] a;
            a=na;
        }
    public:
        Stack()
        {
            top=-1,size=5,a=new int[size]();
        }
        void push(int val)
        {
            if (top==size-1) resize();
            a[++top]=val;
        }
        int pop()
        {
            if (top!=-1) return a[top--];
            return -1;
        }
        int peek()
        {
            if (top!=-1) return a[top];
            return -1;
        }
        bool isEmpty()
        {
            return top==-1;
        }
};

int main()
{
    Stack myStack;
    myStack.push(40);
    myStack.push(50);
    myStack.push(60);
    std::cout << "Is Empty: " << (myStack.isEmpty() ? "True" : "False") << std::endl;
    std::cout << "Peek: " << myStack.peek() << std::endl;
    std::cout << "Popped: " << myStack.pop() << std::endl;
    std::cout << "Popped: " << myStack.pop() << std::endl;
    std::cout << "Is Empty: " << (myStack.isEmpty() ? "True" : "False") << std::endl;
}