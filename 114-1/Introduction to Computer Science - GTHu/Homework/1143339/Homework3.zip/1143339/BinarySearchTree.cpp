#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* left;
    Node* right;
};

class BinarySearchTree
{
    private:
        Node* root;
    public:
        BinarySearchTree()
        {
            root=nullptr;
        }
        void insert(int val)
        {
            Node* nnode=new Node{val,nullptr,nullptr};
            if (root==nullptr) // tree is empty
            {
                root=nnode;
                return;
            }
            Node* now=root;
            Node* fa=nullptr;
            while (now!=nullptr)
            {
                fa=now;
                if (val==now->data) return;
                val<now->data?now=now->left:now=now->right;
            }
            val<fa->data?fa->left=nnode:fa->right=nnode;
        }
        bool search(int val)
        {
            Node* now=root;
            while (now!=nullptr)
            {
                if (val==now->data) return true;
                val<now->data?now=now->left:now=now->right;
            }
            return false;
        }
        void deleteNode(int val)
        {
            Node* now=root;
            Node* fa=nullptr;
            while (now!=nullptr && val!=now->data)
            {
                fa=now;
                val<now->data?now=now->left:now=now->right;
            }
            if (now==nullptr) return;
            if (now->left!=nullptr && now->right!=nullptr)
            {
                // find the smallest in the right
                Node* son=now->right;
                Node* sonfa=now;
                while (son->left!=nullptr) sonfa=son,son=son->left;
                now->data=son->data;
                // delete now later
                now=son;
                fa=sonfa;
            }
            Node* ch=now->left!=nullptr?now->left:now->right;
            // now is root or now is parent's left or right
            fa==nullptr?root=ch:fa->left==now?fa->left=ch:fa->right=ch;
            delete now;
        }
        void inorderTraversal()
        {
            inorder(root);
        }
        void inorder(Node* now)
        {
            if (now!=nullptr)
            {
                inorder(now->left);
                cout<<now->data<<" ";
                inorder(now->right);
            }
            return;
        }
        void preorderTraversal()
        {
            preorder(root);
        }
        void preorder(Node* now)
        {
            if (now!=nullptr)
            {
                cout<<now->data<<" ";
                preorder(now->left);
                preorder(now->right);
            }
            return;
        }
        void postorderTraversal()
        {
            postorder(root);
        }
        void postorder(Node* now)
        {
            if (now!=nullptr)
            {
                postorder(now->left);
                postorder(now->right);
                cout<<now->data<<" ";
            }
            return;
        }
};

int main()
{
    BinarySearchTree myBST;
    int values[] = {60, 40, 80, 30, 50, 70, 90};
    for (int val : values) {
    myBST.insert(val);
    }
    std::cout << "In-order Traversal (Sorted): ";
    myBST.inorderTraversal();
    std::cout << "\nPre-order Traversal (Copy Order): ";
    myBST.preorderTraversal();
    std::cout << "\nSearch for 50: " << (myBST.search(50) ? "Found" : "Not Found") << std::endl;
    // Deletion Test Cases
    myBST.deleteNode(40); // Case 1: Node with one child (30)
    std::cout << "After deleting 40 (one child), In-order: ";
    myBST.inorderTraversal();
    myBST.deleteNode(80); // Case 2: Node with two children (successor is 90)
    std::cout << "\nAfter deleting 80 (two children), In-order: ";
    myBST.inorderTraversal();
    myBST.deleteNode(30); // Case 3: Node with no children (leaf)
    std::cout << "\nAfter deleting 30 (leaf), In-order: ";
    myBST.inorderTraversal();
    std::cout << std::endl;
}