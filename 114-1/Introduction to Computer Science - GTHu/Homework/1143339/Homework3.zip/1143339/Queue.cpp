#include <iostream>
using namespace std;

struct Element
{
    int data;
    Element* next;
};

class Queue
{
    private:
        Element* front;
        Element* rear;
    public:
        Queue()
        {
            front=nullptr,rear=nullptr;
        }
        void enqueue(int val)
        {
            Element* nnode=new Element{val,nullptr};
            if (front==nullptr && rear==nullptr) front=nnode,rear=nnode;
            else
            {
                rear->next=nnode;
                rear=nnode;
            }
        }
        int dequeue()
        {
            if (front!=nullptr)
            {
                Element *tmp=front;
                front=front->next;
                if (front==nullptr) rear=nullptr;
                return tmp->data;
            }
            return -1;
        }
        bool isEmpty()
        {
            return front==nullptr;
        }
};

int main()
{
    Queue myQueue;
    myQueue.enqueue(1);
    myQueue.enqueue(2);
    myQueue.enqueue(3);
    std::cout << "Dequeued: " << myQueue.dequeue() << std::endl;
    myQueue.enqueue(4);
    std::cout << "Dequeued: " << myQueue.dequeue() << std::endl;
    std::cout << "Is Empty: " << (myQueue.isEmpty() ? "True" : "False") << std::endl;
}