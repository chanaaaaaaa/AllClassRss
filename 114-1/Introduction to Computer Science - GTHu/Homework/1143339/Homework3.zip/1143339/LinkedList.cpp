#include <iostream>
using namespace std;

struct Element
{
    int data;
    Element* next; // ptr of next val
};

class LinkedList
{
    private:
        int size;
        Element* head;
    public:
        LinkedList()
        {
            size=0,head=nullptr;
        }
        void insert(int idx,int val)
        {
            Element* nnode=new Element{val,nullptr};
            if (!idx)
            {
                nnode->next=head,head=nnode;
            }
            else
            {
                Element* now=head;
                // LinkedList can't jump an idx, so need  to traversal it with loop
                for (int i=0;i<idx-1;++i) now=now->next;
                nnode->next=now->next,now->next=nnode;
            }
            ++size;
        }
        void remove(int idx)
        {
            if (!idx) head=head->next;
            else
            {
                Element* now=head;
                for (int i=0;i<idx-1;++i) now=now->next;
                now->next=now->next->next;
            }
            --size;
        }
        int get(int idx)
        {
            Element* now=head;
            for (int i=0;i<idx;++i) now=now->next;
            return now->data;
        }
        int getSize()
        {
            return size;
        }
        void printList()
        {
            Element* now=head;
            while (now!=nullptr)
            {
                cout<<now->data<<"-> ";
                now=now->next;
            }
            cout<<"NULL\n";
        }
};

int main()
{
    LinkedList myList;
    myList.insert(0, 5);
    myList.insert(1, 6);
    myList.insert(2, 7);
    std::cout << "List after initial inserts: ";
    myList.printList();
    myList.insert(0, 10); // Insert at head
    std::cout << "List after inserting 10 at index 0: ";
    myList.printList();
    myList.remove(2); // Removes 6 (index 2)
    std::cout << "List after removing index 2: ";
    myList.printList();
    std::cout << "Element at index 2: " << myList.get(2) << std::endl;
}